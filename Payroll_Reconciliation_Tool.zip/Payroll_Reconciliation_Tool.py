from datetime import date
from tkinter import messagebox
from UILayer import frmUserForm


def Expiry():
    ExpiryDate = date(2025, 8, 31)
    if ExpiryDate < date.today():
        messagebox.showinfo("Payroll Reconciliation",
                            "The application has been expired. Please contact WFM automation team for renewal.")
        exit()


Expiry()
frmUserForm.UserForm()
