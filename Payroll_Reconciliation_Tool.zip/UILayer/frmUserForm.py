import os
import pathlib
import tkinter
from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
from tkinter.messagebox import askyesno
from BusinessClasses import clsWriteLog, ExtractPdfData, Outlook


class UserForm:

    def __init__(self):
        self.root = tkinter.Tk()
        self.root.title('Payroll Reconciliation - Ryder')
        self.root.resizable(width=NO, height=NO)
        self.root.iconbitmap(os.getcwd() + r"\Images\cloud.ico")

        # Calculate the screen dimensions
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()

        # Calculate the window dimensions
        window_width = 920
        window_height = 300

        # Calculate the window position
        x = (screen_width - window_width) // 2
        y = (screen_height - window_height) // 2

        # Set the window size and position
        self.root.geometry(f"{window_width}x{window_height}+{x}+{y}")

        top_frame = Frame(self.root, bg="pink", height=20)
        top_frame.pack(side=TOP, fill="x")

        lbl_header = Label(top_frame, text="Payroll Reconciliation", highlightthickness=0, background="pink",
                           bd=0, justify=CENTER, width=50)
        lbl_header.grid(row=0, column=1, padx=5, pady=5, columnspan=3)
        lbl_header.config(font=('Verdana', 20))

        middle_frame = Frame(self.root, height=510)  # bg="gray",
        middle_frame.pack(side=TOP, fill="both")

        lbl_note = Label(middle_frame,
                         text="Note:- Download all the locations folders from sharepoint and extract it before running the tool."
                              "Now select this folder containing location wise sub folders using browse button and click Extract Data button to extract data from all the pdf files.",
                         justify=LEFT)
        lbl_note.grid(row=0, column=0, padx=2, pady=2, columnspan=10, sticky=W)
        lbl_note.config(font=('Verdana', 12), wraplength=800, width=91, height=4, background="gray", fg="white")

        lbl_button = Label(middle_frame, text="Select folder path:-", justify=CENTER, width=20)
        lbl_button.grid(row=2, column=1, padx=2, pady=2, sticky=E)
        lbl_button.config(font=('Verdana', 10))

        self.txt_file_path = Text(middle_frame, width=70, height=2, font=('Verdana', 10))
        self.txt_file_path.grid(row=2, column=3, padx=2, pady=2, sticky=W)
        self.txt_file_path.config(state="disabled")

        btn_browse = Button(middle_frame, text="Browse", width=14, height=2, font=('Verdana', 12), justify=CENTER
                            , command=self.browse_folder, bg="#ffbf00")
        btn_browse.grid(row=2, column=4, padx=2, pady=2)

        btn_extract = Button(middle_frame, text="Extract Data", width=14, height=2, font=('Verdana', 12), justify=CENTER
                             , command=self.extract_data, bg="#ffbf00")
        btn_extract.grid(row=3, column=3, padx=2, pady=2, sticky=W)

        self.root.mainloop()

    def browse_folder(self):
        initial_directory = os.getcwd()
        selected_directory = filedialog.askdirectory(parent=self.root, initialdir=initial_directory,
                                                     title='Please select a folder containing pdf(s)')
        if selected_directory is not None and selected_directory != "":
            self.txt_file_path.config(state="normal")
            self.txt_file_path.delete("1.0", END)
            self.txt_file_path.insert(END, selected_directory.replace('/', '\\'))
            self.txt_file_path.config(state="disabled")
        else:
            self.txt_file_path.config(state="normal")
            self.txt_file_path.delete("1.0", END)
            self.txt_file_path.config(state="disabled")

    def extract_data(self):
        self.txt_file_path.config(state="normal")
        file_path_variable = self.txt_file_path.get(1.0, END).replace('\n', '')
        self.txt_file_path.config(state="disabled")

        if os.path.isfile("ExceptionCode.xlsx") is False:
            messagebox.showinfo(title="Payroll Reconciliation", message="ExceptionCode.xlsx master file not found.",
                                parent=self.root)
            return

        if os.path.isfile("BonusCode.xlsx") is False:
            messagebox.showinfo(title="Payroll Reconciliation", message="BonusCode.xlsx master file not found.",
                                parent=self.root)
            return

        if os.path.isfile("EmailDetails.xlsx") is False:
            messagebox.showinfo(title="Payroll Reconciliation", message="EmailDetails.xlsx master file not found.",
                                parent=self.root)
            return

        if file_path_variable != "":
            result = askyesno(title="Confirm", message="Are you sure that you want to extract data?", parent=self.root)
            if result is True:
                dfExceptionCode = ExtractPdfData.Read_Excel_File("ExceptionCode.xlsx")
                dfExceptionCode = dfExceptionCode.fillna('')

                dfBonusCode = ExtractPdfData.Read_Excel_File("BonusCode.xlsx")
                dfBonusCode = dfBonusCode.fillna('')

                df_EmailDetails = ExtractPdfData.Read_Excel_File("EmailDetails.xlsx")
                df_EmailDetails = df_EmailDetails.fillna('')

                FolderList = os.listdir(file_path_variable)

                for ind in df_EmailDetails.index:
                    strLocation = str(df_EmailDetails['Location'][ind])
                    isLocationFound = False

                    for loc in FolderList:
                        if str(loc).strip() == str(strLocation):
                            isLocationFound = True
                            break

                    if isLocationFound is True:
                        strTO = str(df_EmailDetails['TO_Client'][ind])
                        strCC = str(df_EmailDetails['CC_Client'][ind])
                        strBCC = str(df_EmailDetails['BCC_Client'][ind])
                        strSubjectLine = str(df_EmailDetails['SubjectLine_Client'][ind])
                        strBody = str(df_EmailDetails['Body_Client'][ind])
                        strSignature = str(df_EmailDetails['Signature_Client'][ind])
                        strDisclaimer = str(df_EmailDetails['Disclaimer_Client'][ind])
                        strTOInternal = str(df_EmailDetails['TO_Internal'][ind])
                        strCCInternal = str(df_EmailDetails['CC_Internal'][ind])
                        strBCCInternal = str(df_EmailDetails['BCC_Internal'][ind])
                        strSubjectLineInternal = str(df_EmailDetails['SubjectLine_Internal'][ind])
                        strBodyInternal = str(df_EmailDetails['Body_Internal'][ind])
                        strSignatureInternal = str(df_EmailDetails['Signature_Internal'][ind])
                        strDisclaimerInternal = str(df_EmailDetails['Disclaimer_Internal'][ind])

                        location_folder_path = os.path.join(file_path_variable, str(strLocation))

                        for file in os.listdir(location_folder_path):
                            file_extension = pathlib.Path(file).suffix
                            if file_extension.lower() == ".pdf":
                                strPDFFilePath = os.path.join(location_folder_path, file)

                                strData = ExtractPdfData.Extract_Pdf_Text(strPDFFilePath)

                                strOutputFilePath = os.path.join(location_folder_path,
                                                                 file.replace(file_extension, ".xlsx"))

                                isDifferenceFound, strWeekEnding, strLocation, BonusDetails = ExtractPdfData.Extract_And_Export_Details(
                                    strPdfData=strData, dfException=dfExceptionCode, dfBonus=dfBonusCode,
                                    strOutputFilePath=strOutputFilePath)

                                if os.path.isfile(strOutputFilePath):
                                    AttachmentsList = [strPDFFilePath, strOutputFilePath]
                                    BonusCount = len(BonusDetails)

                                    if isDifferenceFound is False:
                                        # print('Email to client')
                                        if BonusCount == 0:
                                            Outlook.Send_Email(strTO, strCC, strBCC,
                                                               strSubjectLine.replace('#LOC#', strLocation).replace(
                                                                   '#WE#',
                                                                   strWeekEnding),
                                                               strBody.replace('#WE#', strWeekEnding), strSignature,
                                                               strDisclaimer, AttachmentsList)

                                            # clsWriteLog.WriteLog(f"Email sent to client - Bonus details not found.")
                                            clsWriteLog.WriteLog(f" {str(strLocation)} Email sent to client.")
                                        else:
                                            strBody = ""
                                            strBody = strBody + "Hi ,<br><br>"
                                            strBody = strBody + "This location does not have any exception, all drivers got paid accurately.<br><br>"

                                            counter = 1
                                            for bonus in BonusDetails:
                                                strFormattedText = f"{str(counter)}. <b>{str(bonus[3])}</b> is showing paid extra <b>${str(bonus[8])}</b> but his pay is correct because {str(bonus[6])} paid through workday and this we not add in TMW so the pay is correct.<br><br>"
                                                strBody = strBody + strFormattedText
                                                counter = counter + 1

                                            Outlook.Send_Email(strTO, strCC, strBCC,
                                                               strSubjectLine.replace('#LOC#', strLocation).replace(
                                                                   '#WE#',
                                                                   strWeekEnding),
                                                               strBody.replace('#WE#', strWeekEnding), strSignature,
                                                               strDisclaimer, AttachmentsList)

                                            # clsWriteLog.WriteLog(f"Email sent to client - Bonus details found.")
                                            clsWriteLog.WriteLog(f" {str(strLocation)} Email sent to client.")
                                    else:
                                        # print('Email to internal team')
                                        if BonusCount == 0:
                                            Outlook.Send_Email(strTOInternal, strCCInternal, strBCCInternal,
                                                               strSubjectLineInternal.replace('#LOC#',
                                                                                              strLocation).replace(
                                                                   '#WE#', strWeekEnding),
                                                               strBodyInternal.replace('#WE#', strWeekEnding),
                                                               strSignatureInternal, strDisclaimerInternal,
                                                               AttachmentsList)

                                            # clsWriteLog.WriteLog(f"Email sent to Internal WNS Team - Bonus details are not found.")
                                            clsWriteLog.WriteLog(f" {str(strLocation)} Email sent to Internal WNS Team.")
                                        else:
                                            strBodyInternal = ""
                                            strBodyInternal = strBodyInternal + "Hi ,<br><br>"
                                            strBodyInternal = strBodyInternal + "This location found exception(s).Please check.<br>"
                                            strBodyInternal = strBodyInternal + "Also find attached payroll reconciliation - WD vs TMW report for WE -<b>#WE#.</b><br><br>"

                                            counter = 1
                                            for bonus in BonusDetails:
                                                strFormattedText = f"{str(counter)}. <b>{str(bonus[3])}</b> is showing paid extra <b>${str(bonus[8])}</b> but his pay is correct because {str(bonus[6])} paid through workday and this we not add in TMW so the pay is correct.<br><br>"
                                                strBodyInternal = strBodyInternal + strFormattedText
                                                counter = counter + 1

                                            strBodyInternal = strBodyInternal + "<br><br>"

                                            Outlook.Send_Email(strTOInternal, strCCInternal, strBCCInternal,
                                                               strSubjectLineInternal.replace('#LOC#',
                                                                                              strLocation).replace(
                                                                   '#WE#', strWeekEnding),
                                                               strBodyInternal.replace('#WE#', strWeekEnding),
                                                               strSignatureInternal, strDisclaimerInternal,
                                                               AttachmentsList)

                                            # clsWriteLog.WriteLog(f"Email sent to Internal WNS Team - Bonus details found.")
                                            clsWriteLog.WriteLog(f" {str(strLocation)} Email sent to Internal WNS Team.")
                                else:
                                    clsWriteLog.WriteLog(f"Reconciliation for {strLocation} location is not done due to some issues.")
                    else:
                        clsWriteLog.WriteLog(f"Folder does not exists in selected path for {strLocation} location.")

                messagebox.showinfo(title="Payroll Reconciliation",
                                    message="Payroll reconciliation process completed.\n\nPlease check the Log.txt file for status.",
                                    parent=self.root)

                self.txt_file_path.config(state="normal")
                self.txt_file_path.delete("1.0", END)
                self.txt_file_path.config(state="disabled")
        else:
            messagebox.showinfo(title="Payroll Reconciliation", message="Folder is not selected.", parent=self.root)
