import os.path
import pandas as pd
from BusinessClasses import clsWriteLog
from tkinter import messagebox
from pypdf import PdfReader


def Extract_Pdf_Text(strPdfFilePath):
    try:
        reader = PdfReader(strPdfFilePath)
        ExtractedText = ''

        for page in reader.pages:
            ExtractedText = ExtractedText + page.extract_text() + '\n'

    except Exception as ex:
        ExtractedText = ""
        clsWriteLog.WriteLog("Error in Extract_Pdf_Text function:-" + str(ex))
        messagebox.showinfo("Payroll Reconciliation", 'Error in Extract_Pdf_Text:-\n' + str(ex))

    return ExtractedText


def Extract_And_Export_Details(strPdfData, dfException, dfBonus, strOutputFilePath):
    try:
        lines = strPdfData.split('\n')

        MainData = []
        BonusData = []

        strWeekEnding = ""
        strLocation = ""
        strEmployeeID = ""
        strEmployeeName = ""
        strWDAmt = ""
        strTMWAmt = ""
        strCode = ""
        strTMAmount = ""
        strWDAmount = ""
        strMatchType = ""
        isLineStart = False
        DifferenceFound = False

        for line in lines:
            line = str(line).strip()

            if line == "":
                continue

            if isLineStart is False:
                if "WeekEnding:" in line:
                    strWeekEnding = line.split(':')[1].strip()
                    continue

                if "Location:" in line:
                    strLocation = line.split(':')[1].strip()
                    continue

                if "Employee ID:" in line:
                    strEmployeeID = line.split(':')[1].strip()
                    isLineStart = False
                    continue

                if "Name:" in line:
                    strEmployeeName = line.split(':')[1].strip()
                    continue

                if "WD Amt:" in line:
                    line = line.replace(",", "").replace("$", "")
                    strWDAmt = line.split(':')[1].strip()
                    continue

                if "TMW Amt:" in line:
                    line = line.replace(",", "").replace("$", "")
                    strTMWAmt = line.split(':')[1].strip()
                    continue

                if "Code" in line and "Description" in line and "Difference" in line:
                    isLineStart = True
                    continue
            else:
                if "Retro Earning Notes" in line:
                    isLineStart = False
                    continue
                else:
                    if "Code" in line and "Description" in line and "Difference" in line:
                        isLineStart = True
                        continue

                    lstTableData = line.split('$')

                    if len(lstTableData) > 2:
                        strCode = lstTableData[0].strip()
                        strTMAmount = lstTableData[1].strip().replace(",", "")
                        strWDAmount = lstTableData[2].strip().split(' ')[0].replace(",", "")
                        strMatchType = lstTableData[2].strip().split(' ')[1].replace(",", "")
                    else:
                        continue

                    LineData = []
                    LineBonus = []
                    strRemarks = ""
                    # strCode = lstTableData[0].strip()
                    # strTMAmount = lstTableData[1].strip().replace("$", "").replace(",", "")
                    # strWDAmount = lstTableData[2].strip().replace("$", "").replace(",", "")
                    # strMatchType = lstTableData[3].strip()

                    if dfException is not None:
                        result = dfException.loc[(dfException['Code'] == strCode)]  # find exception code in master file
                        exception_row_count = result.shape[0]
                    else:
                        exception_row_count = 0

                    if dfBonus is not None:
                        result = dfBonus.loc[(dfBonus['Code'] == strCode)]  # find dfBonus code in master file
                        bonus_row_count = result.shape[0]
                    else:
                        bonus_row_count = 0

                    if exception_row_count > 0:
                        strRemarks = "Exception found"
                    elif bonus_row_count > 0:
                        LineBonus.append(strWeekEnding)
                        LineBonus.append(strLocation)
                        LineBonus.append(strEmployeeID)
                        LineBonus.append(strEmployeeName)
                        LineBonus.append(strWDAmt)
                        LineBonus.append(strTMWAmt)

                        # Line Details for bonus cases
                        LineBonus.append(strCode)
                        LineBonus.append(strTMAmount)
                        LineBonus.append(strWDAmount)
                        LineBonus.append(strMatchType)
                        LineBonus.append(strRemarks)

                        BonusData.append(LineBonus)
                        strRemarks = "Bonus found"
                    else:
                        fTMAmount = float(strTMAmount)
                        fWDAmount = float(strWDAmount)
                        fDifference = abs(fTMAmount - fWDAmount)

                        if fDifference > 1:
                            DifferenceFound = True
                            if fTMAmount > fWDAmount:
                                strRemarks = "Difference In WD Amount"
                            else:
                                strRemarks = "Difference In TM Amount"
                        else:
                            strRemarks = "Amounts are matching"

                    # Headers details
                    LineData.append(strWeekEnding)
                    LineData.append(strLocation)
                    LineData.append(strEmployeeID)
                    LineData.append(strEmployeeName)
                    LineData.append(strWDAmt)
                    LineData.append(strTMWAmt)

                    # Line Details
                    LineData.append(strCode)
                    LineData.append(strTMAmount)
                    LineData.append(strWDAmount)
                    LineData.append(strMatchType)
                    LineData.append(strRemarks)

                    MainData.append(LineData)
                    continue

        Export_To_Excel(MainData, strOutputFilePath)

    except Exception as ex:
        clsWriteLog.WriteLog(f"Error in Extract_And_Export_Details function for {strLocation} location:-" + str(ex))

    return DifferenceFound, strWeekEnding, strLocation, BonusData


def Export_To_Excel(DictDataList, strFilePath):
    try:
        field_names = ["WeekEnding", "Location", "EmployeeID", "EmployeeName", "WDAmt", "TMWAmt", "Code", "TMAmount",
                       "WDAmount", "MatchType", "Remarks"]

        df = pd.DataFrame(DictDataList, columns=field_names)
        writer = pd.ExcelWriter(strFilePath, engine='xlsxwriter')
        df.to_excel(writer, sheet_name='Data', index=False)
        writer._save()
    except Exception as ex:
        messagebox.showinfo("Payroll Reconciliation", 'Error in Export_To_Excel:-\n' + str(ex))
        clsWriteLog.WriteLog("Error in Export_To_Excel function:-" + str(ex))


def Read_Excel_File(strFilePath):
    try:
        if os.path.isfile(strFilePath):
            dataframe1 = pd.read_excel(strFilePath)
        else:
            dataframe1 = None

        return dataframe1
    except Exception as ex:
        messagebox.showinfo("Payroll Reconciliation", 'Error in Read_Excel_File:-\n' + str(ex))
        clsWriteLog.WriteLog("Error in Read_Excel_File function:-" + str(ex))
        return None
