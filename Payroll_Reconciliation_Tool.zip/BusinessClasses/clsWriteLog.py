import datetime


def WriteLog(strLogMsg):
    try:
        currentTime = datetime.datetime.now()
        logFile = open("Log.txt", "a")
        logFile.write(str(currentTime) + " " + strLogMsg + "\n")
        logFile.close()
    except Exception as err:
        print(f'Error occurred in writelog function {str(err)}')
