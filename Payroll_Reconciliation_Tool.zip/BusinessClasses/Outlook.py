import os.path
import psutil
import time
from tkinter import messagebox
import win32com.client as win32
from BusinessClasses import clsWriteLog


# Drafting and sending email notification to senders. You can add other senders' email in the list
def Send_Email(strTO, strCC, strBCC, strSubject, strBody, strSignature, strDisclaimer, AttachmentList):
    if Check_Outlook_IsOpen() is False:
        messagebox.showinfo("Payroll Reconciliation", 'Outlook is not opened.')
        return

    try:
        outlook = win32.Dispatch('outlook.application')
        olFormatHTML = 2
        olFormatPlain = 1
        olFormatRichText = 3
        olFormatUnspecified = 0
        olMailItem = 0x0

        newMail = outlook.CreateItem(olMailItem)
        newMail.To = strTO
        newMail.Cc = strCC
        newMail.Bcc = strBCC
        newMail.Subject = strSubject
        newMail.BodyFormat = olFormatHTML  # or olFormatRichText or olFormatPlain

        strBodyText = strBody

        if strSignature != "":
            strBodyText = strBodyText + '<br><br>' + strSignature

        if strDisclaimer != "":
            strBodyText = strBodyText + '<br><br><br><br>' + strDisclaimer

        newMail.HTMLBody = strBodyText

        AttachmentsCount = len(AttachmentList)
        if AttachmentsCount >= 1:
            for attachment in AttachmentList:
                newMail.Attachments.Add(attachment)

        # newMail.display()
        newMail.Send()

    except Exception as ex:
        messagebox.showinfo("Payroll Reconciliation", 'Error in Send_Email:-\n' + str(ex))
        clsWriteLog.WriteLog(f"Error in Send_Email function:-" + str(ex))


# Open Outlook.exe. Path may vary according to system config Please check the path to .exe file and update below
def Check_Outlook_IsOpen():
    try:
        flag = 0
        # Checking if outlook is already opened. If not, open Outlook.exe and send email
        for item in psutil.pids():
            p = psutil.Process(item)
            if p.name().upper() == "OUTLOOK.EXE":
                flag = 1
                break
            else:
                flag = 0

        if flag == 1:
            return True
        else:
            return False

    except Exception as ex:
        messagebox.showinfo("Payroll Reconciliation", 'Error in Check_Outlook_IsOpen:-\n' + str(ex))
        clsWriteLog.WriteLog(f"Error in Check_Outlook_IsOpen function:-" + str(ex))


def Open_Outlook_Application():
    try:
        if os.path.isfile(r"C:\Program Files\Microsoft Office\Office16\OUTLOOK.EXE"):
            os.startfile(r"C:\Program Files\Microsoft Office\Office16\OUTLOOK.EXE")
            time.sleep(2)
            return

        if os.path.isfile(r"C:\Program Files (x86)\Microsoft Office\Office16\OUTLOOK.EXE"):
            os.startfile(r"C:\Program Files (x86)\Microsoft Office\Office16\OUTLOOK.EXE")
            time.sleep(2)
            return

    except Exception as ex:
        messagebox.showinfo("Payroll Reconciliation", 'Error in Open_Outlook_Application:-\n' + str(ex))
        clsWriteLog.WriteLog(f"Error in Open_Outlook_Application function:-" + str(ex))
