from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.secret_key = 'App@123'

# SQL Server connection string  C:\Pundlik\FlowchartMaker
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///IntellectApp.db'
# app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///Pundlik//FlowchartMaker//IntellectApp.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)


# User model
class User(db.Model):
    UserID = db.Column(db.Integer, primary_key=True)
    FirstName = db.Column(db.String(50), nullable=False)
    LastName = db.Column(db.String(50), nullable=False)
    EmailID = db.Column(db.String(50), unique=True, nullable=False)
    Password = db.Column(db.String(50), nullable=False)
    ProcessName = db.Column(db.String(50), nullable=False)
    Role = db.Column(db.String(50), nullable=False)
    IsActive = db.Column(db.Boolean, default=False)
    CreatedBy = db.Column(db.String(50), nullable=False)
    CreatedDateTime = db.Column(db.DateTime, default=datetime.utcnow())


# Flowchart model
class Flowchart(db.Model):
    FlowchartID = db.Column(db.Integer, primary_key=True)
    FlowchartName = db.Column(db.String(50), nullable=False)
    ProcessName = db.Column(db.String(50), nullable=False)
    IsActive = db.Column(db.Boolean, default=False)
    CreatedBy = db.Column(db.String(50), nullable=False)
    CreatedDateTime = db.Column(db.DateTime, default=datetime.utcnow())


# FlowchartDetails model
class FlowchartDetails(db.Model):
    FlowchartDetailsID = db.Column(db.Integer, primary_key=True)
    FlowchartID = db.Column(db.Integer, nullable=False)
    NodeID = db.Column(db.String(50), nullable=False)
    NodeType = db.Column(db.String(50), nullable=False)
    NodeName = db.Column(db.String(50), nullable=False)
    Description = db.Column(db.String(100), nullable=False)
    NextNodeID = db.Column(db.String(50), nullable=False)


# AuditTrail model
class AuditTrail(db.Model):
    AuditTrailID = db.Column(db.Integer, primary_key=True)
    UserName = db.Column(db.String(50), nullable=False)
    LogName = db.Column(db.String(50), nullable=False)
    Description = db.Column(db.String(100), nullable=False)
    StartTime = db.Column(db.DateTime, nullable=False)
    EndTime = db.Column(db.DateTime, nullable=False)


# Create the database and tables
with app.app_context():
    db.create_all()


@app.route('/', methods=['GET', 'POST'])
def login_base():
    return render_template('login.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email_id = request.form['EmailID']
        password = request.form['Password']
        user = User.query.filter_by(EmailID=email_id, Password=password).first()
        print(user)
        if user:
            if user.IsActive:
                validated_user = User.query.filter_by(UserID=user.UserID).first()
                session['User_Name'] = validated_user.FirstName + ' ' + validated_user.LastName
                session['User_Role'] = validated_user.Role
                return redirect(url_for('dashboard'))
            else:
                flash('User is not active', 'danger')
        else:
            flash('Invalid username or password', 'danger')
    return render_template('login.html')


@app.route('/logout', methods=['GET', 'POST'])
def logout():
    session['User_Name'] = ""
    return render_template('login.html')


@app.route('/user_list', methods=['GET', 'POST'])
def user_list():
    print('user_list function')
    userslist = User.query.all()
    for user in userslist:
        print(user.FirstName)
    return render_template('Users/list.html', users=userslist)


@app.route('/register', methods=['GET', 'POST'])
def register():
    print('in register')
    if request.method == 'POST':
        firstname = request.form['FirstName']
        lastname = request.form['LastName']
        email_id = request.form['EmailID']
        password = request.form['Password']
        process_name = request.form['ProcessName']
        role = request.form['Role']
        is_active = request.form['IsActive']

        if is_active == "Active":
            is_active = True
        else:
            is_active = False

        if 'User_Name' in session:
            created_by = session['User_Name']
        else:
            created_by = "Admin"

        new_user = User(FirstName=firstname, LastName=lastname, EmailID=email_id, Password=password,
                        ProcessName=process_name, Role=role, IsActive=is_active, CreatedBy=created_by)
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('user_list'))

    return render_template('Users/create.html')


@app.route('/edit_user/<int:userid>', methods=['GET', 'POST'])
def edit_user(userid):
    if 'User_ID' in session:
        if request.method == 'POST':
            firstname = request.form['FirstName']
            lastname = request.form['LastName']
            email_id = request.form['EmailID']
            password = request.form['Password']
            process_name = request.form['ProcessName']
            role = request.form['Role']
            is_active = request.form['IsActive']

            if is_active == "Active":
                is_active = True
            else:
                is_active = False

            if 'User_Name' in session:
                created_by = session['User_Name']
            else:
                created_by = "Admin"

            new_user = User(FirstName=firstname, LastName=lastname, EmailID=email_id, Password=password,
                            ProcessName=process_name, Role=role, IsActive=is_active, CreatedBy=created_by)

            return redirect(url_for('user_list'))
        else:
            user = User.query.filter_by(UserID=userid).first()
            return render_template('Users/edit.html', user=user)


@app.route('/delete_user', methods=['POST'])
def delete_user(userid):
    if 'User_ID' in session:
        if request.method == 'POST':
            User.query.delete(UserID=userid)
            return redirect(url_for('user_list'))


@app.route('/dashboard')
def dashboard():
    if 'User_ID' in session:
        return render_template('home.html', username=session["User_ID"])
    return redirect(url_for('login'))


@app.route('/flowchart_list', methods=['GET', 'POST'])
def flowchart_list():
    if 'User_ID' in session:
        flowcharts = Flowchart.query.all()
        return render_template('Flowchart/list.html', flowcharts=flowcharts)


@app.route('/create_flowchart', methods=['GET', 'POST'])
def create_flowchart():
    if request.method == 'POST':
        firstname = request.form['FirstName']
        lastname = request.form['LastName']
        email_id = request.form['EmailID']
        password = request.form['Password']
        process_name = request.form['ProcessName']
        role = request.form['Role']
        is_active = request.form['IsActive']

        if is_active == "Active":
            is_active = True
        else:
            is_active = False

        if 'User_Name' in session:
            created_by = session['User_Name']
        else:
            created_by = "Admin"

        new_user = User(FirstName=firstname, LastName=lastname, EmailID=email_id, Password=password,
                        ProcessName=process_name, Role=role, IsActive=is_active, CreatedBy=created_by)
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('login'))

    return render_template('Flowchart/create.html')


@app.route('/edit_flowchart/<int:flowchart_id>', methods=['GET', 'POST'])
def edit_flowchart(flowchart_id):
    if 'User_ID' in session:
        if request.method == 'POST':
            firstname = request.form['FirstName']
            lastname = request.form['LastName']
            email_id = request.form['EmailID']
            password = request.form['Password']
            process_name = request.form['ProcessName']
            role = request.form['Role']
            is_active = request.form['IsActive']

            if is_active == "Active":
                is_active = True
            else:
                is_active = False

            if 'User_Name' in session:
                created_by = session['User_Name']
            else:
                created_by = "Admin"

            new_user = User(FirstName=firstname, LastName=lastname, EmailID=email_id, Password=password,
                            ProcessName=process_name, Role=role, IsActive=is_active, CreatedBy=created_by)

            return redirect(url_for('flowchart_list'))
        else:
            flowchart = Flowchart.query.filter_by(FlowchartID=flowchart_id).first()
            return render_template('Flowchart/edit.html', flowchart=flowchart)


@app.route('/delete_flowchart', methods=['POST'])
def delete_flowchart(flowchart_id):
    if 'User_ID' in session:
        if request.method == 'POST':
            Flowchart.query.delete(FlowchartID=flowchart_id)
            return redirect(url_for('flowchart_list'))


if __name__ == '__main__':
    app.run(debug=True)
