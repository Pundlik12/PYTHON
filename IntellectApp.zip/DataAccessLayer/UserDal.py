import sqlite3


class ClsUserDal:
    strDatabasePath = ''

    def __init__(self):
        self.strDatabasePath = "C:\\Pundlik\\OneDrive - WNS\\MY_PYTHON_PROJECTS\\IntellectAppFlask\\instance\\IntellectApp.db"

    def get_all(self):
        try:
            conn = sqlite3.connect(self.strDatabasePath)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM User")
            rows = cursor.fetchall()
            users = [dict(row) for row in rows]
            conn.close()
        except Exception as Err:
            print('Error occurred in get_all function from UserDal class\nError:-' + str(Err))
        return users

    def get_by_id(self, user_id):
        try:
            conn = sqlite3.connect(self.strDatabasePath)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM User WHERE UserID = ?", (user_id,))
            rows = cursor.fetchall()
            user = [dict(rows[0])]
            conn.close()
        except Exception as Err:
            print('Error occurred in get_by_id function from UserDal class\nError:-' + str(Err))
        return user

    def validate_user(self, email_id, password):
        try:
            conn = sqlite3.connect(self.strDatabasePath)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM User WHERE EmailID = ? AND Password = ? ", (email_id, password))
            rows = cursor.fetchall()
            if rows:
                user = [dict(rows[0])]
            else:
                user = None
            conn.close()
        except Exception as Err:
            print('Error occurred in get_by_id function from UserDal class\nError:-' + str(Err))
        return user

    def add_user(self, lst_user):
        try:
            conn = sqlite3.connect(self.strDatabasePath)
            cursor = conn.cursor()
            cursor.execute("INSERT INTO User (FirstName,LastName,EmailID,Password,ProcessName,Role,IsActive,CreatedBy) VALUES(?,?,?,?,?,?,?,?)", (lst_user.FirstName, lst_user.LastName, lst_user.EmailID, lst_user.Password, lst_user.ProcessName, lst_user.Role, lst_user.IsActive, lst_user.CreatedBy))
            conn.commit()
            conn.close()
        except Exception as Err:
            print('Error occurred in add_user function from UserDal class\nError:-' + str(Err))
            return False
        return True

    def update_user(self, user_id, lst_user):
        try:
            conn = sqlite3.connect(self.strDatabasePath)
            cursor = conn.cursor()
            cursor.execute("UPDATE User SET FirstName=?,LastName=?,EmailID=?,Password=?,ProcessName=?,Role=?,IsActive=?,CreatedBy=? WHERE UserID =?", (lst_user.FirstName, lst_user.LastName, lst_user.EmailID, lst_user.Password, lst_user.ProcessName, lst_user.Role, lst_user.IsActive, lst_user.CreatedBy, lst_user.UserID))
            conn.commit()
            conn.close()
        except Exception as Err:
            print('Error occurred in update_user function from UserDal class\nError:-' + str(Err))
            return False
        return True

    def delete_user(self, user_id):
        try:
            conn = sqlite3.connect(self.strDatabasePath)
            cursor = conn.cursor()
            cursor.execute("DELETE * FROM User WHERE UserID = ?", user_id)
            conn.commit()
            conn.close()
        except Exception as Err:
            print('Error occurred in delete_user function from UserDal class\nError:-' + str(Err))
            return False
        return True
