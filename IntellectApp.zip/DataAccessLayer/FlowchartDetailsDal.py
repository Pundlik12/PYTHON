import sqlite3


class ClsFlowchartDetailsDal:
    strDatabasePath = ''

    def __init__(self):
        self.strDatabasePath = "C:\\Pundlik\\OneDrive - WNS\\MY_PYTHON_PROJECTS\\IntellectAppFlask\\instance\\IntellectApp.db"

    def get_all(self):
        try:
            conn = sqlite3.connect(self.strDatabasePath)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM Flowchart_Details")
            rows = cursor.fetchall()
            flowcharts = [dict(row) for row in rows]
            conn.close()
        except Exception as Err:
            print('Error occurred in get_all function from ClsFlowchartDal class\nError:-' + str(Err))
        return flowcharts

    def get_by_flowchart_id(self, flowchart_id):
        try:
            conn = sqlite3.connect(self.strDatabasePath)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()

            str_query = ""
            str_query = str_query + "SELECT parent.FlowchartDetailsID, parent.FlowchartID, parent.NodeID, parent.NodeType, parent.NodeName, parent.Description, parent.NextNodeID\n"
            str_query = str_query + ",child.FlowchartDetailsID as NextFlowchartDetailsID, child.FlowchartID as NextFlowchartID, child.NodeID as NextNodeID, child.NodeType as NextNodeType, child.NodeName as NextNodeName, child.Description as NextDescription, child.NextNodeID as NextNextNodeID\n"
            str_query = str_query + "FROM Flowchart_Details as parent\n"
            str_query = str_query + "INNER JOIN Flowchart_Details as child\n"
            str_query = str_query + "on parent.NextNodeID = child.NodeID \n"
            str_query = str_query + "WHERE parent.FlowchartID = ?\n"

            cursor.execute(str_query, (flowchart_id,))

            # cursor.execute("SELECT * FROM Flowchart_Details WHERE FlowchartID = ?", (flowchart_id,))
            rows = cursor.fetchall()
            if rows:
                flowchart = [dict(row) for row in rows]
            else:
                flowchart = None

            # cursor.execute("DELETE FROM Flowchart_Details")
            # conn.commit()
            conn.close()
        except Exception as Err:
            flowchart = None
            print('Error occurred in get_by_id function from ClsFlowchartDal class Error:-' + str(Err))
        return flowchart

    def add_flowchart_steps(self, flowchart_details):
        try:
            conn = sqlite3.connect(self.strDatabasePath)
            cursor = conn.cursor()
            cursor.execute("INSERT INTO Flowchart_Details (FlowchartID,NodeID,NodeType,NodeName,Description,NextNodeID) VALUES(?,?,?,?,?,?)", (flowchart_details.FlowchartID, flowchart_details.NodeID, flowchart_details.NodeType, flowchart_details.NodeName, flowchart_details.Description, flowchart_details.NextNodeID))
            conn.commit()
            conn.close()
        except Exception as Err:
            print('Error occurred in add_flowchart_steps function from ClsFlowchartDal class\nError:-' + str(Err))
            return False
        return True

    def update_flowchart_steps(self, flowchart_steps):
        try:
            conn = sqlite3.connect(self.strDatabasePath)
            cursor = conn.cursor()
            cursor.execute("UPDATE Flowchart_Details SET NodeID=?, NodeType=?, NodeName=?, Description=?, NextNodeID=? WHERE FlowchartDetailsID = ?", (flowchart_steps.NodeID, flowchart_steps.NodeType, flowchart_steps.NodeName, flowchart_steps.Description, flowchart_steps.NextNodeID, flowchart_steps.FlowchartDetailsID))
            conn.commit()
            conn.close()
        except Exception as Err:
            print('Error occurred in update_flowchart_steps function from ClsFlowchartDal class\nError:-' + str(Err))
            return False
        return True

    def delete_flowchart_steps(self, flowchart_details_id):
        try:
            conn = sqlite3.connect(self.strDatabasePath)
            cursor = conn.cursor()
            cursor.execute("DELETE FROM Flowchart_Details WHERE FlowchartDetailsID = ", flowchart_details_id)
            conn.commit()
            conn.close()
        except Exception as Err:
            print('Error occurred in delete_flowchart_steps function from ClsFlowchartDal class\nError:-' + str(Err))
            return False
        return True
