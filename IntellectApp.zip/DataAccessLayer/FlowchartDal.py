import sqlite3


class ClsFlowchartDal:
    strDatabasePath = ''

    def __init__(self):
        self.strDatabasePath = "C:\\Pundlik\\OneDrive - WNS\\MY_PYTHON_PROJECTS\\IntellectAppFlask\\instance\\IntellectApp.db"

    def get_all(self):
        try:
            conn = sqlite3.connect(self.strDatabasePath)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM Flowchart")
            rows = cursor.fetchall()
            flowcharts = [dict(row) for row in rows]
            conn.close()
        except Exception as Err:
            print('Error occurred in get_all function from ClsFlowchartDal class\nError:-' + str(Err))
        return flowcharts

    def get_by_id(self, flowchart_id):
        try:
            conn = sqlite3.connect(self.strDatabasePath)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM Flowchart WHERE FlowchartID = ?", (flowchart_id,))
            rows = cursor.fetchall()
            flowchart = [dict(rows[0])]
            conn.close()
        except Exception as Err:
            print('Error occurred in get_by_id function from ClsFlowchartDal class Error:-' + str(Err))
        return flowchart

    def add_flowchart(self, lst_flowchart):
        try:
            conn = sqlite3.connect(self.strDatabasePath)
            cursor = conn.cursor()
            cursor.execute("INSERT INTO Flowchart (FlowchartName,ProcessName,IsActive,CreatedBy) VALUES(?,?,?,?)", (lst_flowchart.FlowchartName, lst_flowchart.ProcessName, lst_flowchart.IsActive, lst_flowchart.CreatedBy))
            conn.commit()
            conn.close()
        except Exception as Err:
            print('Error occurred in add_flowchart function from ClsFlowchartDal class\nError:-' + str(Err))
            return False
        return True

    def update_flowchart(self, flowchart_id, lst_flowchart):
        try:
            conn = sqlite3.connect(self.strDatabasePath)
            cursor = conn.cursor()
            cursor.execute("UPDATE Flowchart SET FlowchartName=?,ProcessName=?,IsActive=?,CreatedBy=? WHERE FlowchartID = ?", (lst_flowchart.FlowchartName, lst_flowchart.ProcessName, lst_flowchart.IsActive, lst_flowchart.CreatedBy, lst_flowchart.FlowchartID))
            conn.commit()
            conn.close()
        except Exception as Err:
            print('Error occurred in update_flowchart function from ClsFlowchartDal class\nError:-' + str(Err))
            return False
        return True

    def delete_flowchart(self, flowchart_id):
        try:
            conn = sqlite3.connect(self.strDatabasePath)
            cursor = conn.cursor()
            cursor.execute("DELETE * FROM Flowchart WHERE FlowchartID = ", flowchart_id)
            conn.commit()
            conn.close()
        except Exception as Err:
            print('Error occurred in delete_flowchart function from ClsFlowchartDal class\nError:-' + str(Err))
            return False
        return True
