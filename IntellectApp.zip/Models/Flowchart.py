
class FlowchartModel:
    FlowchartID = ""
    FlowchartName = ""
    ProcessName = ""
    IsActive = False
    CreatedBy = ""
    CreatedDateTime = ""

    def __init__(self):
        self.FlowchartID = ""
        self.FlowchartName = ""
        self.ProcessName = ""
        self.IsActive = False
        self.CreatedBy = ""
        self.CreatedDateTime = ""
