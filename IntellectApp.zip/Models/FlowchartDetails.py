
class FlowchartDetailsModel:
    FlowchartDetailsID = ""
    FlowchartID = ""
    NodeID = ""
    NodeType = ""
    NodeName = ""
    Description = ""
    NextNodeID = ""

    def __init__(self):
        self.FlowchartDetailsID = ""
        self.FlowchartID = ""
        self.NodeID = ""
        self.NodeType = ""
        self.NodeName = ""
        self.Description = ""
        self.NextNodeID = ""
