
class UserModel:
    UserID = ""
    FirstName = ""
    LastName = ""
    EmailID = ""
    Password = ""
    ProcessName = ""
    Role = ""
    IsActive = False
    CreatedBy = ""
    CreatedDateTime = ""

    def __init__(self):
        self.UserID = ""
        self.FirstName = ""
        self.LastName = ""
        self.EmailID = ""
        self.Password = ""
        self.ProcessName = ""
        self.Role = ""
        self.IsActive = True
        self.CreatedBy = ""
        self.CreatedDateTime = ""
