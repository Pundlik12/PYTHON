from flask import Flask, render_template, request, redirect, url_for, session, flash
from DataAccessLayer.UserDal import ClsUserDal
from DataAccessLayer.FlowchartDal import ClsFlowchartDal
from Models.User import UserModel


app = Flask(__name__)
app.secret_key = 'App@123'

ObjUserDal = ClsUserDal()
ObjFlowchartDal = ClsFlowchartDal()


# @app.route('/', methods=['GET', 'POST'])
# def login_base():
#     return redirect(url_for('login'))


@app.route('/', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        email_id = request.form['EmailID']
        password = request.form['Password']
        users = ObjUserDal.validate_user(email_id.upper(), password)
        if users is not None:
            user = users[0]
            if int(user["IsActive"]) == 1:
                session['User_ID'] = user["UserID"]
                session['User_Name'] = user["FirstName"] + ' ' + user["LastName"]
                session['User_Role'] = user["Role"]
                return redirect(url_for('dashboard'))
            else:
                error = 'User is not active'
        else:
            error = 'Invalid username or password'
    return render_template('login.html', error=error)


@app.route('/logout', methods=['GET', 'POST'])
def logout():
    session['User_ID'] = ""
    session['User_Name'] = ""
    session['User_Role'] = ""
    return redirect(url_for('login'))


@app.route('/user_list', methods=['GET', 'POST'])
def user_list():
    if 'User_ID' in session:
        users = ObjUserDal.get_all()
        return render_template('Users/list.html', users=users)
    return redirect(url_for('login'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    if 'User_ID' in session:
        if request.method == 'POST':
            firstname = request.form['FirstName']
            lastname = request.form['LastName']
            email_id = request.form['EmailID']
            password = request.form['Password']
            process_name = request.form['ProcessName']
            role = request.form['Role']
            is_active = request.form['IsActive']

            if is_active == "Active":
                is_active = True
            else:
                is_active = False

            if 'User_Name' in session:
                created_by = session['User_Name']
            else:
                created_by = "Admin"

            user_model = UserModel()
            user_model.FirstName = firstname.upper()
            user_model.LastName = lastname.upper()
            user_model.EmailID = email_id.upper()
            user_model.Password = password
            user_model.ProcessName = process_name
            user_model.Role = role
            user_model.IsActive = is_active
            user_model.CreatedBy = created_by

            ObjUserDal.add_user(user_model)

            return redirect(url_for('user_list'))

        return render_template('Users/create.html')
    return redirect(url_for('login'))


@app.route('/edit_user/<int:userid>', methods=['GET', 'POST'])
def edit_user(userid):
    if 'User_ID' in session:
        if request.method == 'POST':
            userid = request.form['UserId']
            firstname = request.form['FirstName']
            lastname = request.form['LastName']
            email_id = request.form['EmailID']
            password = request.form['Password']
            process_name = request.form['ProcessName']
            role = request.form['Role']
            is_active = request.form['IsActive']

            if is_active == "Active":
                is_active = True
            else:
                is_active = False

            if 'User_Name' in session:
                created_by = session['User_Name']
            else:
                created_by = "Admin"

            user_model = UserModel()
            user_model.UserID = userid
            user_model.FirstName = firstname.upper()
            user_model.LastName = lastname.upper()
            user_model.EmailID = email_id.upper()
            user_model.Password = password
            user_model.ProcessName = process_name
            user_model.Role = role
            user_model.IsActive = is_active
            user_model.CreatedBy = created_by

            ObjUserDal.update_user(userid, user_model)

            return redirect(url_for('user_list'))
        else:
            user = ObjUserDal.get_by_id(userid)
            return render_template('Users/edit.html', user=user)


@app.route('/delete_user/<int:userid>', methods=['POST'])
def delete_user(userid):
    # if 'User_ID' in session:
    print('In delete method..')
    ObjUserDal.delete_user(userid)
    return redirect(url_for('user_list'))
    # return redirect(url_for('login'))


@app.route('/dashboard')
def dashboard():
    if 'User_ID' in session:
        print(session["User_ID"])
        if session["User_ID"] != "":
            return render_template('home.html', username=session["User_ID"])
    return redirect(url_for('login'))


@app.route('/flowchart_list', methods=['GET', 'POST'])
def flowchart_list():
    if 'User_ID' in session:
        flowcharts = ObjFlowchartDal.get_all()
        return render_template('Flowchart/list.html', flowcharts=flowcharts)
    return redirect(url_for('login'))


@app.route('/create_flowchart', methods=['GET', 'POST'])
def create_flowchart():
    if 'User_ID' in session:
        if request.method == 'POST':
            flowchart_name = request.form['FlowchartName']
            process_name = request.form['ProcessName']
            is_active = request.form['IsActive']

            if is_active == "Active":
                is_active = True
            else:
                is_active = False

            if 'User_Name' in session:
                created_by = session['User_Name']
            else:
                created_by = "Admin"

            flowchart = {"FlowchartName": flowchart_name, "ProcessName": process_name, "IsActive": is_active, "CreatedBy": created_by}
            ObjFlowchartDal.add_flowchart(flowchart)

            return redirect(url_for('flowchart_list'))

        return render_template('Flowchart/create.html')
    return redirect(url_for('login'))


@app.route('/edit_flowchart/<int:flowchart_id>', methods=['GET', 'POST'])
def edit_flowchart(flowchart_id):
    if 'User_ID' in session:
        if request.method == 'POST':
            flowchart_name = request.form['FlowchartName']
            process_name = request.form['ProcessName']
            is_active = request.form['IsActive']

            if is_active == "Active":
                is_active = True
            else:
                is_active = False

            if 'User_Name' in session:
                created_by = session['User_Name']
            else:
                created_by = "Admin"

            flowchart_id = 0
            flowchart = {"FlowchartID": flowchart_id, "FlowchartName": flowchart_name, "ProcessName": process_name, "IsActive": is_active, "CreatedBy": created_by}
            ObjFlowchartDal.update_flowchart(flowchart)

            return redirect(url_for('flowchart_list'))
        else:
            flowchart = ObjFlowchartDal.get_by_id(flowchart_id)
            return render_template('Flowchart/edit.html', flowchart=flowchart)
    return redirect(url_for('login'))


@app.route('/delete_flowchart', methods=['POST'])
def delete_flowchart(flowchart_id):
    if 'User_ID' in session:
        if request.method == 'POST':
            ObjFlowchartDal.delete_flowchart(flowchart_id)
            return redirect(url_for('flowchart_list'))
    return redirect(url_for('login'))


if __name__ == '__main__':
    app.run(debug=True)
