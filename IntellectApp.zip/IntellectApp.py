from flask import Flask, render_template, request, redirect, url_for, session, flash
from DataAccessLayer.UserDal import ClsUserDal
from DataAccessLayer.FlowchartDal import ClsFlowchartDal
from DataAccessLayer.FlowchartDetailsDal import ClsFlowchartDetailsDal
from Models.User import UserModel
from Models.Flowchart import FlowchartModel
from Models.FlowchartDetails import FlowchartDetailsModel

app = Flask(__name__)
app.secret_key = 'App@123'

ObjUserDal = ClsUserDal()
ObjFlowchartDal = ClsFlowchartDal()
ObjFlowchartDetailsDal = ClsFlowchartDetailsDal()


@app.route('/', methods=['GET', 'POST'])
def login():
    error = None
    session['User_ID'] = ""
    session['User_Name'] = ""
    session['User_Role'] = ""
    if request.method == 'POST':
        email_id = request.form['EmailID']
        password = request.form['Password']
        users = ObjUserDal.validate_user(email_id.upper(), password)
        if users is not None:
            user = users[0]
            if int(user["IsActive"]) == 1:
                session['User_ID'] = user["UserID"]
                session['User_Name'] = user["FirstName"] + ' ' + user["LastName"]
                session['User_Role'] = user["Role"]
                return redirect(url_for('home'))
            else:
                error = 'User is not active'
        else:
            error = 'Invalid username or password'
    return render_template('login.html', error=error)


@app.route('/logout', methods=['GET', 'POST'])
def logout():
    session['User_ID'] = ""
    session['User_Name'] = ""
    session['User_Role'] = ""
    return redirect(url_for('login'))


@app.route('/user_list', methods=['GET', 'POST'])
def user_list():
    if 'User_ID' in session:
        users = ObjUserDal.get_all()
        return render_template('Users/list.html', users=users)
    return redirect(url_for('login'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    if 'User_ID' in session:
        if session['User_ID'] != "":
            if request.method == 'POST':
                firstname = request.form['FirstName']
                lastname = request.form['LastName']
                email_id = request.form['EmailID']
                password = request.form['Password']
                process_name = request.form['ProcessName']
                role = request.form['Role']
                is_active = request.form['IsActive']

                if is_active == "Active":
                    is_active = True
                else:
                    is_active = False

                if 'User_Name' in session:
                    created_by = session['User_Name']
                else:
                    created_by = "Admin"

                user_model = UserModel()
                user_model.FirstName = firstname.upper()
                user_model.LastName = lastname.upper()
                user_model.EmailID = email_id.upper()
                user_model.Password = password
                user_model.ProcessName = process_name
                user_model.Role = role
                user_model.IsActive = is_active
                user_model.CreatedBy = created_by

                ObjUserDal.add_user(user_model)

                return redirect(url_for('user_list'))

            return render_template('Users/create.html')
    return redirect(url_for('login'))


@app.route('/edit_user/<int:userid>', methods=['GET', 'POST'])
def edit_user(userid):
    if 'User_ID' in session:
        if request.method == 'POST':
            userid = request.form['UserId']
            firstname = request.form['FirstName']
            lastname = request.form['LastName']
            email_id = request.form['EmailID']
            password = request.form['Password']
            process_name = request.form['ProcessName']
            role = request.form['Role']
            is_active = request.form['IsActive']

            if is_active == "Active":
                is_active = True
            else:
                is_active = False

            if 'User_Name' in session:
                created_by = session['User_Name']
            else:
                created_by = "Admin"

            user_model = UserModel()
            user_model.UserID = userid
            user_model.FirstName = firstname.upper()
            user_model.LastName = lastname.upper()
            user_model.EmailID = email_id.upper()
            user_model.Password = password
            user_model.ProcessName = process_name
            user_model.Role = role
            user_model.IsActive = is_active
            user_model.CreatedBy = created_by

            ObjUserDal.update_user(userid, user_model)

            return redirect(url_for('user_list'))
        else:
            user = ObjUserDal.get_by_id(userid)
            return render_template('Users/edit.html', user=user)


@app.route('/delete_user/<int:userid>', methods=['POST'])
def delete_user(userid):
    # if 'User_ID' in session:
    print('In delete method..')
    ObjUserDal.delete_user(userid)
    return redirect(url_for('user_list'))
    # return redirect(url_for('login'))


@app.route('/change_password', methods=['GET', 'POST'])
def change_password():
    if 'User_ID' in session:
        if request.method == 'POST':
            password = request.form['Password']
            confirm_password = request.form['ConfirmPassword']
            is_active = request.form['IsActive']

            # user_model = UserModel()
            # user_model.FlowchartName = flowchart_name
            # user_model.ProcessName = process_name
            # user_model.IsActive = is_active
            # user_model.CreatedBy = created_by

            # ObjFlowchartDal.add_user(user_model)

            return redirect(url_for('user_list'))

        return render_template('User/change_password.html')
    return redirect(url_for('login'))


@app.route('/home')
def home():
    if 'User_ID' in session:
        if session["User_ID"] != "":
            # return render_template('home.html', username=session["User_ID"])
            return render_template('home.html')
    return redirect(url_for('login'))


@app.route('/flowchart_list', methods=['GET', 'POST'])
def flowchart_list():
    if 'User_ID' in session:
        flowcharts = ObjFlowchartDal.get_all()
        return render_template('Flowchart/list.html', flowcharts=flowcharts)
    return redirect(url_for('login'))


@app.route('/create_flowchart', methods=['GET', 'POST'])
def create_flowchart():
    if 'User_ID' in session:
        if request.method == 'POST':
            flowchart_name = request.form['FlowchartName']
            process_name = request.form['ProcessName']
            is_active = request.form['IsActive']

            if is_active == "Active":
                is_active = True
            else:
                is_active = False

            if 'User_Name' in session:
                created_by = session['User_Name']
            else:
                created_by = "Admin"

            flowchart_model = FlowchartModel()
            flowchart_model.FlowchartName = flowchart_name
            flowchart_model.ProcessName = process_name
            flowchart_model.IsActive = is_active
            flowchart_model.CreatedBy = created_by

            ObjFlowchartDal.add_flowchart(flowchart_model)

            return redirect(url_for('flowchart_list'))

        return render_template('Flowchart/create.html')
    return redirect(url_for('login'))


@app.route('/edit_flowchart/<int:flowchart_id>', methods=['GET', 'POST'])
def edit_flowchart(flowchart_id):
    if 'User_ID' in session:
        if request.method == 'POST':
            flowchart_name = request.form['FlowchartName']
            process_name = request.form['ProcessName']
            is_active = request.form['IsActive']

            if is_active == "Active":
                is_active = True
            else:
                is_active = False

            if 'User_Name' in session:
                created_by = session['User_Name']
            else:
                created_by = "Admin"

            flowchart_model = FlowchartModel()
            flowchart_model.FlowchartID = flowchart_id
            flowchart_model.FlowchartName = flowchart_name
            flowchart_model.ProcessName = process_name
            flowchart_model.IsActive = is_active
            flowchart_model.CreatedBy = created_by

            ObjFlowchartDal.update_flowchart(flowchart_id, flowchart_model)

            return redirect(url_for('flowchart_list'))
        else:
            flowchart = ObjFlowchartDal.get_by_id(flowchart_id)
            return render_template('Flowchart/edit.html', flowchart=flowchart)
    return redirect(url_for('login'))


@app.route('/delete_flowchart/<int:flowchart_id>', methods=['POST'])
def delete_flowchart(flowchart_id):
    if 'User_ID' in session:
        if request.method == 'POST':
            ObjFlowchartDal.delete_flowchart(flowchart_id)
            return redirect(url_for('flowchart_list'))
    return redirect(url_for('login'))


@app.route('/flowchart/<int:flowchart_id>', methods=['GET', 'POST'])
def flowchart(flowchart_id):
    if 'User_ID' in session:
        if request.method == 'POST':
            flowchart_steps = FlowchartDetailsModel()
            flowchart_steps.FlowchartDetailsID = 0
            flowchart_steps.FlowchartID = flowchart_id
            flowchart_steps.NodeID = request.form['NodeID']
            flowchart_steps.NodeType = request.form['NodeType']
            flowchart_steps.NodeName = request.form['NodeName']
            flowchart_steps.Description = request.form['Description']
            flowchart_steps.NextNodeID = request.form['NextNodeID']

            ObjFlowchartDetailsDal.add_flowchart_steps(flowchart_steps)

        flowchart_details = ObjFlowchartDetailsDal.get_by_flowchart_id(flowchart_id)
        if flowchart_details is not None:
            mermaid_syntax_string = generate_mermaid_syntax(flowchart_details)
            table_syntax_string = generate_table_syntax(flowchart_details)
        else:
            mermaid_syntax_string = ""
            table_syntax_string = ""
        print(f"mermaid_syntax: -{mermaid_syntax_string}")
        print(f"table_syntax: - {table_syntax_string}")
        return render_template('Flowchart/flowchart.html', flowchart_details=flowchart_details,
                               mermaid_syntax=mermaid_syntax_string, table_syntax=table_syntax_string)


def generate_table_syntax(items):
    rows = []
    for item in items:
        str_table_row = f"""<tr><td>Edit</td><td>Delete</td><td>{item["FlowchartDetailsID"]}</td><td>{item["FlowchartID"]}</td><td>{item["NodeID"]}</td><td>{item["NodeType"]}</td><td>{item["NodeName"]}</td><td>{item["Description"]}</td><td>{item["NextNodeID"]}</td></tr>"""
        rows.append(str_table_row)

    return "\n".join(rows)


def generate_mermaid_syntax(items):
    nodes = []
    links = []
    nodes.append('graph TD;')
    print(f'items: - {items}')

    for item in items:
        str_node_text = ""

        if item['NodeID'] != "":
            str_node_text = item['NodeID']

        if item['NodeType'] == "Decision":
            str_node_text = str_node_text + "{"
        elif item['NodeType'] == "Input":
            str_node_text = str_node_text + "["
        elif item['NodeType'] == "Processing":
            str_node_text = str_node_text + "("

        if item['NodeName'] != "":
            str_node_text = str_node_text + "" + item['NodeName']

        if item['NodeType'] == "Decision":
            str_node_text = str_node_text + "}"
        elif item['NodeType'] == "Input":
            str_node_text = str_node_text + "]"
        elif item['NodeType'] == "Processing":
            str_node_text = str_node_text + ")"

        str_node_text = str_node_text + "-->"

        if item['Description'] != "":
            str_node_text = str_node_text + "|" + item['Description'] + "|"

        if item['NextNodeID'] != "":
            str_node_text = str_node_text + "" + item['NextNodeID']

        if item['NextNodeType'] == "Decision":
            str_node_text = str_node_text + "{"
        elif item['NextNodeType'] == "Input":
            str_node_text = str_node_text + "["
        elif item['NextNodeType'] == "Processing":
            str_node_text = str_node_text + "("

        if item['NextNodeName'] != "":
            str_node_text = str_node_text + "" + item['NextNodeName']

        if item['NextNodeType'] == "Decision":
            str_node_text = str_node_text + "}"
        elif item['NextNodeType'] == "Input":
            str_node_text = str_node_text + "]"
        elif item['NextNodeType'] == "Processing":
            str_node_text = str_node_text + ")"

        nodes.append(str_node_text)

        # nodes.append(f"{item['FlowchartDetailsID']}[{item['NodeName']}]")
        # if item['FlowchartDetailsID'] > 1:
        #     links.append(f"{item['FlowchartDetailsID'] - 1} --> {item['NodeName']}")

    return "\n".join(nodes)


if __name__ == '__main__':
    app.run(debug=True)
