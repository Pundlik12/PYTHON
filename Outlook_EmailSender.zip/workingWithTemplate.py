import os
import win32com.client as win32
import tkinter as tk
from tkinter import messagebox
from tkinter import scrolledtext


def convert_to_table(text):
    rows = text.splitlines()
    table = "<table border='1' cellpadding='5' cellspacing='0' style='border-collapse: collapse;'>"
    for row in rows:
        table += "<tr>"
        for col in row.split():
            table += f"<td>{col}</td>"
        table += "</tr>"
    table += "</table>"
    return table


def send_email(to_email, subject, body):
    try:
        outlook = win32.Dispatch('Outlook.Application')
        template_File = os.getcwd() + r'\emailTemplate\Mode Special Handling New.oft'
        mail = outlook.CreateItemFromTemplate(template_File)

        mail.To = to_email
        mail.Subject = subject
        greeting = "<p>Hi,</p><p>Please see attached invoice(s) #</p>"

        table_body = convert_to_table(body)
        mail.HTMLBody = greeting + table_body + mail.HTMLBody

        mail.Display()
        messagebox.showinfo("Success", "Email Created Successfully!")
    except Exception as e:
        messagebox.showerror("Error", str(e))


def create_ui():
    window = tk.Tk()
    window.title("Outlook Email Sender")

    tk.Label(window, text="To:").grid(row=1, column=0, padx=10, pady=5)
    to_entry = tk.Entry(window, width=50)
    to_entry.grid(row=1, column=1, padx=10, pady=5)

    tk.Label(window, text="Subject:").grid(row=2, column=0, padx=10, pady=5)
    subject_entry = tk.Entry(window, width=50)
    subject_entry.grid(row=2, column=1, padx=10, pady=5)

    tk.Label(window, text="Body:").grid(row=3, column=0, padx=10, pady=5)
    body_entry = scrolledtext.ScrolledText(window, width=50, height=10)
    body_entry.grid(row=3, column=1, padx=10, pady=5)

    send_button = tk.Button(window, text="Send Email", command=lambda: send_email(
        to_entry.get(),
        subject_entry.get(),
        body_entry.get("1.0", tk.END)
    ))
    send_button.grid(row=4, column=1, padx=10, pady=10)

    window.mainloop()


create_ui()
