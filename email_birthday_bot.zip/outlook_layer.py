import os
import pandas
import random
import logging
import win32com.client
from datetime import datetime

# Configure logging
logging.basicConfig(
    filename='logfile.txt',  # Name of the log file
    filemode='a',            # Append mode ('w' for overwrite)
    format='%(asctime)s - %(levelname)s - %(message)s',  # Log format
    level=logging.INFO       # Log level
)


def read_file_and_send_email():
    try:
        file_path = 'birthdays.csv'
        if not os.path.exists(file_path):
            logging.warning(f"{file_path} file not exists!")
        else:
            today = datetime.now()
            today_tuple = (today.month, today.day)

            data = pandas.read_csv(file_path)

            birthdays_dict = {(data_row["month"], data_row["day"]): data_row for (index, data_row) in data.iterrows()}

            if today_tuple in birthdays_dict:
                birthday_person = birthdays_dict[today_tuple]

                file_path = f"letter_templates/letter_{random.randint(1, 3)}.txt"
                if not os.path.exists(file_path):
                    logging.warning(f"{file_path} file not exists!")
                else:
                    with open(file_path) as letter_file:
                        contents = letter_file.read()
                        contents = contents.replace("[NAME]", birthday_person["name"])

                    if contents != "":
                        str_to_email_address = str(birthday_person["email"])
                        str_cc_email_address = ""
                        str_bcc_email_address = ""

                        file_path = "RecipientsList.xlsx"
                        if os.path.exists(file_path):
                            df = pandas.read_excel(file_path)
                            for index, row in df.iterrows():
                                if str(row['EmailAddress']).strip().upper() != str_to_email_address.strip().upper():
                                    str_cc_email_address = str_cc_email_address + str(row['EmailAddress']) + "; "
                        else:
                            logging.warning(f"{file_path} file not exists!")

                        str_subject_line = "Happy Birthday " + str(birthday_person["name"]) + " - Auto Mailer"
                        str_body = contents
                        lst_attachments = []

                        send_email_via_outlook(str_to_email_address, str_cc_email_address, str_bcc_email_address,
                                               str_subject_line,
                                               str_body, lst_attachments)

                        logging.info("Email send.")

        logging.info("Attempted birthday email.")
    except Exception as ex:
        logging.error(f'Error occurred in read_file_and_send_email function:-\n' + str(ex))


def send_email_via_outlook(str_to_email_address, str_cc_email_address, str_bcc_email_address, str_subject_line, str_body, lst_attachments):
    try:
        outlook = win32com.client.Dispatch("Outlook.Application")

        mail = outlook.CreateItem(0)
        mail.To = str_to_email_address

        if str_cc_email_address != "":
            mail.CC = str_cc_email_address

        if str_bcc_email_address != "":
            mail.BCC = str_bcc_email_address

        mail.Subject = str_subject_line
        mail.Body = str_body

        if len(lst_attachments) > 0:
            for attachment in lst_attachments:
                mail.Attachments.Add(str(attachment))

        mail.Send()
        return True
    except Exception as ex:
        logging.error(f'Error occurred in send_email_via_outlook function:-\n' + str(ex))
        return False
