import os
import frmUserForm
from datetime import date
from tkinter import messagebox


def validate_form():
    icon_path = os.getcwd() + r"\Images\cloud.ico"
    if os.path.isfile(icon_path) is False:
        messagebox.showinfo("PDF Data Extractor", "Images folder is missing in startup path.")
        exit()


def check_expiry():
    expiry_date = date(2025, 4, 30)
    if expiry_date < date.today():
        messagebox.showinfo("PDF Data Extractor",
                            "The application has been expired please contact the WFM team for renewal")
        exit()
    else:
        validate_form()
        frmUserForm.UserForm()


check_expiry()
