import os
import cv2
import fitz
import pytesseract
import pandas as pd
import openpyxl
from tkinter import messagebox
from openpyxl.utils.dataframe import dataframe_to_rows


def convert_pdf_to_image(str_pdf_folder_path):
    tesseract_ocr_path = os.path.join(os.getcwd(), "Tesseract-OCR\\tesseract.exe")
    is_exist = os.path.isfile(tesseract_ocr_path)
    if not is_exist:
        messagebox.showinfo("PDF Data Extractor", "Tesseract-OCR engine is not configured.")
    else:
        pytesseract.pytesseract.tesseract_cmd = tesseract_ocr_path
        pdf_counter = 0
        for filename in os.listdir(str_pdf_folder_path):
            if not filename.lower().endswith(".pdf"):
                continue

            fullpath = os.path.join(str_pdf_folder_path, filename)
            if os.path.isfile(fullpath):
                pdf_counter = pdf_counter + 1
                dpi = 300
                zoom = dpi / 75
                magnify = fitz.Matrix(zoom, zoom)
                doc = fitz.open(fullpath)

                page_counter = 1
                for page in doc:
                    pix = page.get_pixmap(matrix=magnify)
                    page_file_name = filename.upper().replace(".PDF", "") + "_PAGE" + str(page_counter) + ".JPEG"
                    full_image_path = os.path.join(str_pdf_folder_path, page_file_name)
                    pix.save(full_image_path)

                    extract_text(full_image_path)
                    page_counter = page_counter + 1

        if pdf_counter > 0:
            convert_text_to_excel(str_pdf_folder_path)
            messagebox.showinfo("PDF Data Extractor", "Pdf data extraction process completed.")
        else:
            messagebox.showinfo("PDF Data Extractor", "pdf files(s) doesnt found in selected folder.")


def extract_text(original_image_path):
    try:
        image = cv2.imread(original_image_path)
        # convert the image to black and white for better OCR
        ret, thresh1 = cv2.threshold(image, 120, 255, cv2.THRESH_BINARY)

        # pytesseract image to string to get results
        text = str(pytesseract.image_to_string(thresh1, config='--psm 6'))
        text = text.replace('\n\n', '\n')
        # print(f"Extracted text:- {text}")

        text_file_path = str(original_image_path.split('_PAGE')[0]) + ".TXT"
        write_output_to_text(text_file_path, text)
    except Exception as Error:
        print(f"Error occurred in extract_text function\n{Error}")


def write_output_to_text(file_path, text_to_write):
    try:
        write_file = open(file_path, "a")
        write_file.write(text_to_write)
        write_file.close()
    except Exception as Error:
        print(f"Error occurred in Write_output_to_text function\n{Error}")


def convert_text_to_excel(input_path):
    try:
        # List all text files in the directory
        txt_files = [f for f in os.listdir(input_path) if f.endswith('.TXT')]

        for txt_file in txt_files:
            # Read each line from the text file and split it into columns
            with open(os.path.join(input_path, txt_file), 'r') as file:
                lines = file.readlines()
                data = [line.strip().split(' ') for line in lines]  # Adjust the delimiter if needed

            df = pd.DataFrame(data)
            # Write the DataFrame to a separate sheet in the Excel file
            sheet_name = os.path.splitext(txt_file)[0]
            workbook = openpyxl.Workbook()

            sheet = workbook.create_sheet(title=sheet_name)
            for row in dataframe_to_rows(df, index=False, header=True):
                sheet.append(row)

            workbook.remove_sheet(workbook['Sheet'])
            output_file_path = os.path.join(input_path, sheet_name + '.xlsx')
            workbook.save(filename=output_file_path)
    except Exception as Error:
        print(f'Error occurred in convert_text_to_excel function\n{Error}')
