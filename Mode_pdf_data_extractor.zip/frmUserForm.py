import os
import shutil
import tkinter
from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
from tkinter.messagebox import askyesno
import Pdf_To_Image


class UserForm:

    def __init__(self):
        self.vendor_selected = ""
        self.root = tkinter.Tk()
        # use to hide tkinter window
        # root.withdraw()

        self.root.title('PDF Data Extractor')
        self.root.resizable(width=NO, height=NO)
        self.root.iconbitmap(os.getcwd() + r"\Images\cloud.ico")
        # self.root.state('zoomed')

        # Calculate the screen dimensions
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()

        # Calculate the window dimensions
        window_width = 920
        window_height = 300

        # Calculate the window position
        x = (screen_width - window_width) // 2
        y = (screen_height - window_height) // 2

        # Set the window size and position
        self.root.geometry(f"{window_width}x{window_height}+{x}+{y}")

        # start_width = root.winfo_screenwidth() % 50
        # start_height = root.winfo_screenheight() % 50
        # root.geometry(f"{start_width}x{start_height}")

        top_frame = Frame(self.root, bg="pink", height=20)
        top_frame.pack(side=TOP, fill="x")

        lbl_header = Label(top_frame, text="PDF Data Extractor", highlightthickness=0, background="pink",
                           bd=0, justify=CENTER, width=50)
        lbl_header.grid(row=0, column=1, padx=5, pady=5, columnspan=3)
        lbl_header.config(font=('Verdana', 20))

        middle_frame = Frame(self.root, height=510)  # bg="gray",
        middle_frame.pack(side=TOP, fill="both")

        lbl_note = Label(middle_frame, text="Note:- Please create a folder and paste all pdf file(s) in it before running this tool "
                                            "and select this folder using browse button given below and click extract data button to extract data from pdf files.", justify=LEFT)
        lbl_note.grid(row=0, column=0, padx=2, pady=2, columnspan=10, sticky=W)
        lbl_note.config(font=('Verdana', 12), wraplength=800, width=91, height=4, background="gray", fg="white")

        # lbl_vendor = Label(middle_frame, text="Select vendor:-", width=20)
        # lbl_vendor.grid(row=1, column=1, padx=2, pady=2, sticky=E)
        # lbl_vendor.config(font=('Verdana', 10))

        # self.vendor_clicked = StringVar(value="Select")
        # self.vendor_options = ["Vendor1", "Vendor2", "Vendor3"]
        # self.vendor_dropdown = OptionMenu(middle_frame, self.vendor_clicked, *self.vendor_options)
        # self.vendor_dropdown.grid(row=1, column=3, padx=2, pady=2, sticky=W)
        # self.vendor_dropdown.config(width=30, height=2, bg="#ffbf00", font=('Verdana', 10))

        self.chk_save_image = IntVar()
        self.btn_save_image = Checkbutton(middle_frame, text="Save image files", variable=self.chk_save_image, onvalue=1, offvalue=0, height=2, width=20)
        self.btn_save_image.grid(row=1, column=4, padx=2, pady=2, sticky=W)
        self.btn_save_image.select()
        self.btn_save_image.config(font=('Verdana', 10))

        lbl_button = Label(middle_frame, text="Select folder path:-", justify=CENTER, width=20)
        lbl_button.grid(row=2, column=1, padx=2, pady=2, sticky=E)
        lbl_button.config(font=('Verdana', 10))

        self.txt_file_path = Text(middle_frame, width=70, height=2, font=('Verdana', 10))
        self.txt_file_path.grid(row=2, column=3, padx=2, pady=2, sticky=W)
        self.txt_file_path.config(state="disabled")

        btn_browse = Button(middle_frame, text="Browse", width=14, height=2, font=('Verdana', 12), justify=CENTER
                            , command=self.browse_folder, bg="#ffbf00")
        btn_browse.grid(row=2, column=4, padx=2, pady=2)

        btn_extract = Button(middle_frame, text="Extract Data", width=14, height=2, font=('Verdana', 12), justify=CENTER
                             , command=self.extract_data, bg="#ffbf00")
        btn_extract.grid(row=3, column=3, padx=2, pady=2, sticky=W)

        # root.destroy()
        self.root.mainloop()

    def browse_folder(self):
        # self.vendor_selected = self.vendor_clicked.get()
        # if self.vendor_selected == "Select":
        #     messagebox.showinfo("PDF Data Extractor", "Please select the vendor and try again.")
        #     return

        initial_directory = os.getcwd()
        selected_directory = filedialog.askdirectory(parent=self.root, initialdir=initial_directory,
                                                     title='Please select a folder containing pdf(s)')
        if selected_directory is not None and selected_directory != "":
            self.txt_file_path.config(state="normal")
            self.txt_file_path.delete("1.0", END)
            self.txt_file_path.insert(END, selected_directory)
            self.txt_file_path.config(state="disabled")
        else:
            self.txt_file_path.config(state="normal")
            self.txt_file_path.delete("1.0", END)
            self.txt_file_path.config(state="disabled")

    def extract_data(self):
        # self.vendor_selected = self.vendor_clicked.get()
        # if self.vendor_selected == "Select":
        #     messagebox.showinfo("PDF Data Extractor", "Please select the vendor and try again.")
        #     return

        self.txt_file_path.config(state="normal")
        file_path_variable = self.txt_file_path.get(1.0, END).replace('\n', '')
        self.txt_file_path.config(state="disabled")

        if file_path_variable != "":
            result = askyesno(title="Confirm", message="Are you sure that you want to extract data?")
            if result is True:
                Pdf_To_Image.convert_pdf_to_image(file_path_variable)
                save_image = self.chk_save_image.get()
                if save_image == 0:
                    # Delete all files if exists
                    for filename in os.listdir(file_path_variable):
                        try:
                            file_path = os.path.join(file_path_variable, filename)
                            extension = file_path[-4:].upper()
                            if extension == ".TXT" or extension == "JPEG":
                                if os.path.isfile(file_path) or os.path.islink(file_path):
                                    os.unlink(file_path)
                                elif os.path.isdir(file_path):
                                    shutil.rmtree(file_path)
                        except Exception as e:
                            print('Failed to delete files after extraction')

                self.txt_file_path.config(state="normal")
                self.txt_file_path.delete("1.0", END)
                self.txt_file_path.config(state="disabled")
                # self.vendor_clicked.set('Select')
        else:
            messagebox.showinfo("PDF Data Extractor", "Folder is not selected.")
