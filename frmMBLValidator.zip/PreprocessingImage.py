import cv2
import numpy as np

# Load the image
image = cv2.imread('path_to_your_image.jpg')

# Normalize
norm_img = np.zeros((image.shape[0], image.shape[1]))
image = cv2.normalize(image, norm_img, 0, 255, cv2.NORM_MINMAX)

# Convert to grayscale
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Binarize
_, binary_image = cv2.threshold(gray_image, 128, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)

# Remove noise
binary_image = cv2.medianBlur(binary_image, 3)

# Skew correction
coords = np.column_stack(np.where(binary_image > 0))
angle = cv2.minAreaRect(coords)[-1]
if angle < -45:
    angle = -(90 + angle)
else:
    angle = -angle

(h, w) = binary_image.shape[:2]
center = (w // 2, h // 2)
M = cv2.getRotationMatrix2D(center, angle, 1.0)
binary_image = cv2.warpAffine(binary_image, M, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)

# Dilation and erosion
kernel = np.ones((1, 1), np.uint8)
binary_image = cv2.dilate(binary_image, kernel, iterations=1)
binary_image = cv2.erode(binary_image, kernel, iterations=1)

# Optional: Edge detection
edges = cv2.Canny(binary_image, 100, 200)

# Save the preprocessed image
cv2.imwrite('preprocessed_image.jpg', binary_image)
