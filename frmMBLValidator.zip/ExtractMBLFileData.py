import os
import cv2
import pymupdf
import pytesseract
import pandas as pd
from PIL import Image
import numpy as np
import xlsxwriter
import common


class ExtractMBLDataOCR:
    pdfImagePath = []
    headersData = []
    detailsData = []

    strVessel = ""
    strPortOfLoading = ""
    strPortOfDischarge = ""
    strPlaceOfDelivery = ""

    strMarksAndNo = ""
    strPackageQuantity = ""
    strDescriptionOfGoods = ""

    def __init__(self):
        str_tesseract_binaries_path = os.getcwd() + r'\\Tesseract-OCR\\tesseract.exe'
        pytesseract.pytesseract.tesseract_cmd = str_tesseract_binaries_path
        self.clear()
        self.obj_common = common.Common()

        if not os.path.exists('Processing'):
            os.makedirs('Processing')

    def clear(self):
        self.pdfImagePath = []
        self.headersData = []
        self.detailsData = []

        self.strVessel = ""
        self.strPortOfLoading = ""
        self.strPortOfDischarge = ""
        self.strPlaceOfDelivery = ""

        self.strMarksAndNo = ""
        self.strPackageQuantity = ""
        self.strDescriptionOfGoods = ""

        self.delete_processed_images()

    def delete_processed_images(self):
        try:
            for file in os.listdir('Processing'):
                if file.lower().endswith('.png'):
                    os.remove("Processing//" + file)
        except Exception as err:
            self.obj_common.write_log(f"Error in delete_processed_images function: -{str(err)}")

    def convert_pdf_to_images(self, str_pdffile_path):
        try:
            self.clear()
            dpi = 200
            zoom = dpi / 75
            magnify = pymupdf.Matrix(zoom, zoom)

            # Open the PDF file and ensure it's properly closed
            with pymupdf.open(str_pdffile_path) as pdf_doc:
                page_counter = 1
                for page in pdf_doc:
                    page_name = f"Processing\\MBL_Page_{str(page_counter)}.PNG"
                    pix = page.get_pixmap(matrix=magnify)
                    pix.save(page_name)
                    self.pdfImagePath.append(page_name)
                    page_counter += 1

            self.extract_first_page_header_data()
            self.extract_first_page_details_data()
            self.extract_other_page_data()
            self.delete_processed_images()
            self.write_to_excel(str_pdffile_path)

        except Exception as err:
            self.obj_common.write_log(f"Error in convert_pdf_to_images function: -{str(err)}")

    def extract_first_page_header_data(self):
        try:
            first_page_path = self.pdfImagePath[0]

            main_image = cv2.imread(first_page_path)
            image = cv2.cvtColor(main_image, cv2.COLOR_BGR2GRAY)

            y1 = 760
            y2 = 832
            x1 = 74
            x2 = 907
            cropped_image = image[y1:y2, x1:x2]
            cv2.imwrite(f'Processing/VesselMBL.png', cropped_image)
            pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
            extracted_text = pytesseract.image_to_string(pil_image)
            array = extracted_text.replace('\n\n', '\n').strip().split('\n')
            self.strVessel = array[1].strip()
            os.remove(f'Processing/VesselMBL.png')

            y1 = 760
            y2 = 832
            x1 = 492
            x2 = 907
            cropped_image = image[y1:y2, x1:x2]
            cv2.imwrite(f'Processing/PortOfLoadingMBL.png', cropped_image)
            pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
            extracted_text = pytesseract.image_to_string(pil_image)
            array = extracted_text.replace('\n\n', '\n').strip().split('\n')
            self.strPortOfLoading = array[1].strip()
            os.remove(f'Processing/PortOfLoadingMBL.png')

            y1 = 832
            y2 = 893
            x1 = 75
            x2 = 490
            cropped_image = image[y1:y2, x1:x2]
            cv2.imwrite(f'Processing/PortOfDischargeMBL.png', cropped_image)
            pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
            extracted_text = pytesseract.image_to_string(pil_image)
            array = extracted_text.replace('\n\n', '\n').strip().split('\n')
            self.strPortOfDischarge = array[1].strip()
            os.remove(f'Processing/PortOfDischargeMBL.png')

            y1 = 829
            y2 = 893
            x1 = 491
            x2 = 907
            cropped_image = image[y1:y2, x1:x2]
            cv2.imwrite(f'Processing/PlaceOfDeliveryMBL.png', cropped_image)
            pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
            extracted_text = pytesseract.image_to_string(pil_image)
            array = extracted_text.replace('\n\n', '\n').strip().split('\n')
            self.strPlaceOfDelivery = array[1].strip()
            os.remove(f'Processing/PlaceOfDeliveryMBL.png')

            self.headersData.append({
                            "Vessel": self.strVessel,
                            "PortOfLoading": self.strPortOfLoading,
                            "PortOfDischarge": self.strPortOfDischarge,
                            "PlaceOfDelivery": self.strPlaceOfDelivery
                        })
        except Exception as err:
            self.obj_common.write_log(f"Error in extract_first_page_header_data function: -{str(err)}")

    def extract_first_page_details_data(self):
        try:
            first_page_path = self.pdfImagePath[0]

            main_image = cv2.imread(first_page_path)
            image = cv2.cvtColor(main_image, cv2.COLOR_BGR2GRAY)

            y1 = 930
            y2 = 1397
            x1 = 74
            x2 = 379
            cropped_image = image[y1:y2, x1:x2]
            cv2.imwrite(f'Processing/MarksAndNosColumnMBL.png', cropped_image)

            y1 = 930
            y2 = 1397
            x1 = 378
            x2 = 539
            cropped_image = image[y1:y2, x1:x2]
            cv2.imwrite(f'Processing/PackageQuantityColumnMBL.png', cropped_image)

            y1 = 930
            y2 = 1397
            x1 = 563
            x2 = 1145
            cropped_image = image[y1:y2, x1:x2]
            cv2.imwrite(f'Processing/DescriptionOfGoodsColumnMBL.png', cropped_image)

            y1 = 930
            y2 = 1397
            x1 = 1361
            x2 = 1553
            cropped_image = image[y1:y2, x1:x2]
            cv2.imwrite(f'Processing/MeasurementColumnMBL.png', cropped_image)

            # Extract Top coordinates of each line based from measurement column image which contains CBM or KGS to separate lines
            image = Image.open('Processing/MeasurementColumnMBL.png')
            data = pytesseract.image_to_data(image, output_type='dict')
            df = pd.DataFrame(data)
            df_filtered = df.loc[lambda x: x['level'] == 5]

            top_values = []
            for index, row in df_filtered.iterrows():
                if "CBM" in str(row['text']).upper() or " CBM" in str(row['text']).upper():
                    top_values.append(str(row['top']))

            start = 0
            length = len(top_values)

            for i in range(start, start + length):
                y1 = int(top_values[i])

                if i == length-1:
                    y2 = y1 + 500
                else:
                    y2 = int(top_values[i+1])

                cv2image = cv2.imread('Processing/DescriptionOfGoodsColumnMBL.png')
                cropped_image = cv2image[y1-12:y2-8, :]
                cv2.imwrite(f'Processing/DescriptionOfGoods_{i+1}.png', cropped_image)
                pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
                extracted_text = pytesseract.image_to_string(pil_image)
                self.strDescriptionOfGoods = extracted_text.replace('\n\n', '\n').strip()
                os.remove(f'Processing/DescriptionOfGoods_{i+1}.png')

                cv2image = cv2.imread('Processing/PackageQuantityColumnMBL.png')
                cropped_image = cv2image[y1-8:y2-8, :]
                cv2.imwrite(f'Processing/PackageQuantityColumn_{i+1}.png', cropped_image)
                pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
                extracted_text = pytesseract.image_to_string(pil_image)
                self.strPackageQuantity = extracted_text.replace('\n\n', '\n').strip().replace('\n', '').strip()
                os.remove(f'Processing/PackageQuantityColumn_{i+1}.png')

                cv2image = cv2.imread('Processing/MarksAndNosColumnMBL.png')
                cropped_image = cv2image[y1-12:y2-8, :]
                cv2.imwrite(f'Processing/MarksAndNosColumn_{i+1}.png', cropped_image)
                pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
                extracted_text = pytesseract.image_to_string(pil_image)
                self.strMarksAndNo = extracted_text.replace('\n\n', '\n').strip()
                os.remove(f'Processing/MarksAndNosColumn_{i+1}.png')

                self.detailsData.append({
                    "MarksAndNo": self.strMarksAndNo,
                    "PackageQuantity": self.strPackageQuantity,
                    "DescriptionOfGoods": self.strDescriptionOfGoods
                })

            os.remove(f'Processing/MarksAndNosColumnMBL.png')
            os.remove(f'Processing/PackageQuantityColumnMBL.png')
            os.remove(f'Processing/DescriptionOfGoodsColumnMBL.png')
            os.remove(f'Processing/MeasurementColumnMBL.png')
        except Exception as err:
            self.obj_common.write_log(f"Error in extract_first_page_details_data function: -{str(err)}")

    def extract_other_page_data(self):
        try:
            counter = 0
            for imagePath in self.pdfImagePath:
                if counter == 0:
                    counter = counter + 1
                    continue

                main_image = cv2.imread(imagePath)
                image = cv2.cvtColor(main_image, cv2.COLOR_BGR2GRAY)

                # First crop all the columns from main page
                y1 = 183
                y2 = 1929
                x1 = 37
                x2 = 375
                cropped_image = image[y1:y2, x1:x2]
                cv2.imwrite(f'Processing/MarksAndNosColumnMBL.png', cropped_image)

                y1 = 183
                y2 = 1929
                x1 = 377
                x2 = 529
                cropped_image = image[y1:y2, x1:x2]
                cv2.imwrite(f'Processing/PackageQuantityColumnMBL.png', cropped_image)

                y1 = 183
                y2 = 1929
                x1 = 545
                x2 = 1113
                cropped_image = image[y1:y2, x1:x2]
                cv2.imwrite(f'Processing/DescriptionOfGoodsColumnMBL.png', cropped_image)

                y1 = 183
                y2 = 1929
                x1 = 1334
                x2 = 1561
                cropped_image = image[y1:y2, x1:x2]
                cv2.imwrite(f'Processing/MeasurementColumnMBL.png', cropped_image)

                # Extract Top coordinates of each line based from measurement column image which contains CBM or KGS to separate lines
                image = Image.open('Processing/MeasurementColumnMBL.png')
                data = pytesseract.image_to_data(image, output_type='dict')
                df = pd.DataFrame(data)
                df_filtered = df.loc[lambda x: x['level'] == 5]

                top_values = [55]
                for index, row in df_filtered.iterrows():
                    if "CBM" in str(row['text']).upper() or " CBM" in str(row['text']).upper():
                        top_values.append(str(row['top']))

                start = 0
                length = len(top_values)

                if length > 1:
                    for i in range(start, start + length):
                        y1 = int(top_values[i])

                        if i == length-1:
                            y2 = y1 + 500
                        else:
                            y2 = int(top_values[i+1])

                        cv2image = cv2.imread('Processing/DescriptionOfGoodsColumnMBL.png')
                        cropped_image = cv2image[y1-4:y2, :]
                        cv2.imwrite(f'Processing/DescriptionOfGoods_{i+1}.png', cropped_image)
                        pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        self.strDescriptionOfGoods = extracted_text.replace('\n\n', '\n').strip()
                        os.remove(f'Processing/DescriptionOfGoods_{i+1}.png')

                        cv2image = cv2.imread('Processing/PackageQuantityColumnMBL.png')
                        cropped_image = cv2image[y1-4:y2, :]
                        cv2.imwrite(f'Processing/PackageQuantityColumn_{i+1}.png', cropped_image)
                        pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        self.strPackageQuantity = extracted_text.replace('\n\n', '\n').replace('\n', '').strip()
                        os.remove(f'Processing/PackageQuantityColumn_{i+1}.png')

                        cv2image = cv2.imread('Processing/MarksAndNosColumnMBL.png')
                        cropped_image = cv2image[y1-4:y2, :]
                        cv2.imwrite(f'Processing/MarksAndNosColumn_{i+1}.png', cropped_image)
                        pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        self.strMarksAndNo = extracted_text.replace('\n\n', '\n').strip()
                        os.remove(f'Processing/MarksAndNosColumn_{i+1}.png')

                        if self.strMarksAndNo != "" and self.strPackageQuantity != "" and self.strDescriptionOfGoods != "":
                            self.detailsData.append({
                                "MarksAndNo": self.strMarksAndNo,
                                "PackageQuantity": self.strPackageQuantity.replace('\n', '').replace('(', '').replace(')', ''),
                                "DescriptionOfGoods": self.strDescriptionOfGoods
                            })

            os.remove(f'Processing/MarksAndNosColumnMBL.png')
            os.remove(f'Processing/PackageQuantityColumnMBL.png')
            os.remove(f'Processing/DescriptionOfGoodsColumnMBL.png')
            os.remove(f'Processing/MeasurementColumnMBL.png')
        except Exception as err:
            self.obj_common.write_log(f"Error in extract_other_page_data function: -{str(err)}")

    def preprocess_image(self, image):
        try:
            # Normalize
            norm_img = np.zeros((image.shape[0], image.shape[1]))
            image = cv2.normalize(image, norm_img, 0, 255, cv2.NORM_MINMAX)

            # Convert to grayscale
            gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

            # Binarize
            _, binary_image = cv2.threshold(gray_image, 128, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)

            # Remove noise
            binary_image = cv2.medianBlur(binary_image, 3)

            # Skew correction
            co_ords = np.column_stack(np.where(binary_image > 0))
            angle = cv2.minAreaRect(co_ords)[-1]
            if angle < -45:
                angle = -(90 + angle)
            else:
                angle = -angle

            (h, w) = binary_image.shape[:2]
            center = (w // 2, h // 2)
            M = cv2.getRotationMatrix2D(center, angle, 1.0)
            binary_image = cv2.warpAffine(binary_image, M, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)

            # Dilation and erosion
            kernel = np.ones((1, 1), np.uint8)
            binary_image = cv2.dilate(binary_image, kernel, iterations=1)
            binary_image = cv2.erode(binary_image, kernel, iterations=1)

            # Optional: Edge detection
            edges = cv2.Canny(binary_image, 100, 200)

            return binary_image
        except Exception as err:
            self.obj_common.write_log(f"Error in preprocess_image function: -{str(err)}")

    def write_to_excel(self, pdf_file_path):
        try:
            file_path = os.path.dirname(os.path.abspath(pdf_file_path))
            str_pdf_file_path = os.path.join(file_path, "MBL_OCR.xlsx")
            workbook = xlsxwriter.Workbook(str_pdf_file_path)
            # workbook = xlsxwriter.Workbook(pdf_file_path.replace('.pdf', '_OCR.xlsx'))
            worksheet = workbook.add_worksheet()
            worksheet.name = "Header Data"

            # worksheet.set_column('A:A', 20)
            if len(self.headersData) > 0:
                worksheet.write('A1', 'Vessel')
                worksheet.write('B1', 'PortOfLoading')
                worksheet.write('C1', 'PortOfDischarge')
                worksheet.write('D1', 'PlaceOfDelivery')

                counter = 2
                for data in self.headersData:
                    worksheet.write('A' + str(counter), data['Vessel'])
                    worksheet.write('B' + str(counter), data['PortOfLoading'])
                    worksheet.write('C' + str(counter), data['PortOfDischarge'])
                    worksheet.write('D' + str(counter), data['PlaceOfDelivery'])

            if len(self.detailsData) > 0:
                worksheet = workbook.add_worksheet()
                worksheet.name = "Details Data"

                worksheet.write('A1', 'MarksAndNo')
                worksheet.write('B1', 'PackageQuantity')
                worksheet.write('C1', 'DescriptionOfGoods')

                counter = 2
                for data in self.detailsData:
                    worksheet.write('A' + str(counter), data['MarksAndNo'])
                    worksheet.write('B' + str(counter), data['PackageQuantity'])
                    worksheet.write('C' + str(counter), data['DescriptionOfGoods'])
                    counter = counter + 1

            workbook.close()
        except Exception as err:
            self.obj_common.write_log(f"Error in write_to_excel function: -{str(err)}")
