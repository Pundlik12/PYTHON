import os
import pdfplumber
import xlsxwriter
from common import Common


class ExtractSIData:
    text = ''
    Shipper = ''
    Consignee = ''
    NotifyAddress = ''
    BookingRef = ''
    ContainerNo = ''
    Seal = ''
    NrFile = ''
    Vessel = ''
    PortOfLoading = ''
    PlaceOfDelivery = ''
    FinalDestination = ''

    HblNumber = ''
    MarksAndNo = ''
    Package = ''
    Description = ''
    GrossWeight = ''
    Measurement = ''
    headers_data = []
    details_data = []
    obj_common = None

    def initiate_variables(self):
        self.text = ''
        self.Shipper = ''
        self.Consignee = ''
        self.NotifyAddress = ''
        self.BookingRef = ''
        self.ContainerNo = ''
        self.Seal = ''
        self.NrFile = ''
        self.Vessel = ''
        self.PortOfLoading = ''
        self.PlaceOfDelivery = ''
        self.FinalDestination = ''

        self.HblNumber = ''
        self.MarksAndNo = ''
        self.Package = ''
        self.Description = ''
        self.GrossWeight = ''
        self.Measurement = ''
        self.headers_data = []
        self.details_data = []
        self.obj_common = Common()

    def extract_text_from_pdf(self, pdf_path):
        try:
            self.initiate_variables()

            with pdfplumber.open(pdf_path) as pdf:
                for page in pdf.pages:
                    self.text = self.text + page.extract_text() + '\n'

        except Exception as Err:
            self.text = ""
            self.obj_common.write_log(f'Error in extract_text_from_pdf function of SI: - {str(Err)}')

        if self.text != "":
            # print(self.text)
            self.extract_header_details()
            self.extract_line_details()
            self.write_to_excel(pdf_path)

    def extract_header_details(self):
        try:
            tempdata = self.get_data_between_markers("shipper", "consignee")
            for line in tempdata:
                if 'ECU-WORLDWIDE' in line:
                    break
                else:
                    self.Shipper = self.Shipper + line + '\n'

            tempdata = self.get_data_between_markers("consignee", "notify address")
            for line in tempdata:
                if 'B/L INSTRUCTIONS' in line:
                    continue
                else:
                    if 'Booking Ref' in line:
                        start_position = line.find('Booking Ref')
                        text = line[1:start_position]
                        self.Consignee = self.Consignee + text.strip() + '\n'
                        self.BookingRef = str(line[start_position:]).replace('Booking Ref.:', '').replace('Booking Ref', '').strip()
                    else:
                        self.Consignee = self.Consignee + line + '\n'

            tempdata = self.get_data_between_markers("notify address", "vessel")
            counter = 1
            for line in tempdata:
                if 'Container' in line:
                    continue
                else:
                    if counter == 2:
                        data_array = line.split(' ')
                        length = len(data_array)
                        self.Seal = str(data_array[length - 1]).strip()
                        self.ContainerNo = str(data_array[0] + data_array[1]).replace('-', '')  # line.replace(self.Seal, '').strip()
                    else:
                        self.NotifyAddress = self.NotifyAddress + line + '\n'
                counter = counter + 1

            tempdata = self.get_data_between_markers("Vessel Port of loading NrFile", "Place of Delivery Final Destination")
            self.NrFile = tempdata[0]
            self.Vessel = tempdata[1]
            self.PortOfLoading = tempdata[1]

            tempdata = self.get_data_between_markers("Place of Delivery Final Destination", "Marks and Nos.")
            self.PlaceOfDelivery = tempdata[0]
            self.FinalDestination = tempdata[0]

            self.headers_data.append({
                                "Shipper": self.Shipper,
                                "Consignee": self.Consignee,
                                "NotifyAddress": self.NotifyAddress,
                                "Vessel": self.Vessel,
                                "PortOfLoading": self.PortOfLoading,
                                "PlaceOfDelivery": self.PlaceOfDelivery,
                                "FinalDestination": self.FinalDestination,
                                "BookingNo": self.BookingRef,
                                "Container": self.ContainerNo,
                                "Seal": self.Seal
                            })

        except Exception as Err:
            self.obj_common.write_log(f'Error in extract_header_details function of SI: - {str(Err)}')

    def extract_line_details(self):
        try:
            line_data = self.text.split('\n')

            for x in range(len(line_data) - 1):
                self.HblNumber = ""
                self.MarksAndNo = ""
                self.Package = ""
                self.Description = ""
                self.GrossWeight = ""
                self.Measurement = ""

                text = line_data[x]
                if 'House BL'.lower() in text.lower():
                    self.HblNumber = text.replace('House BL', '').strip()
                    text = line_data[x + 1]
                    data_array = text.split(' ')
                    self.GrossWeight = str(data_array[len(data_array)-2]).replace(',', '')
                    self.Measurement = str(data_array[len(data_array)-1]).replace(',', '')

                    if self.is_numeric(self.GrossWeight) and self.is_numeric(self.Measurement):
                        self.details_data.append(
                                        {"HblNumber": self.HblNumber,
                                         "MarksAndNo": "",
                                         "Package": "",
                                         "Description": "",
                                         "GrossWeight": self.GrossWeight,
                                         "Measurement": self.Measurement})

            # Old Logic ##
            # for x in range(len(line_data) - 1):
            #     text = line_data[x]
            #     if 'House BL'.lower() in text.lower():
            #         self.HblNumber = ""
            #         self.MarksAndNo = ""
            #         self.Package = ""
            #         self.Description = ""
            #         self.GrossWeight = ""
            #         self.Measurement = ""
            #
            #         self.HblNumber = text.replace('House BL', '').strip()
            #         hbl_found = False
            #         for y in range(len(line_data) - 1):
            #             text = line_data[y]
            #             if hbl_found is False:
            #                 if self.HblNumber not in text:
            #                     continue
            #                 else:
            #                     hbl_found = True
            #                     continue
            #
            #             if hbl_found is True:
            #                 if 'House BL'.lower() in text.lower():
            #                     self.details_data.append(
            #                         {"HblNumber": self.HblNumber,
            #                          "MarksAndNo": "",
            #                          "Package": "",
            #                          "Description": "",
            #                          "GrossWeight": self.GrossWeight,
            #                          "Measurement": self.Measurement})
            #
            #                     # self.details_data.append(
            #                     #     {"HblNumber": self.HblNumber,
            #                     #      "MarksAndNo": self.MarksAndNo,
            #                     #      "Package": self.Package,
            #                     #      "Description": self.Description,
            #                     #      "GrossWeight": self.GrossWeight,
            #                     #      "Measurement": self.Measurement})
            #                     break
            #                 else:
            #                     data_array = text.split(' ')
            #                     if self.GrossWeight == "" and self.Measurement == "":
            #                         gross_weight = str(data_array[len(data_array) - 2]).replace(',', '')
            #                         measurement = str(data_array[len(data_array) - 1]).replace(',', '')
            #
            #                         if self.is_numeric(gross_weight) and self.is_numeric(measurement):
            #                             self.GrossWeight = gross_weight
            #                             self.Measurement = measurement
            #
            #                         for n in range(len(data_array)-1):
            #                             text1 = data_array[n]
            #                             if 'STC' in text1:
            #                                 self.Package = data_array[n-1]
            #                                 break
            #
            #                         data_array1 = text.split(self.Package)
            #                         self.MarksAndNo = str(data_array1[0]).strip()
            #                         self.Description = str(data_array1[1]).replace(data_array[len(data_array) - 1], '').replace(data_array[len(data_array) - 2], '').replace('STC', '').strip()
            #
            # self.details_data.append(
            #                         {"HblNumber": self.HblNumber,
            #                          "MarksAndNo": "",
            #                          "Package": "",
            #                          "Description": "",
            #                          "GrossWeight": self.GrossWeight,
            #                          "Measurement": self.Measurement})
        except Exception as Err:
            self.obj_common.write_log(f'Error in extract_line_details function of SI: - {str(Err)}')

    def is_numeric(self, value):
        try:
            check_value = value.replace(',', '')
            float(check_value)
            return True
        except ValueError:
            return False

    def get_data_between_markers(self, start_text, end_text):
        try:
            lines = []
            inside = False
            line_data = self.text.split('\n')

            for line in line_data:
                if start_text.lower() in line.lower():
                    inside = True
                    continue

                if end_text.lower() in line.lower():
                    break

                if inside:
                    lines.append(line.strip())

            return lines

        except Exception as Err:
            self.obj_common.write_log(f'Error in get_data_between_markers function of SI: - {str(Err)}')

    def write_to_excel(self, pdf_file_path):
        try:
            file_path = os.path.dirname(os.path.abspath(pdf_file_path))
            str_pdf_file_path = os.path.join(file_path, "SI.xlsx")
            workbook = xlsxwriter.Workbook(str_pdf_file_path)
            # workbook = xlsxwriter.Workbook(pdf_file_path.replace('.pdf', '.xlsx'))
            worksheet = workbook.add_worksheet()
            worksheet.name = "Header Data"

            # worksheet.set_column('A:A', 20)
            if len(self.headers_data) > 0:
                worksheet.write('A1', 'Shipper')
                worksheet.write('B1', 'Consignee')
                worksheet.write('C1', 'NotifyAddress')
                worksheet.write('D1', 'Vessel')
                worksheet.write('E1', 'PortOfLoading')
                worksheet.write('F1', 'PlaceOfDelivery')
                worksheet.write('G1', 'FinalDestination')
                worksheet.write('H1', 'BookingNo')
                worksheet.write('I1', 'Container')
                worksheet.write('J1', 'Seal')

                counter = 2
                for data in self.headers_data:
                    worksheet.write('A' + str(counter), data['Shipper'])
                    worksheet.write('B' + str(counter), data["Consignee"])
                    worksheet.write('C' + str(counter), data['NotifyAddress'])
                    worksheet.write('D' + str(counter), data['Vessel'])
                    worksheet.write('E' + str(counter), data['PortOfLoading'])
                    worksheet.write('F' + str(counter), data['PlaceOfDelivery'])
                    worksheet.write('G' + str(counter), data['FinalDestination'])
                    worksheet.write('H' + str(counter), data['BookingNo'])
                    worksheet.write('I' + str(counter), data['Container'])
                    worksheet.write('J' + str(counter), data['Seal'])

            if len(self.details_data) > 0:
                worksheet = workbook.add_worksheet()
                worksheet.name = "Details Data"

                worksheet.write('A1', 'HblNumber')
                worksheet.write('B1', 'MarksAndNo')
                worksheet.write('C1', 'Package')
                worksheet.write('D1', 'Description')
                worksheet.write('E1', 'GrossWeight')
                worksheet.write('F1', 'Measurement')

                counter = 2
                for data in self.details_data:
                    worksheet.write('A' + str(counter), data['HblNumber'])
                    worksheet.write('B' + str(counter), data['MarksAndNo'])
                    worksheet.write('C' + str(counter), data['Package'])
                    worksheet.write('D' + str(counter), data['Description'])
                    worksheet.write('E' + str(counter), data['GrossWeight'])
                    worksheet.write('F' + str(counter), data['Measurement'])
                    counter = counter + 1

            workbook.close()
        except Exception as Err:
            self.obj_common.write_log(f'Error in write_to_excel function of SI: - {str(Err)}')
