import os
import shutil


class Common:

    def __init__(self):
        self.str_log_file_path = os.getcwd() + "\\Log.txt"
        self.file_write = None

    def write_log(self, str_log_text):
        try:
            self.file_write = open(self.str_log_file_path, "a")
            self.file_write.write(str_log_text + '\n')
            self.file_write.close()
        except Exception as e:
            print(f'Failed to write_log {str(e)}')

    def delete_all_files(self, folder_path):
        for filename in os.listdir(folder_path):
            file_path = os.path.join(folder_path, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)
            except Exception as e:
                print(f'Error in delete_all_files function:- {str(e)}')
