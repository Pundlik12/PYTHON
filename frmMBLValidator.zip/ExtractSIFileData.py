import os
import cv2
import pymupdf
import pytesseract
import numpy as np
import xlsxwriter
from PIL import Image
import common


class ExtractSIDataOCR:
    pdfImagePath = []
    headersData = []
    detailsData = []

    strVessel = ""
    strPortOfLoading = ""
    strPlaceOfDelivery = ""
    strFinalDestination = ""

    strMarksAndNo = ""
    strPackage = ""
    strDescription = ""

    def __init__(self):
        str_tesseract_binaries_path = os.getcwd() + r'\\Tesseract-OCR\\tesseract.exe'
        pytesseract.pytesseract.tesseract_cmd = str_tesseract_binaries_path
        self.clear()
        self.obj_common = common.Common()

        if not os.path.exists('Processing'):
            os.makedirs('Processing')

    def clear(self):
        self.pdfImagePath = []
        self.headersData = []
        self.detailsData = []

        self.strVessel = ""
        self.strPortOfLoading = ""
        self.strPlaceOfDelivery = ""
        self.strFinalDestination = ""

        self.strMarksAndNo = ""
        self.strPackage = ""
        self.strDescription = ""

        self.delete_processed_images()

    def delete_processed_images(self):
        try:
            for file in os.listdir('Processing'):
                if file.lower().endswith('.png'):
                    os.remove("Processing//" + file)
        except Exception as err:
            self.obj_common.write_log(f"Error in delete_processed_images function: -{str(err)}")

    def convert_pdf_to_images(self, str_pdf_file_path):
        try:
            self.clear()

            dpi = 200
            zoom = dpi / 75
            magnify = pymupdf.Matrix(zoom, zoom)

            # Open the PDF file and ensure it's properly closed
            with pymupdf.open(str_pdf_file_path) as pdf_doc:
                page_counter = 1
                for page in pdf_doc:
                    page_name = f"Processing\\SI_Page{str(page_counter)}.PNG"
                    pix = page.get_pixmap(matrix=magnify)
                    pix.save(page_name)
                    self.pdfImagePath.append(page_name)
                    page_counter += 1

            self.extract_first_page_data()
            self.extract_remaining_page_data()
            self.delete_processed_images()
            self.write_to_excel(str_pdf_file_path)

        except Exception as err:
            self.obj_common.write_log(f"Error in convert_pdf_to_images function: -{str(err)}")

    def extract_first_page_data(self):
        try:
            first_page_path = self.pdfImagePath[0]

            # Load the image
            img = cv2.imread(first_page_path)

            # Convert to grayscale
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

            # Apply edge detection
            edges = cv2.Canny(gray, 50, 150)

            # Apply Hough transform
            lines = cv2.HoughLinesP(edges, 1, np.pi/180, 200, minLineLength=100, maxLineGap=10)

            # Filter horizontal lines
            horizontal_lines = []
            y_lines = []
            for line in lines:
                x1, y1, x2, y2 = line[0]
                if abs(y1 - y2) < 10 and abs(x1 - x2) > 700:   # Check if the line is horizontal
                    horizontal_lines.append(line)
                    y_lines.append(y1)

            y_lines.sort()

            line_length = len(y_lines)
            if line_length >= 2:
                lines_coordinate = []
                for counter in range(0, line_length):
                    current_value = y_lines[counter]
                    if (counter + 1) <= (line_length - 1):
                        next_value = y_lines[counter + 1]
                        if (next_value - current_value) > 20:
                            lines_coordinate.append([current_value, next_value])

                counter = 0
                for linnes in lines_coordinate:
                    counter = counter + 1

                    if counter == 4:  # Vessel
                        y1 = linnes[0]
                        y2 = linnes[1]
                        main_image = img[y1:y2, 0:img.shape[1]]

                        # Convert to grayscale
                        cropped_image = cv2.cvtColor(main_image, cv2.COLOR_BGR2GRAY)
                        cv2.imwrite(f'Processing/cropped_image{str(counter)}.png', cropped_image)

                        y1 = 3
                        y2 = 82
                        x1 = 1
                        x2 = 444
                        vessel_image = cropped_image[y1:y2, x1:x2]
                        pil_image = Image.fromarray(cv2.cvtColor(vessel_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        extracted_text = extracted_text.replace('\n\n', '\n')
                        array = extracted_text.split('\n')
                        self.strVessel = array[1].strip()

                        # Port Of Loading
                        y1 = 3
                        y2 = 82
                        x1 = 444
                        x2 = 851
                        port_of_loading_image = cropped_image[y1:y2, x1:x2]
                        pil_image = Image.fromarray(cv2.cvtColor(port_of_loading_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        extracted_text = extracted_text.replace('\n\n', '\n')
                        array = extracted_text.split('\n')
                        self.strPortOfLoading = array[1].strip()
                        os.remove(f'Processing/cropped_image{str(counter)}.png')

                    if counter == 5:  # Place Of Delivery
                        y1 = linnes[0]
                        y2 = linnes[1]
                        main_image = img[y1:y2, 0:img.shape[1]]

                        # Convert to grayscale
                        cropped_image = cv2.cvtColor(main_image, cv2.COLOR_BGR2GRAY)
                        cv2.imwrite(f'Processing/cropped_image{str(counter)}.png', cropped_image)

                        y1 = 3
                        y2 = 80
                        x1 = 4
                        x2 = 444
                        place_of_delivery_image = cropped_image[y1:y2, x1:x2]
                        pil_image = Image.fromarray(cv2.cvtColor(place_of_delivery_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        extracted_text = extracted_text.replace('\n\n', '\n')
                        array = extracted_text.split('\n')
                        self.strPlaceOfDelivery = array[1].strip()

                        # Final Destination
                        y1 = 3
                        y2 = 80
                        x1 = 444
                        x2 = 849
                        final_destination_image = cropped_image[y1:y2, x1:x2]
                        pil_image = Image.fromarray(cv2.cvtColor(final_destination_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        extracted_text = extracted_text.replace('\n\n', '\n')
                        array = extracted_text.split('\n')
                        self.strFinalDestination = array[1].strip()
                        os.remove(f'Processing/cropped_image{str(counter)}.png')

                self.headersData.append({
                                "Vessel": self.strVessel,
                                "PortOfLoading": self.strPortOfLoading,
                                "PlaceOfDelivery": self.strPlaceOfDelivery,
                                "FinalDestination": self.strFinalDestination
                            })
            else:
                print("Not enough horizontal lines detected.")

        except Exception as err:
            self.obj_common.write_log(f"Error in extract_first_page_data function: -{str(err)}")

    def extract_remaining_page_data(self):
        try:
            counter = 0
            for imageFileName in self.pdfImagePath:
                if counter == 0:
                    counter = counter + 1
                    continue

                image = cv2.imread(imageFileName)

                # Convert to grayscale
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

                # Apply edge detection to detect lines
                edges = cv2.Canny(gray, threshold1=50, threshold2=150)

                # Use Hough Line Transform to detect horizontal lines
                lines = cv2.HoughLinesP(edges, 1, np.pi / 180, threshold=100, minLineLength=100, maxLineGap=10)

                # Extract y-coordinates of horizontal lines
                y_lines = []
                for line in lines:
                    for x1, y1, x2, y2 in line:
                        if abs(y1 - y2) < 10 and abs(x1-x2) > 500:  # This checks if the line is horizontal
                            y_lines.append(y1)
                            cv2.line(image, (x1, y1), (x2, y2), (0, 255, 0), 2)

                # Sort lines by y-coordinate
                y_lines.sort()

                line_length = len(y_lines)
                if line_length >= 2:
                    lines_coordinate = []
                    for counter in range(0, line_length):
                        current_value = y_lines[counter]
                        if (counter + 1) <= (line_length - 1):
                            next_value = y_lines[counter + 1]
                            if (next_value - current_value) > 20:
                                lines_coordinate.append([current_value, next_value])
                        else:
                            width, height = image.shape[:2]
                            end_x = width - 1
                            end_y = height - 1
                            next_value = end_x
                            lines_coordinate.append([current_value, next_value])

                    counter = 0
                    for linnes in lines_coordinate:
                        y1 = linnes[0]
                        y2 = linnes[1]
                        cropped_image = image[y1+5:y2-5, 0:image.shape[1]]
                        cv2.imwrite(f'Processing/cropped_image{str(counter)}.png', cropped_image)
                        os.remove(f'Processing/cropped_image{str(counter)}.png')

                        house_bl_image = cropped_image[:, 0:500]
                        cv2.imwrite(f'Processing/{str(counter)}_HBL.png', house_bl_image)
                        pil_image = Image.fromarray(cv2.cvtColor(house_bl_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        extracted_text = extracted_text.replace('\n\n', '\n')
                        self.strMarksAndNo = str(extracted_text.replace('House BL', '')).strip()
                        os.remove(f'Processing/{str(counter)}_HBL.png')

                        package_image = cropped_image[:, 510:750]
                        cv2.imwrite(f'Processing/{str(counter)}_PKG.png', package_image)
                        pil_image = Image.fromarray(cv2.cvtColor(package_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        extracted_text = extracted_text.replace('\n\n', '\n').replace('STC', '')
                        self.strPackage = extracted_text.strip()
                        os.remove(f'Processing/{str(counter)}_PKG.png')

                        description_image = cropped_image[:, 760:1200]
                        cv2.imwrite(f'Processing/{str(counter)}_DESC.png', description_image)
                        pil_image = Image.fromarray(cv2.cvtColor(description_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        extracted_text = extracted_text.replace('\n\n', '\n')
                        self.strDescription = extracted_text.strip()
                        os.remove(f'Processing/{str(counter)}_DESC.png')

                        self.detailsData.append({
                            "MarksAndNo": self.strMarksAndNo,
                            "Package": self.strPackage,
                            "Description": self.strDescription
                        })

                        counter = counter + 1
                else:
                    print("Not enough horizontal lines detected.")

        except Exception as err:
            self.obj_common.write_log(f"Error in extract_remaining_page_data function: -{str(err)}")

    def preprocess_image(self, image):
        try:
            # Normalize
            norm_img = np.zeros((image.shape[0], image.shape[1]))
            image = cv2.normalize(image, norm_img, 0, 255, cv2.NORM_MINMAX)

            # Convert to grayscale
            gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

            # Binarize
            _, binary_image = cv2.threshold(gray_image, 128, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)

            # Remove noise
            binary_image = cv2.medianBlur(binary_image, 3)

            # Skew correction
            co_ords = np.column_stack(np.where(binary_image > 0))
            angle = cv2.minAreaRect(co_ords)[-1]
            if angle < -45:
                angle = -(90 + angle)
            else:
                angle = -angle

            (h, w) = binary_image.shape[:2]
            center = (w // 2, h // 2)
            M = cv2.getRotationMatrix2D(center, angle, 1.0)
            binary_image = cv2.warpAffine(binary_image, M, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)

            # Dilation and erosion
            kernel = np.ones((1, 1), np.uint8)
            binary_image = cv2.dilate(binary_image, kernel, iterations=1)
            binary_image = cv2.erode(binary_image, kernel, iterations=1)

            # Optional: Edge detection
            edges = cv2.Canny(binary_image, 100, 200)

            return binary_image
        except Exception as err:
            self.obj_common.write_log(f"Error in preprocess_image function: -{str(err)}")

    def write_to_excel(self, pdf_file_path):
        try:
            file_path = os.path.dirname(os.path.abspath(pdf_file_path))
            str_pdf_file_path = os.path.join(file_path, "SI_OCR.xlsx")
            workbook = xlsxwriter.Workbook(str_pdf_file_path)
            # workbook = xlsxwriter.Workbook(pdf_file_path.replace('.pdf', '_OCR.xlsx'))
            worksheet = workbook.add_worksheet()
            worksheet.name = "Header Data"

            # worksheet.set_column('A:A', 20)
            if len(self.headersData) > 0:
                worksheet.write('A1', 'Vessel')
                worksheet.write('B1', 'PortOfLoading')
                worksheet.write('C1', 'FinalDestination')
                worksheet.write('D1', 'PlaceOfDelivery')

                counter = 2
                for data in self.headersData:
                    worksheet.write('A' + str(counter), data['Vessel'])
                    worksheet.write('B' + str(counter), data['PortOfLoading'])
                    worksheet.write('C' + str(counter), data['FinalDestination'])
                    worksheet.write('D' + str(counter), data['PlaceOfDelivery'])

            if len(self.detailsData) > 0:
                worksheet = workbook.add_worksheet()
                worksheet.name = "Details Data"

                worksheet.write('A1', 'MarksAndNo')
                worksheet.write('B1', 'Package')
                worksheet.write('C1', 'Description')

                counter = 2
                for data in self.detailsData:
                    worksheet.write('A' + str(counter), data['MarksAndNo'])
                    worksheet.write('B' + str(counter), data['Package'])
                    worksheet.write('C' + str(counter), data['Description'])
                    counter = counter + 1

            workbook.close()
        except Exception as err:
            self.obj_common.write_log(f"Error in write_to_excel function: -{str(err)}")
