import tkinter as tk
from PIL import ImageGrab


class SnapshotApp:

    def __init__(self, root):
        self.root = root
        self.root.title("Snapshot App")
        self.start_x = None
        self.start_y = None
        self.rect = None

        self.canvas = tk.Canvas(root, width=800, height=600)
        self.canvas.pack()

        self.canvas.bind("<ButtonPress-1>", self.on_button_press)
        self.canvas.bind("<B1-Motion>", self.on_mouse_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_button_release)

    def on_button_press(self, event):
        self.start_x = event.x
        self.start_y = event.y
        self.rect = self.canvas.create_rectangle(self.start_x, self.start_y, self.start_x, self.start_y, outline='red')

    def on_mouse_drag(self, event):
        cur_x, cur_y = (event.x, event.y)
        self.canvas.coords(self.rect, self.start_x, self.start_y, cur_x, cur_y)

    def on_button_release(self, event):
        end_x, end_y = (event.x, event.y)
        self.take_snapshot(self.start_x, self.start_y, end_x, end_y)

    def take_snapshot(self, x1, y1, x2, y2):
        x1 = self.root.winfo_rootx() + x1
        y1 = self.root.winfo_rooty() + y1
        x2 = self.root.winfo_rootx() + x2
        y2 = self.root.winfo_rooty() + y2
        ImageGrab.grab(bbox=(x1, y1, x2, y2)).save("snapshot.png")


if __name__ == "__main__":
    main_root = tk.Tk()
    app = SnapshotApp(main_root)
    main_root.mainloop()
