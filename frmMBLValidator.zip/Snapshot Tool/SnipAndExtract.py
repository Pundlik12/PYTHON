import pyautogui
from PIL import Image
from pynput import mouse
import pyautogui
from PIL import Image

# Get the mouse position
mouse_x, mouse_y = pyautogui.position()

# Select a region by dragging the mouse
print("Select a region by dragging the mouse...")
pyautogui.dragTo(mouse_x + 100, mouse_y + 100, duration=0.5)

# Get the selected region's coordinates
region = pyautogui.position()
print("Selected region:", region)

# Take a screenshot of the selected region
image = pyautogui.screenshot(region=(region[0], region[1], 100, 100))

# Save the screenshot to a file
image.save('snip.png')


def on_click(x, y, button, pressed):
    if pressed:
        # Take a screenshot of the selected region
        img = pyautogui.screenshot(region=(x, y, 100, 100))
        img.save('snip.png')


listener = mouse.Listener(on_click=on_click)
listener.start()
listener.join()
