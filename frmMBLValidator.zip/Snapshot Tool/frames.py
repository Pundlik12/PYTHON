import tkinter as tk

root = tk.Tk()
root.title("Nested Frames Example")

# Create main frame
main_frame = tk.Frame(root, bg="lightgrey", padx=10, pady=10)
main_frame.pack(padx=20, pady=20)

# Create top frame
top_frame = tk.Frame(main_frame, bg="lightblue", padx=5, pady=5)
top_frame.pack(fill=tk.X)

# Create bottom frame
bottom_frame = tk.Frame(main_frame, bg="lightgreen", padx=5, pady=5)
bottom_frame.pack(fill=tk.X)

# Add widgets to top frame
label1 = tk.Label(top_frame, text="Top Frame")
label1.pack()

# Add widgets to bottom frame
label2 = tk.Label(bottom_frame, text="Bottom Frame")
label2.pack()

root.mainloop()
