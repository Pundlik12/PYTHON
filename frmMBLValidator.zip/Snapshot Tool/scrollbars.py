import tkinter as tk

root = tk.Tk()
root.title("Canvas with Vertical Scrollbar")

# Create a frame to hold the canvas and scrollbar
frame = tk.Frame(root)
frame.pack(fill=tk.BOTH, expand=True)

# Create a canvas widget
canvas = tk.Canvas(frame, bg="white")
canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

# Create a vertical scrollbar linked to the canvas
v_scrollbar = tk.Scrollbar(frame, orient=tk.VERTICAL, command=canvas.yview)
v_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

# Configure the canvas to use the scrollbar
canvas.config(yscrollcommand=v_scrollbar.set)

# Create a frame inside the canvas to hold other widgets
inner_frame = tk.Frame(canvas, bg="lightgrey")
canvas.create_window((0, 0), window=inner_frame, anchor="nw")

# Add some content to the inner frame
for i in range(50):
    tk.Label(inner_frame, text=f"Label {i+1}").pack()

# Update the scroll region to include the inner frame
inner_frame.update_idletasks()
canvas.config(scrollregion=canvas.bbox("all"))

root.mainloop()
