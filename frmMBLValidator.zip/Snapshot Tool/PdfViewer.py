import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk, ImageGrab
import fitz  # PyMuPDF


class PDFViewer:

    def __init__(self):
        # super().__init__()
        self.root = tk.Tk()
        self.root.title("PDF Viewer")
        # self.geometry("800x600")
        self.screen_width = self.root.winfo_screenwidth()
        self.screen_height = self.root.winfo_screenheight()
        self.root.geometry(f"{self.screen_width}x{self.screen_height}+0+0")

        self.start_x = None
        self.start_y = None
        self.rect = None

        # self.canvas = tk.Canvas(self, width=800, height=600)
        self.canvas = tk.Canvas(self.root, bg="white")
        self.canvas.pack(fill=tk.BOTH, expand=True)

        self.canvas.bind("<ButtonPress-1>", self.on_button_press)
        self.canvas.bind("<B1-Motion>", self.on_mouse_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_button_release)

        self.open_button = tk.Button(self.root, text="Open PDF", command=self.open_pdf)
        self.open_button.pack(side=tk.BOTTOM)

        self.root.mainloop()

    def on_button_press(self, event):
        self.start_x = event.x
        self.start_y = event.y
        self.rect = self.canvas.create_rectangle(self.start_x, self.start_y, self.start_x, self.start_y, outline='red')

    def on_mouse_drag(self, event):
        cur_x, cur_y = (event.x, event.y)
        self.canvas.coords(self.rect, self.start_x, self.start_y, cur_x, cur_y)

    def on_button_release(self, event):
        end_x, end_y = (event.x, event.y)
        self.take_snapshot(self.start_x, self.start_y, end_x, end_y)

    def take_snapshot(self, x1, y1, x2, y2):
        # x1 = self.root.winfo_rootx() + x1
        # y1 = self.root.winfo_rooty() + y1
        # x2 = self.root.winfo_rootx() + x2
        # y2 = self.root.winfo_rooty() + y2
        ImageGrab.grab(bbox=(x1, y1, x2, y2)).save("snapshot.png")

    def open_pdf(self):
        file_path = filedialog.askopenfilename(filetypes=[("PDF files", "*.pdf")])
        if file_path:
            self.display_pdf(file_path)

    def display_pdf(self, file_path):
        doc = fitz.open(file_path)
        page = doc.load_page(0)  # Load the first page
        pix = page.get_pixmap()
        img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
        img_tk = ImageTk.PhotoImage(img)

        self.canvas.create_image(0, 0, anchor=tk.NW, image=img_tk)
        self.canvas.image = img_tk


if __name__ == "__main__":
    app = PDFViewer()
    # app.mainloop()
