import tkinter as tk
from PIL import Image, ImageTk


def zoom(event):
    scale = 1.0
    if event.delta > 0:  # Zoom in
        scale = 1.1
    elif event.delta < 0:  # Zoom out
        scale = 0.9
    canvas.scale("all", event.x, event.y, scale, scale)
    canvas.configure(scrollregion=canvas.bbox("all"))


root = tk.Tk()
root.title("Zoom In/Out Example")

# Create a frame to hold the canvas and scrollbar
frame = tk.Frame(root)
frame.pack(fill=tk.BOTH, expand=True)

# Create a canvas widget
canvas = tk.Canvas(frame, bg="white")
canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

# Create a vertical scrollbar linked to the canvas
v_scrollbar = tk.Scrollbar(frame, orient=tk.VERTICAL, command=canvas.yview)
v_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

# Configure the canvas to use the scrollbar
canvas.config(yscrollcommand=v_scrollbar.set)

# Load the image using PIL
image = Image.open("path_to_your_image.jpg")
photo = ImageTk.PhotoImage(image)

# Add the image to the canvas
canvas.create_image(0, 0, image=photo, anchor="nw")

# Update the scroll region to include the image
canvas.config(scrollregion=canvas.bbox("all"))

# Bind the mouse wheel event to the zoom function
canvas.bind("<MouseWheel>", zoom)

root.mainloop()
