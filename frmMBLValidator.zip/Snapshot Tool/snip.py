import os
import cv2
import fitz  # PyMuPDF
import tkinter as tk
from tkinter import filedialog, messagebox
import numpy as np
import pytesseract
from PIL import Image, ImageTk


class SnippingTool:
    pdf_document = None
    page_counter = 0
    total_pages = 0
    start_x = 0
    start_y = 0
    strTesseractBinariesPath = ""

    def __init__(self):
        self.pdf_document = None
        self.page_counter = 0
        self.total_pages = 0
        self.start_x = 0
        self.start_y = 0

        self.strTesseractBinariesPath = os.getcwd() + r'\Tesseract-OCR\tesseract.exe'
        if not os.path.isfile(self.strTesseractBinariesPath):
            print(self.strTesseractBinariesPath)
        else:
            pytesseract.pytesseract.tesseract_cmd = self.strTesseractBinariesPath

        self.root = tk.Tk()
        self.root.title("PDF Viewer")

        screen_width = int(self.root.winfo_screenwidth() / 2)
        screen_height = self.root.winfo_screenheight()
        self.root.geometry(f"{screen_width}x{screen_height}+0+0")
        self.root.resizable(False, False)
        self.center_window()

        main_frame = tk.Frame(self.root, width=300, height=200, bg="lightgrey", padx=5, pady=5)
        main_frame.pack(padx=5, pady=5)

        open_button = tk.Button(main_frame, width=10, text="Open PDF", command=self.open_pdf)
        # open_button.pack()
        open_button.grid(row=0, column=1, sticky=tk.W)

        self.next_button = tk.Button(main_frame, width=10, text="Next >>", command=self.next_page)
        # self.next_button.pack()
        self.next_button.grid(row=0, column=2, sticky=tk.W)
        self.next_button.config(state="disabled")

        self.previous_button = tk.Button(main_frame, width=10, text="Previous <<", command=self.previous_page)
        # self.previous_button.pack()
        self.previous_button.grid(row=0, column=3, sticky=tk.W)
        self.previous_button.config(state="disabled")

        page = tk.Label(main_frame, text="Page ")
        page.grid(row=0, column=4, sticky=tk.W)

        self.active_page_number = tk.Text(main_frame, width=3, height=1, font=('Verdana', 10))
        self.active_page_number.grid(row=0, column=5, padx=2, pady=2, sticky=tk.W)
        self.active_page_number.insert(tk.END, 1)
        self.active_page_number.config(state="disabled")

        page_off = tk.Label(main_frame, text=" Out Of ")
        page_off.grid(row=0, column=6, sticky=tk.W)

        self.page_count = tk.Label(main_frame, text="1")
        self.page_count.grid(row=0, column=7, sticky=tk.W)

        self.bottom_frame = tk.Frame(self.root, bg="lightgrey", padx=5, pady=5)
        # self.bottom_frame.pack(padx=5, pady=5)
        self.bottom_frame.pack(fill=tk.BOTH, expand=True)

        self.canvas = tk.Canvas(self.bottom_frame, width=600, height=600)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        # self.canvas.grid(row=1, column=0, columnspan=10, sticky=tk.NSEW)

        v_scrollbar = tk.Scrollbar(self.bottom_frame, width=20, orient=tk.VERTICAL, command=self.canvas.yview)
        v_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.canvas.config(yscrollcommand=v_scrollbar.set, scrollregion=self.canvas.bbox("all"))
        self.canvas.bind("<MouseWheel>", self.zoom)

        self.canvas.bind("<ButtonPress-1>", self.on_mouse_down)
        self.canvas.bind("<ButtonRelease-1>", self.on_mouse_up)

        self.root.mainloop()

    def center_window(self):
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')

    def open_pdf(self):
        file_path = filedialog.askopenfilename(filetypes=[("PDF files", "*.pdf")])
        if file_path:
            self.next_button.config(state="normal")
            self.previous_button.config(state="normal")
            self.pdf_document = fitz.open(file_path)
            self.page_counter = 1
            self.total_pages = self.pdf_document.page_count
            self.page_count.config(text=self.total_pages)

            self.display_page(self.page_counter - 1)

            self.bottom_frame.update_idletasks()
            self.canvas.config(scrollregion=self.canvas.bbox("all"))

    def zoom(self, event):
        scale = 1.0
        if event.delta > 0:  # Zoom in
            scale = 1.1
        elif event.delta < 0:  # Zoom out
            scale = 0.9

        self.canvas.scale("all", event.x, event.y, scale, scale)
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def next_page(self):
        if self.page_counter < self.total_pages:
            self.page_counter = self.page_counter + 1
            self.active_page_number.config(state="normal")
            self.active_page_number.delete("1.0", tk.END)
            self.active_page_number.insert(tk.END, self.page_counter)
            self.active_page_number.config(state="disabled")
            self.display_page(self.page_counter - 1)

    def previous_page(self):
        if self.page_counter > 1:
            self.page_counter = self.page_counter - 1
            self.active_page_number.config(state="normal")
            self.active_page_number.delete("1.0", tk.END)
            self.active_page_number.insert(tk.END, self.page_counter)
            self.active_page_number.config(state="disabled")
            self.display_page(self.page_counter - 1)

    def display_page(self, page_num):
        page = self.pdf_document.load_page(page_num)
        pix = page.get_pixmap()
        img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
        img_tk = ImageTk.PhotoImage(img)
        self.canvas.create_image(0, 0, anchor=tk.NW, image=img_tk)
        self.canvas.image = img_tk

    def on_mouse_down(self, event):
        self.start_x, self.start_y = event.x, event.y

    def on_mouse_up(self, event):
        end_x, end_y = event.x, event.y
        self.take_snapshot(self.start_x, self.start_y, end_x, end_y)

    def take_snapshot(self, x1, y1, x2, y2):
        page = self.pdf_document.load_page(0)
        pix = page.get_pixmap()
        img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
        cropped_img = img.crop((x1, y1, x2, y2))
        extracted_text = pytesseract.image_to_string(cropped_img)
        messagebox.showinfo(title="Extract", message="data:-" + extracted_text, parent=self.root)
        # cropped_img.show()  # Display the snapshot

    def preprocess_image(self, image):
        try:
            # Normalize
            norm_img = np.zeros((image.shape[0], image.shape[1]))
            image = cv2.normalize(image, norm_img, 0, 255, cv2.NORM_MINMAX)

            # Convert to grayscale
            gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

            # Binarize
            _, binary_image = cv2.threshold(gray_image, 128, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)

            # Remove noise
            binary_image = cv2.medianBlur(binary_image, 3)

            # Skew correction
            co_ords = np.column_stack(np.where(binary_image > 0))
            angle = cv2.minAreaRect(co_ords)[-1]
            if angle < -45:
                angle = -(90 + angle)
            else:
                angle = -angle

            (h, w) = binary_image.shape[:2]
            center = (w // 2, h // 2)
            M = cv2.getRotationMatrix2D(center, angle, 1.0)
            binary_image = cv2.warpAffine(binary_image, M, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)

            # Dilation and erosion
            kernel = np.ones((1, 1), np.uint8)
            binary_image = cv2.dilate(binary_image, kernel, iterations=1)
            binary_image = cv2.erode(binary_image, kernel, iterations=1)

            # Optional: Edge detection
            edges = cv2.Canny(binary_image, 100, 200)

            return binary_image
        except Exception as err:
            self.obj_common.write_log(f"Error in preprocess_image function: -{str(err)}")


obj = SnippingTool()
