import os
import tkinter
from tkinter import *
from datetime import date
from tkinter import filedialog
from tkinter import messagebox
from tkinter.messagebox import askyesno
from ExtractMBLFileData import ExtractMBLDataOCR
from ExtractMBLPdfText import ExtractMBLData
from ExtractSIFileData import ExtractSIDataOCR
from ExtractSIPdfText import ExtractSIData


def validate_form():
    icon_path = os.getcwd() + r"\Images\Download.ico"
    if os.path.isfile(icon_path) is False:
        messagebox.showinfo("MBL/SI PDF Data Extractor", "Images folder is missing in startup path.")
        exit()


def check_expiry():
    expiry_date = date(2026, 12, 30)
    if expiry_date < date.today():
        messagebox.showinfo("MBL/SI PDF Data Extractor",
                            "The application has been expired please contact the WFM team for renewal")
        exit()


class MBLDataValidator:

    def __init__(self):
        self.root = tkinter.Tk()
        self.root.title('MBL/SI PDF Data Extractor')
        self.root.resizable(width=NO, height=NO)

        if os.path.isfile(os.getcwd() + r"\Images\Download.ico"):
            self.root.iconbitmap(os.getcwd() + r"\Images\Download.ico")

        # Calculate the screen dimensions
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()

        # Calculate the window dimensions
        window_width = 920
        window_height = 220

        # Calculate the window position
        x = (screen_width - window_width) // 2
        y = (screen_height - window_height) // 2

        # Set the window size and position
        self.root.geometry(f"{window_width}x{window_height}+{x}+{y}")

        top_frame = Frame(self.root, bg="pink", height=20)
        top_frame.pack(side=TOP, fill="x")

        lbl_header = Label(top_frame, text="MBL/SI PDF Data Extractor", highlightthickness=0, background="pink",
                           bd=0, justify=CENTER, width=50)
        lbl_header.grid(row=0, column=1, padx=5, pady=5, columnspan=3)
        lbl_header.config(font=('Verdana', 20))

        middle_frame = Frame(self.root, height=510)  # bg="gray",
        middle_frame.pack(side=TOP, fill="both")

        lbl_mbl_button = Label(middle_frame, text="MBL file path:-", justify=CENTER, width=20)
        lbl_mbl_button.grid(row=2, column=1, padx=2, pady=2, sticky=E)
        lbl_mbl_button.config(font=('Verdana', 10))

        self.txt_MBL_file_path = Text(middle_frame, width=70, height=2, font=('Verdana', 10))
        self.txt_MBL_file_path.grid(row=2, column=3, padx=2, pady=2, sticky=W)
        self.txt_MBL_file_path.config(state="disabled")

        btn_browse_mbl = Button(middle_frame, text="Browse", width=14, height=2, font=('Verdana', 12),
                                justify=CENTER
                                , command=self.browse_mbl_file, bg="#ffbf00")
        btn_browse_mbl.grid(row=2, column=4, padx=2, pady=2)

        lbl_si_button = Label(middle_frame, text="SI file path:-", justify=CENTER, width=20)
        lbl_si_button.grid(row=3, column=1, padx=2, pady=2, sticky=E)
        lbl_si_button.config(font=('Verdana', 10))

        self.txt_SI_file_path = Text(middle_frame, width=70, height=2, font=('Verdana', 10))
        self.txt_SI_file_path.grid(row=3, column=3, padx=2, pady=2, sticky=W)
        self.txt_SI_file_path.config(state="disabled")

        btn_browse_si = Button(middle_frame, text="Browse", width=14, height=2, font=('Verdana', 12), justify=CENTER
                               , command=self.browse_si_file, bg="#ffbf00")
        btn_browse_si.grid(row=3, column=4, padx=2, pady=2)

        btn_extract = Button(middle_frame, text="Extract Data", width=14, height=2, font=('Verdana', 12),
                             justify=CENTER
                             , command=self.extract_data, bg="#ffbf00")
        btn_extract.grid(row=4, column=3, padx=2, pady=2, sticky=W)

        self.root.mainloop()

    def browse_si_file(self):
        initial_directory = os.getcwd()
        selected_directory = filedialog.askopenfilename(parent=self.root, initialdir=initial_directory,
                                                        title='Select SI input file.',
                                                        filetypes=(("Excel files", "*.pdf*"), ("all files", "*.pdf*")))

        if selected_directory is not None and selected_directory != "":
            self.txt_SI_file_path.config(state="normal")
            self.txt_SI_file_path.delete("1.0", END)
            self.txt_SI_file_path.insert(END, selected_directory.replace('/', '\\'))
            self.txt_SI_file_path.config(state="disabled")
        else:
            self.txt_SI_file_path.config(state="normal")
            self.txt_SI_file_path.delete("1.0", END)
            self.txt_SI_file_path.config(state="disabled")

    def browse_mbl_file(self):
        initial_directory = os.getcwd()
        selected_directory = filedialog.askopenfilename(parent=self.root, initialdir=initial_directory,
                                                        title='Select MBL input file.',
                                                        filetypes=(("Excel files", "*.pdf*"), ("all files", "*.pdf*")))

        if selected_directory is not None and selected_directory != "":
            self.txt_MBL_file_path.config(state="normal")
            self.txt_MBL_file_path.delete("1.0", END)
            self.txt_MBL_file_path.insert(END, selected_directory.replace('/', '\\'))
            self.txt_MBL_file_path.config(state="disabled")
        else:
            self.txt_MBL_file_path.config(state="normal")
            self.txt_MBL_file_path.delete("1.0", END)
            self.txt_MBL_file_path.config(state="disabled")

    def extract_data(self):
        str_tesseract_binaries_path = os.getcwd() + r'\\Tesseract-OCR\\tesseract.exe'
        if not os.path.isfile(str_tesseract_binaries_path):
            messagebox.showinfo(title="MBL/SI PDF Data Extractor", message="OCR engine is not configured.", parent=self.root)
            return
        else:
            if not os.path.exists('Processing'):
                os.makedirs('Processing')

        self.txt_MBL_file_path.config(state="normal")
        mbl_file_path_variable = self.txt_MBL_file_path.get(1.0, END).replace('\n', '')
        self.txt_MBL_file_path.config(state="disabled")

        self.txt_SI_file_path.config(state="normal")
        si_file_path_variable = self.txt_SI_file_path.get(1.0, END).replace('\n', '')
        self.txt_SI_file_path.config(state="disabled")

        if mbl_file_path_variable == "" and si_file_path_variable == "":
            messagebox.showinfo(title="MBL/SI PDF Data Extractor", message="Please select the path(s) first and try again.", parent=self.root)
        else:
            result = askyesno(title="Confirm", message="Are you sure?", parent=self.root)
            if result is True:
                if mbl_file_path_variable != "":
                    # obj_mbl_ocr = ExtractMBLDataOCR()
                    # obj_mbl_ocr.convert_pdf_to_images(mbl_file_path_variable)
                    #
                    # obj_mbl = ExtractMBLData()
                    # obj_mbl.extract_text_from_pdf(mbl_file_path_variable)

                    self.txt_MBL_file_path.config(state="normal")
                    self.txt_MBL_file_path.delete("1.0", END)
                    self.txt_MBL_file_path.config(state="disabled")

                if si_file_path_variable != "":
                    obj_si_ocr = ExtractSIDataOCR()
                    obj_si_ocr.convert_pdf_to_images(si_file_path_variable)

                    obj_si = ExtractSIData()
                    obj_si.extract_text_from_pdf(si_file_path_variable)

                    self.txt_SI_file_path.config(state="normal")
                    self.txt_SI_file_path.delete("1.0", END)
                    self.txt_SI_file_path.config(state="disabled")

                messagebox.showinfo(title="MBL/SI PDF Data Extractor", message="PDF data extraction process completed.", parent=self.root)


check_expiry()
validate_form()
obj = MBLDataValidator()
