import tkinter as tk
from tkinter import scrolledtext, messagebox
import threading
import socket

# Constants
PORT = 5005
BUFFER_SIZE = 1024

# Listener thread function
def listen_for_messages(text_area):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(("", PORT))
    while True:
        try:
            data, addr = sock.recvfrom(BUFFER_SIZE)
            message = f"{addr[0]}: {data.decode()}\n"
            text_area.config(state='normal')
            text_area.insert(tk.END, message)
            text_area.config(state='disabled')
        except Exception as e:
            print("Error:", e)

# GUI creation
def create_gui():
    window = tk.Tk()
    window.title("IP Messenger")

    text_area = scrolledtext.ScrolledText(window, width=50, height=20, state='disabled')
    text_area.pack(padx=10, pady=10)

    entry = tk.Entry(window, width=40)
    entry.pack(side=tk.LEFT, padx=(10,0), pady=(0,10))

    ip_entry = tk.Entry(window, width=15)
    ip_entry.insert(0, "127.0.0.1")  # Default IP
    ip_entry.pack(side=tk.LEFT, padx=(0,10), pady=(0,10))

    def send_message():
        msg = entry.get()
        ip = ip_entry.get()
        if not msg:
            messagebox.showwarning("Warning", "Message cannot be empty.")
            return
        entry.delete(0, tk.END)
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.sendto(msg.encode(), (ip, PORT))
        text_area.config(state='normal')
        text_area.insert(tk.END, f"You: {msg}\n")
        text_area.config(state='disabled')

    send_btn = tk.Button(window, text="Send", command=send_message)
    send_btn.pack(side=tk.LEFT, pady=(0,10))

    # Start listening thread
    listener_thread = threading.Thread(target=listen_for_messages, args=(text_area,), daemon=True)
    listener_thread.start()

    window.mainloop()
