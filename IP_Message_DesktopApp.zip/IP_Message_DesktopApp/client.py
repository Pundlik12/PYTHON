import socket

def send_message(message, target_ip):
    client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    client.sendto(message.encode(), (target_ip, 12345))
