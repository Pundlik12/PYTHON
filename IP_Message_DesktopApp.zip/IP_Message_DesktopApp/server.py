import socket
import threading

def listen_for_messages():
    server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server.bind(('', 12345))
    while True:
        msg, addr = server.recvfrom(1024)
        print(f"\n[{addr[0]}]: {msg.decode()}")

def start_server():
    thread = threading.Thread(target=listen_for_messages)
    thread.daemon = True
    thread.start()
