import graphviz

# Define the user flow as a list of tuples
user_flow = [
    ('User visits landing page', 'User clicks "Shop Now" button'),
    ('User clicks "Shop Now" button', 'User views product category page'),
    ('User views product category page', 'User clicks on a product'),
    ('User clicks on a product', 'User views product page'),
    ('User views product page', 'User adds product to cart'),
    ('User adds product to cart', 'User views cart'),
    ('User views cart', 'User clicks "Checkout" button'),
    ('User clicks "Checkout" button', 'User enters shipping information'),
    ('User enters shipping information', 'User enters payment information'),
    ('User enters payment information', 'User clicks "Place Order" button'),
    ('User clicks "Place Order" button', 'User sees confirmation page')
]

# Define the graph and its properties
dot = graphviz.Digraph(comment='User Flow Diagram')
dot.attr('node', shape='note')

# Add the nodes and edges to the graph
for item in user_flow:
    dot.node(item[0])
    dot.node(item[1])
    dot.edge(item[0], item[1])

# Render the graph and save it to a file
dot.render('user_flow', view=True)
