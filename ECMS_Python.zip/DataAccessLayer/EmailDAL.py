import pyodbc
from tkinter import messagebox
from DataAccessLayer.DbConnection import DbConnection


class EmailDataAccess(DbConnection):

    def __init__(self):
        super().__init__()
        self.listEmails = []

    def get_email_details(self):
        try:
            self.connCursor.execute("SELECT MailBoxName, SenderEmailAddress, ReceivedTime, SubjectLine, Priority, Status, AttachementCount, EntryID, ConverstationID, OutlookEmailID FROM OutlookEmails")
            self.listEmails = self.connCursor.fetchall()
        except pyodbc.Error as e:
            messagebox.showinfo("Ryder COI Extraction Tool", "Error fetching email details from DB\n" + str(e))
        finally:
            if 'cursor' in locals():
                self.connCursor.close()
            if 'connection' in locals():
                self.connObject.close()
        return self.listEmails

    def get_email_details_by_entryID(self, entryID):
        try:
            str_query = "SELECT MailBoxName, SenderEmailAddress, ReceivedTime, SubjectLine, Priority, Status, AttachementCount, EntryID, ConverstationID, OutlookEmailID FROM OutlookEmails WHERE EntryID = '" + entryID + "'"
            self.connCursor.execute(str_query)
            self.listEmails = self.connCursor.fetchall()
        except pyodbc.Error as e:
            messagebox.showinfo("Ryder COI Extraction Tool", "Error fetching email details from DB\n" + str(e))
        finally:
            if 'cursor' in locals():
                self.connCursor.close()
            if 'connection' in locals():
                self.connObject.close()
        return self.listEmails

    def add_email_details(self, email_details):
        try:
            for item in email_details:
                MailBoxName = str(item[0])
                SenderEmailAddress = str(item[1])
                ReceivedTime = str(item[2])
                SubjectLine = str(item[3])
                Priority = str(item[4])
                Status = str(item[5])
                AttachementCount = str(item[6])
                EntryID = str(item[7])
                ConverstationID = str(item[8])

                sql_query = f"INSERT INTO OutlookEmails (MailBoxName, SenderEmailAddress, ReceivedTime, SubjectLine, Priority, Status, AttachementCount, EntryID, ConverstationID)"
                sql_query = sql_query + f" VALUES ('{MailBoxName}','{SenderEmailAddress}','{ReceivedTime}','{SubjectLine}','{Priority}','{Status}','{AttachementCount}','{EntryID}','{ConverstationID}')"

                self.connCursor.execute(sql_query)
                self.connObject.commit()
        except Exception as error:
            messagebox.showinfo("Ryder COI Extraction Tool", "Error inserting email details into DB\n" + str(error))
        finally:
            if 'cursor' in locals():
                self.connCursor.close()
            if 'connection' in locals():
                self.connObject.close()

    def update_email_details(self, email_details):
        try:
            for item in email_details:
                MailBoxName = str(item[0])
                SenderEmailAddress = str(item[1])
                ReceivedTime = str(item[2])
                SubjectLine = str(item[3])
                Priority = str(item[4])
                Status = str(item[5])
                AttachementCount = str(item[6])
                EntryID = str(item[7])
                ConverstationID = str(item[8])

                sql_query = f"UPDATE OutlookEmails SET MailBoxName = '{MailBoxName}', SenderEmailAddress = '{SenderEmailAddress}', ReceivedTime = '{ReceivedTime}',"
                sql_query = sql_query + f"SubjectLine = '{SubjectLine}', Priority = '{Priority}', Status = '{Status}', AttachementCount = '{AttachementCount}' "
                sql_query = sql_query + f"WHERE EntryID = '{EntryID}'"

                self.connCursor.execute(sql_query)
                self.connObject.commit()
        except pyodbc.Error as error:
            messagebox.showinfo("Ryder COI Extraction Tool", "Error updating email details into DB\n" + str(error))
        finally:
            if 'cursor' in locals():
                self.connCursor.close()
            if 'connection' in locals():
                self.connObject.close()

    def delete_email_details(self, entryID):
        try:
            sql_query = f"DELETE FROM OutlookEmails WHERE EntryID = '{entryID}'"
            self.connCursor.execute(sql_query)
            self.connObject.commit()
        except pyodbc.Error as error:
            messagebox.showinfo("Ryder COI Extraction Tool", "Error deleting email details from DB\n" + str(error))
        finally:
            if 'cursor' in locals():
                self.connCursor.close()
            if 'connection' in locals():
                self.connObject.close()
