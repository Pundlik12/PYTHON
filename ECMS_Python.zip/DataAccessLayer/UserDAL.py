import datetime
import pyodbc
from tkinter import messagebox
from DataAccessLayer.DbConnection import DbConnection


class UserDataAccess(DbConnection):

    def __init__(self):
        super().__init__()
        self.listUsers = []

    def get_user_details(self):
        try:
            self.connCursor.execute("SELECT ID, UserName, UID, Pass, Role, IsActive, EntryUser, EntryDateTime FROM UserDetails")
            self.listUsers = self.connCursor.fetchall()
        except pyodbc.Error as e:
            messagebox.showinfo("Ryder COI Extraction Tool", "Error fetching user details from DB\n" + str(e))
        finally:
            if 'cursor' in locals():
                self.connCursor.close()
            if 'connection' in locals():
                self.connObject.close()
        return self.listUsers

    def get_user_details_by_UID(self, UID):
        try:
            str_query = "SELECT ID, UserName, UID, Pass, Role, IsActive, EntryUser, EntryDateTime FROM UserDetails WHERE UID = '" + UID + "'"
            self.connCursor.execute(str_query)
            self.listUsers = self.connCursor.fetchall()
        except pyodbc.Error as e:
            messagebox.showinfo("Ryder COI Extraction Tool", "Error fetching user details from DB\n" + str(e))
        finally:
            if 'cursor' in locals():
                self.connCursor.close()
            if 'connection' in locals():
                self.connObject.close()
        return self.listUsers

    def add_user_details(self, user_details):
        try:
            for item in user_details:
                UserName = str(item[0])
                UID = str(item[1])
                Password = str(item[2])
                Role = str(item[3])
                IsActive = str(item[4])
                EntryUser = str(item[5])
                EntryDateTime = datetime.datetime

                sql_query = f"INSERT INTO UserDetails (UserName, UID, Pass, Role, IsActive, EntryUser, EntryDateTime)"
                sql_query = sql_query + f" VALUES ('{UserName}','{UID}','{Password}','{Role}','{IsActive}','{EntryUser}','{EntryDateTime}')"

                self.connCursor.execute(sql_query)
                self.connObject.commit()
        except Exception as error:
            messagebox.showinfo("Ryder COI Extraction Tool", "Error inserting user details into DB\n" + str(error))
        finally:
            if 'cursor' in locals():
                self.connCursor.close()
            if 'connection' in locals():
                self.connObject.close()

    def update_user_details(self, user_details):
        try:
            for item in user_details:
                UserName = str(item[0])
                UID = str(item[1])
                Password = str(item[2])
                Role = str(item[3])
                IsActive = str(item[4])
                EntryUser = str(item[5])
                EntryDateTime = datetime.datetime

                sql_query = f"UPDATE UserDetails SET UserName = '{UserName}', Pass = '{Password}',"
                sql_query = sql_query + f"Role = '{Role}', IsActive = '{IsActive}', EntryUser = '{EntryUser}', EntryDateTime = '{EntryDateTime}' "
                sql_query = sql_query + f"WHERE UID = '{UID}'"

                self.connCursor.execute(sql_query)
                self.connObject.commit()
        except pyodbc.Error as error:
            messagebox.showinfo("Ryder COI Extraction Tool", "Error updating user details into DB\n" + str(error))
        finally:
            if 'cursor' in locals():
                self.connCursor.close()
            if 'connection' in locals():
                self.connObject.close()

    def delete_user_details(self, UID):
        try:
            sql_query = f"DELETE FROM UserDetails WHERE UID = '{UID}'"
            self.connCursor.execute(sql_query)
            self.connObject.commit()
        except pyodbc.Error as error:
            messagebox.showinfo("Ryder COI Extraction Tool", "Error deleting user details from DB\n" + str(error))
        finally:
            if 'cursor' in locals():
                self.connCursor.close()
            if 'connection' in locals():
                self.connObject.close()
