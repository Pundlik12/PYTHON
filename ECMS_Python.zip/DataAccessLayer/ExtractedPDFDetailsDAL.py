import pyodbc
from tkinter import messagebox
from DataAccessLayer.DbConnection import DbConnection


class ExtractedDataDataAccess(DbConnection):

    def __init__(self):
        super().__init__()
        self.listExtractedPDFDetails = []

    def get_extracted_pdf_details(self):
        try:
            str_query = "SELECT ExtractedDataID, EntryID, FileName, PRODUCER, INSURED_NAME, INSURED_ADDRESS, CONTACT_NAME, EMAIL_ADDRESS, PHONE_NUMBER, FAX_NUMBER,"
            str_query = str_query + "INSURER_A, NAIC_A, INSURER_B, NAIC_B, INSURER_C, NAIC_C, INSURER_D, NAIC_D, INSURER_E, NAIC_E, INSURER_F, NAIC_F, CERTIFICATE_NUMBER, REVISION_NUMBER,"
            str_query = str_query + "INSR_LTR_A, INS_LTR_A, INS_LTR_B, INS_LTR_C, INS_LTR_D, INS_LTR_E, INS_LTR_F, COMBINED_SINGLE_LIMIT, DESCRIPTION, CERTIFICATE_HOLDER, COMMERCIAL_GENERAL_LIABLITY,"
            str_query = str_query + "POLICY_NUMBER, ADDL_INSD, EFFECTIVE_DATE, EXPIRY_DATE, HIRED_AUTOS_ONLY_TEXT, ANY_AUTO_TEXT, SCHEDULED_AUTOS_TEXT, OWNED_AUTOS_ONLY_TEXT, NON_OWNED_AUTO_ONLY_TEXT,"
            str_query = str_query + "LIABILITY, NON_TRUCKING, NAMED_INSURED, DESCRIPTION_PAGE2, COLL_COMP, SIGNATURE FROM ExtractedPDFDetails"

            self.connCursor.execute(str_query)
            self.listExtractedPDFDetails = self.connCursor.fetchall()
        except pyodbc.Error as e:
            messagebox.showinfo("Email Management Tool", "Error in fetching extracted_email_details from DB\n" + str(e))
        finally:
            if 'cursor' in locals():
                self.connCursor.close()
            if 'connection' in locals():
                self.connObject.close()
        return self.listExtractedPDFDetails

    def get_extracted_pdf_details_by_ID(self, OutlookEmailID):
        try:
            str_query = "SELECT ExtractedDataID, OutlookEmailID, EntryID, FileName, PRODUCER, INSURED_NAME, INSURED_ADDRESS, CONTACT_NAME, EMAIL_ADDRESS, PHONE_NUMBER, FAX_NUMBER,"
            str_query = str_query + "INSURER_A, NAIC_A, INSURER_B, NAIC_B, INSURER_C, NAIC_C, INSURER_D, NAIC_D, INSURER_E, NAIC_E, INSURER_F, NAIC_F, CERTIFICATE_NUMBER, REVISION_NUMBER,"
            str_query = str_query + "INSR_LTR_A, INS_LTR_A, INS_LTR_B, INS_LTR_C, INS_LTR_D, INS_LTR_E, INS_LTR_F, COMBINED_SINGLE_LIMIT, DESCRIPTION, CERTIFICATE_HOLDER, COMMERCIAL_GENERAL_LIABLITY,"
            str_query = str_query + "POLICY_NUMBER, ADDL_INSD, EFFECTIVE_DATE, EXPIRY_DATE, HIRED_AUTOS_ONLY_TEXT, ANY_AUTO_TEXT, SCHEDULED_AUTOS_TEXT, OWNED_AUTOS_ONLY_TEXT, NON_OWNED_AUTO_ONLY_TEXT,"
            str_query = str_query + "LIABILITY, NON_TRUCKING, NAMED_INSURED, DESCRIPTION_PAGE2, COLL_COMP, SIGNATURE FROM ExtractedPDFDetails WHER OutlookEmailID = '" + OutlookEmailID + "'"

            self.connCursor.execute(str_query)
            self.listExtractedPDFDetails = self.connCursor.fetchall()
        except pyodbc.Error as e:
            messagebox.showinfo("Email Management Tool", "Error in fetching extracted_email_details from DB\n" + str(e))
        finally:
            if 'cursor' in locals():
                self.connCursor.close()
            if 'connection' in locals():
                self.connObject.close()
        return self.listExtractedPDFDetails

    def add_extracted_pdf_details(self, extracted_pdf_details):
        try:
            for item in extracted_pdf_details:
                EntryID = str(item["Filename"]).split('_')[0]
                FileName = str(item["Filename"]).replace('.PDF', '')
                PRODUCER = str(item["PRODUCER"]).replace('None', '')
                INSURED_NAME = str(item["INSURED NAME"]).replace('None', '')
                INSURED_ADDRESS = str(item["INSURED ADDRESS"]).replace('None', '')
                CONTACT_NAME = str(item["CONTACT NAME"]).replace('None', '')
                EMAIL_ADDRESS = str(item["EMAIL ADDRESS"]).replace('None', '')
                PHONE_NUMBER = str(item["PHONE NUMBER"]).replace('None', '')
                FAX_NUMBER = str(item["FAX NUMBER"]).replace('None', '')
                INSURER_A = str(item["INSURER A"]).replace('None', '')
                NAIC_A = str(item["NAIC A"]).replace('None', '')
                INSURER_B = str(item["INSURER B"]).replace('None', '')
                NAIC_B = str(item["NAIC B"]).replace('None', '')
                INSURER_C = str(item["INSURER C"]).replace('None', '')
                NAIC_C = str(item["NAIC C"]).replace('None', '')
                INSURER_D = str(item["INSURER D"]).replace('None', '')
                NAIC_D = str(item["NAIC D"]).replace('None', '')
                INSURER_E = str(item["INSURER E"]).replace('None', '')
                NAIC_E = str(item["NAIC E"]).replace('None', '')
                INSURER_F = str(item["INSURER F"]).replace('None', '')
                NAIC_F = str(item["NAIC F"]).replace('None', '')
                CERTIFICATE_NUMBER = str(item["CERTIFICATE NUMBER"]).replace('None', '')
                REVISION_NUMBER = str(item["REVISION NUMBER"]).replace('None', '')
                INSR_LTR_A = str(item["INSR LTR A"]).replace('None', '')
                INS_LTR_A = str(item["INS LTR A"]).replace('None', '')
                INS_LTR_B = str(item["INS LTR B"]).replace('None', '')
                INS_LTR_C = str(item["INS LTR C"]).replace('None', '')
                INS_LTR_D = str(item["INS LTR D"]).replace('None', '')
                INS_LTR_E = str(item["INS LTR E"]).replace('None', '')
                INS_LTR_F = str(item["INS LTR F"]).replace('None', '')
                COMBINED_SINGLE_LIMIT = str(item["COMBINED SINGLE LIMIT"]).replace('None', '')
                DESCRIPTION = str(item["DESCRIPTION"]).replace('None', '')
                CERTIFICATE_HOLDER = str(item["CERTIFICATE HOLDER"]).replace('None', '')
                COMMERCIAL_GENERAL_LIABLITY = str(item["COMMERCIAL GENERAL LIABLITY"]).replace('None', '')
                POLICY_NUMBER = str(item["POLICY NUMBER"]).replace('None', '')
                ADDL_INSD = str(item["ADDL INSD"]).replace('None', '')
                EFFECTIVE_DATE = str(item["EFFECTIVE DATE"]).replace('None', '')
                EXPIRY_DATE = str(item["EFFECTIVE DATE 2"]).replace('None', '')
                HIRED_AUTOS_ONLY_TEXT = str(item["HIRED AUTOS ONLY TEXT"]).replace('None', '')
                ANY_AUTO_TEXT = str(item["ANY AUTO TEXT"]).replace('None', '')
                SCHEDULED_AUTOS_TEXT = str(item["SCHEDULED AUTOS TEXT"]).replace('None', '')
                OWNED_AUTOS_ONLY_TEXT = str(item["OWNED AUTOS ONLY TEXT"]).replace('None', '')
                NON_OWNED_AUTO_ONLY_TEXT = str(item["NON-OWNED AUTO ONLY TEXT"]).replace('None', '')
                LIABILITY = str(item["LIABILITY"]).replace('None', '')
                NON_TRUCKING = str(item["NON-TRUCKING"]).replace('None', '')
                NAMED_INSURED = str(item["NAMED INSURED"]).replace('None', '')
                DESCRIPTION_PAGE2 = str(item["DESCRIPTION PAGE 2"]).replace('None', '')
                COLL_COMP = str(item["COLL/COMP"]).replace('None', '')
                SIGNATURE = ""

                str_query = ""
                str_query = str_query + "INSERT INTO ExtractedPDFDetails (EntryID, FileName, PRODUCER, INSURED_NAME, INSURED_ADDRESS, CONTACT_NAME, EMAIL_ADDRESS, PHONE_NUMBER, FAX_NUMBER,"
                str_query = str_query + "INSURER_A, NAIC_A, INSURER_B, NAIC_B, INSURER_C, NAIC_C, INSURER_D, NAIC_D, INSURER_E, NAIC_E, INSURER_F, NAIC_F, CERTIFICATE_NUMBER, REVISION_NUMBER,"
                str_query = str_query + "INSR_LTR_A, INS_LTR_A, INS_LTR_B, INS_LTR_C, INS_LTR_D, INS_LTR_E, INS_LTR_F, COMBINED_SINGLE_LIMIT, DESCRIPTION, CERTIFICATE_HOLDER, COMMERCIAL_GENERAL_LIABLITY,"
                str_query = str_query + "POLICY_NUMBER, ADDL_INSD, EFFECTIVE_DATE, EXPIRY_DATE, HIRED_AUTOS_ONLY_TEXT, ANY_AUTO_TEXT, SCHEDULED_AUTOS_TEXT, OWNED_AUTOS_ONLY_TEXT, NON_OWNED_AUTO_ONLY_TEXT,"
                str_query = str_query + "LIABILITY, NON_TRUCKING, NAMED_INSURED, DESCRIPTION_PAGE2, COLL_COMP, SIGNATURE)"

                str_query = str_query + f" VALUES ('{EntryID}','{FileName}','{PRODUCER}','{INSURED_NAME}','{INSURED_ADDRESS}','{CONTACT_NAME}','{EMAIL_ADDRESS}','{PHONE_NUMBER}','{FAX_NUMBER}',"
                str_query = str_query + f" '{INSURER_A}','{NAIC_A}','{INSURER_B}','{NAIC_B}','{INSURER_C}','{NAIC_C}','{INSURER_D}','{NAIC_D}','{INSURER_E}','{NAIC_E}','{INSURER_F}','{NAIC_F}','{CERTIFICATE_NUMBER}','{REVISION_NUMBER}',"
                str_query = str_query + f" '{INSR_LTR_A}','{INS_LTR_A}','{INS_LTR_B}','{INS_LTR_C}','{INS_LTR_D}','{INS_LTR_E}','{INS_LTR_F}','{COMBINED_SINGLE_LIMIT}','{DESCRIPTION}','{CERTIFICATE_HOLDER}','{COMMERCIAL_GENERAL_LIABLITY}',"
                str_query = str_query + f" '{POLICY_NUMBER}','{ADDL_INSD}','{EFFECTIVE_DATE}','{EXPIRY_DATE}','{HIRED_AUTOS_ONLY_TEXT}','{ANY_AUTO_TEXT}','{SCHEDULED_AUTOS_TEXT}','{OWNED_AUTOS_ONLY_TEXT}','{NON_OWNED_AUTO_ONLY_TEXT}',"
                str_query = str_query + f" '{LIABILITY}','{NON_TRUCKING}','{NAMED_INSURED}','{DESCRIPTION_PAGE2}','{COLL_COMP}','{SIGNATURE}')"

                self.connCursor.execute(str_query)
                self.connObject.commit()
        except pyodbc.Error as error:
            messagebox.showinfo("Ryder COI Extraction Tool", "Error inserting extracted_pdf_details into DB\n" + str(error))
        finally:
            if 'cursor' in locals():
                self.connCursor.close()
            if 'connection' in locals():
                self.connObject.close()

    def update_extracted_pdf_details(self, extracted_pdf_details):
        try:

            str_query = "UPDATE ExtractedPDFDetails SET PRODUCER, INSURED_NAME, INSURED_ADDRESS, CONTACT_NAME, EMAIL_ADDRESS, PHONE_NUMBER, FAX_NUMBER,"
            str_query = str_query + "INSURER_A, NAIC_A, INSURER_B, NAIC_B, INSURER_C, NAIC_C, INSURER_D, NAIC_D, INSURER_E, NAIC_E, INSURER_F, NAIC_F, CERTIFICATE_NUMBER, REVISION_NUMBER,"
            str_query = str_query + "INSR_LTR_A, INS_LTR_A, INS_LTR_B, INS_LTR_C, INS_LTR_D, INS_LTR_E, INS_LTR_F, COMBINED_SINGLE_LIMIT, DESCRIPTION, CERTIFICATE_HOLDER, COMMERCIAL_GENERAL_LIABLITY,"
            str_query = str_query + "POLICY_NUMBER, ADDL_INSD, EFFECTIVE_DATE, EXPIRY_DATE, HIRED_AUTOS_ONLY_TEXT, ANY_AUTO_TEXT, SCHEDULED_AUTOS_TEXT, OWNED_AUTOS_ONLY_TEXT, NON_OWNED_AUTO_ONLY_TEXT,"
            str_query = str_query + "LIABILITY, NON_TRUCKING, NAMED_INSURED, DESCRIPTION_PAGE2, COLL_COMP, SIGNATURE WHERE "

            self.connCursor.execute(str_query)
            self.connObject.commit()
        except pyodbc.Error as error:
            messagebox.showinfo("Ryder COI Extraction Tool", "Error updating extracted_pdf_details into DB\n" + str(error))
        finally:
            if 'cursor' in locals():
                self.connCursor.close()
            if 'connection' in locals():
                self.connObject.close()

    def delete_extracted_pdf_details(self, entryID):
        try:
            sql_query = f"DELETE FROM ExtractedPDFDetails WHERE EntryID = '{entryID}'"
            self.connCursor.execute(sql_query)
            self.connObject.commit()
        except pyodbc.Error as error:
            messagebox.showinfo("Ryder COI Extraction Tool", "Error deleting extracted_pdf_details from DB\n" + str(error))
        finally:
            if 'cursor' in locals():
                self.connCursor.close()
            if 'connection' in locals():
                self.connObject.close()
