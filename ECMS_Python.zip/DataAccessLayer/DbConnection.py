import os
import pyodbc


class DbConnection:

    def __init__(self):
        self.dbPath = os.getcwd() + r"\Database\DB_Data.mdb"
        self.dbPassword = 'pk@123'
        self.connStr = r'DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=' + self.dbPath + r';PWD=' + self.dbPassword
        self.connObject = pyodbc.connect(self.connStr)
        self.connCursor = self.connObject.cursor()
