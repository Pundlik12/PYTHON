
class ExtractedPDFDetailsBusinessLayer:
    def __init__(self, _obj_extracted_pdf_details_DAL):
        self.email_details = []
        self.obj_emails_DAL = _obj_extracted_pdf_details_DAL

    def get_extracted_pdf_details(self):
        self.email_details = self.obj_emails_DAL.get_extracted_pdf_details()
        return self.email_details

    def get_extracted_pdf_details_by_ID(self, OutlookEmailID):
        self.email_details = self.obj_emails_DAL.get_extracted_pdf_details_by_ID(OutlookEmailID)
        return self.email_details

    def add_extracted_pdf_details(self, extracted_pdf_details):
        self.obj_emails_DAL.add_extracted_pdf_details(extracted_pdf_details)

    def update_extracted_pdf_details(self, extracted_pdf_details):
        self.obj_emails_DAL.update_extracted_pdf_details(extracted_pdf_details)

    def delete_extracted_pdf_details(self, entryID):
        self.obj_emails_DAL.delete_extracted_pdf_details(entryID)
