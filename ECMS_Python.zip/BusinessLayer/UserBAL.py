
class UserBusinessLayer:
    def __init__(self, _obj_users_DAL):
        self.user_details = []
        self.obj_user_DAL = _obj_users_DAL

    def get_user_details(self):
        self.user_details = self.obj_user_DAL.get_user_details()
        return self.user_details

    def get_user_details_by_UID(self, UID):
        self.user_details = self.obj_user_DAL.get_user_details_by_UID(UID)
        return self.user_details

    def add_user_details(self, user_details):
        self.obj_user_DAL.add_user_details(user_details)

    def update_email_details(self, user_details):
        self.obj_user_DAL.update_user_details(user_details)

    def delete_user_details(self, UID):
        self.obj_user_DAL.delete_email_details(UID)
