
class EmailsBusinessLayer:
    def __init__(self, _obj_emails_DAL):
        self.email_details = []
        self.obj_emails_DAL = _obj_emails_DAL

    def get_email_details(self):
        self.email_details = self.obj_emails_DAL.get_email_details()
        return self.email_details

    def get_email_details_by_entryID(self, entryID):
        self.email_details = self.obj_emails_DAL.get_email_details_by_entryID(entryID)
        return self.email_details

    def add_email_details(self, email_details):
        self.obj_emails_DAL.add_email_details(email_details)

    def update_email_details(self, email_details):
        self.obj_emails_DAL.update_email_details(email_details)

    def delete_email_details(self, entryID):
        self.obj_emails_DAL.delete_email_details(entryID)
