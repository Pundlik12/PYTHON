import json
import os


class AppSettings:

    def __init__(self):
        # self.json_file_path = 'C:\\Users\\u372739\\PycharmProjects\\ECMS\\Database\\AppSettings.json'
        self.json_file_path = os.getcwd() + '\\Database\\AppSettings.json'

    def Read_Settings(self):
        try:
            appsettings = open(self.json_file_path)
            data = json.load(appsettings)
            appsettings.close()
            return data
        except Exception as Error:
            print(f'Error in Read_Settings function:- {Error}')
            return None

    def Save_Settings(self, strEmailAddress, strFolderName, strServerName, strDatabaseName, strEndPoint, strKey, strModelID):
        try:
            raw_json = f'''[
              "Outlook": [
                "EmailAddress": "{strEmailAddress}",
                "FolderName": "{strFolderName}"
              ],
              "Database": [
                "ServerName": "{strServerName}",
                "DatabaseName": "{strDatabaseName}"
              ],
              "GenAI": [
                "EndPoint": "{strEndPoint}",
                "Key": "{strKey}",
                "ModelID": "{strModelID}"
              ]
            ]'''

            raw_json = raw_json.replace('[', '{').replace(']', '}')

            # Serializing json
            dictionary = json.loads(raw_json)
            json_object = json.dumps(dictionary, indent=4)

            with open(self.json_file_path, "w") as outfile:
                outfile.write(json_object)

            return True
        except Exception as Error:
            print(f'Error in Save_Settings function:- {Error}')
            return False
