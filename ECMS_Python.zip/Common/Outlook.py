import os
from tkinter import messagebox
import time
import pickle
import win32com.client


class OutlookEmails:
    def __init__(self, strOutlook_Email_Address, strFolderName):
        self.outlook_app = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

        self.outlook_email_id = strOutlook_Email_Address
        self.outlook_folder_name = strFolderName
        self.outlook_account = None
        self.inbox_folder = None
        self.pdf_base_path = os.getcwd() + "\\PDFFiles\\"

        self.attachment_count = 0
        self.entry_id = None
        self.Collect_Emails = []
        self.Sync_Mails_list = []

    def SynchEmails(self, start_date, end_date):
        try:
            # granting permissing to auto access outlook
            filename = 'timestamp.pkl'
            with open(filename, "wb") as file:
                # print(time.time())
                pickle.dump(time.time(), file)

            self.Sync_Mails_list = []
            self.inbox_folder = self.outlook_app.GetDefaultFolder(6)
            filtered_items = self.inbox_folder.Items.Restrict(
                    f"[ReceivedTime] >= '{start_date}' AND [ReceivedTime] <= '{end_date}'")

            for item in filtered_items:
                # checking if pdf attachment available
                if item.Class == 43 and item.MessageClass != 'IPM.Outlook.Recall':
                    self.attachment_count = 0
                    self.Collect_Emails = []
                    attachment_counter = 0

                    for attachment in item.Attachments:
                        if attachment.FileName.upper().endswith('.PDF'):
                            attachment_counter += 1
                            full_pdf_path = self.pdf_base_path + item.EntryID + "_" + str(attachment_counter) + ".PDF"
                            attachment.SaveAsFile(str(full_pdf_path))
                            self.attachment_count += 1

                    if self.attachment_count > 0:
                        mailbox_Name = self.outlook_email_id
                        received_time = item.ReceivedTime.strftime("%Y-%m-%d %H:%M:%S")
                        sender = str(item.Sender)
                        sent_on = str(item.SentOn)
                        body = str(item.Body)
                        size = str(item.Size)
                        subject = str(item.Subject)
                        priority = str(item.Importance)
                        conversation_id = str(item.ConversationID)
                        entry_id = str(item.EntryID)
                        status = "UnAssigned"
                        self.Collect_Emails.append(mailbox_Name)
                        self.Collect_Emails.append(sender)
                        self.Collect_Emails.append(received_time)
                        self.Collect_Emails.append(subject)
                        self.Collect_Emails.append(priority)
                        self.Collect_Emails.append(status)
                        self.Collect_Emails.append(self.attachment_count)
                        self.Collect_Emails.append(entry_id)
                        self.Collect_Emails.append(conversation_id)
                        self.Sync_Mails_list.append(self.Collect_Emails)

                # if pdf_counter == 0:
                #     messagebox.showinfo("Ryder COI Extraction Tool", "Email with attachments doesn't exists.")
            # else:
            #     messagebox.showinfo("Ryder COI Extraction Tool", "Your Outlook Account is not configured")
        except Exception as Error:
            messagebox.showinfo("Ryder COI Extraction Tool", "Error in SynchEmails function: " + str(Error))
        finally:
            self.outlook_account = None
            return self.Sync_Mails_list

    def ValidateAccount(self):
        try:
            for account in self.outlook_app.Accounts:
                if account.SmtpAddress.upper() == self.outlook_email_id.upper():
                    self.outlook_account = account
                    break
        except Exception as Error:
            messagebox.showinfo("Ryder COI Extraction Tool", "Error in ValidateAccount function: " + str(Error))
        finally:
            if self.outlook_account is None:
                return False
            else:
                return True

    def OpenEmail(self, EntryID):
        try:
            mail_item = self.outlook_app.GetItemFromID(EntryID)
            mail_item.Display()
        except Exception as Error:
            messagebox.showinfo("Ryder COI Extraction Tool", "Error in OpenEmail function: " + str(Error))
