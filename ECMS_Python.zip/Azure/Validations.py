import datetime
import os
import re
import pandas
from warnings import simplefilter

simplefilter(action="ignore", category=pandas.errors.PerformanceWarning)

CPIM_dataframe = None


def validate_producer(producer):
    if str(producer).strip() == "":
        return 'Producer is blank.'
    else:
        return ''


def validate_insurer_name(insured_name):
    global CPIM_dataframe
    try:
        if str(insured_name).strip() == "":
            return 'Insured name is blank'
        else:
            insured_name = str(insured_name).strip().upper()
            is_CustomerName = False

            master_file_path = os.getcwd() + '\\MasterData\\CPIM_Raw_Data_Dump.xlsx'
            if os.path.isfile(master_file_path):
                CPIM_dataframe = pandas.read_excel(master_file_path)
                CPIM_dataframe_main = CPIM_dataframe.fillna("", inplace=False)
                CPIM_dataframe = CPIM_dataframe_main

                for index, row in CPIM_dataframe.iterrows():
                    CustName = str(row['CUSTNAME']).strip().upper()
                    if CustName != "":
                        if CustName in insured_name:
                            is_CustomerName = True
                            break

                if is_CustomerName is True:
                    return ''
                else:
                    return 'Insured name is not matched in CPIM master'
            else:
                return "CPIM master file not exist"
    except Exception as Error:
        return f'Error in validate_insurer_name {Error}'


def validate_insurer_address(insured_name, insured_address):
    global CPIM_dataframe
    try:
        if str(insured_address).strip() == "":
            return 'Insured address is blank'
        else:
            if CPIM_dataframe is None:
                return "CPIM master file doesnt exist"

            is_Address1 = False
            is_Address2 = False
            is_Address3 = False
            is_CustomerName = False

            insured_address = str(insured_address).strip().upper()
            for index, row in CPIM_dataframe.iterrows():
                CustName = str(row['CUSTNAME']).strip().upper()
                if CustName != "":
                    if CustName in insured_name.upper():
                        is_CustomerName = True
                        break

                if is_CustomerName is True:
                    Address1 = str(row['"Cust Address Line 1"']).strip().upper()
                    Address2 = str(row['"Cust Address Line 2"']).strip().upper()
                    Address3 = str(row['"Cust Address Line 3"']).strip().upper()

                    if is_Address1 is False:
                        if Address1 != "":
                            if Address1 in insured_address:
                                is_Address1 = True

                    if is_Address2 is False:
                        if Address2 != "":
                            if Address2 in insured_address:
                                is_Address2 = True

                    if is_Address3 is False:
                        if Address3 != "":
                            if Address3 in insured_address:
                                is_Address3 = True

                    if is_Address1 is True and is_Address2 is True and is_Address3 is True:
                        return ''

            return 'Insurer address is not matched with CPIM Master.'
    except Exception as Error:
        return f'Error in validate_insurer_address {Error}'


def update_RPPD(insured_name):
    try:
        for index, row in CPIM_dataframe.iterrows():
            CustName = str(row['CUSTNAME']).strip().upper()
            if CustName != "":
                if CustName in insured_name.upper():
                    rppd = str(row['RPPD']).strip().upper()
                    return rppd

        return 'Customer not found'
    except Exception as Error:
        # print('Error in update_RPPD function')
        return 'Error in update_RPPD function'


def update_SIPD(insured_name):
    try:
        for index, row in CPIM_dataframe.iterrows():
            CustName = str(row['CUSTNAME']).strip().upper()
            if CustName != "":
                if CustName in insured_name.upper():
                    sipd = str(row['SIPD']).strip().upper()
                    return sipd

        return 'Customer not found'
    except Exception as Error:
        # print('Error in update_SIPD function')
        return 'Error in update_SIPD function'


def update_isHazmatCustomer(insured_name):
    try:
        for index, row in CPIM_dataframe.iterrows():
            CustName = str(row['CUSTNAME']).strip().upper()
            if CustName != "":
                if CustName in insured_name.upper():
                    IsHazmatCustomer = str(row['IsHazmatCustomer']).strip().upper()
                    return IsHazmatCustomer

        return 'Customer not found'
    except Exception as Error:
        # print('Error in update_isHazmatCustomer function')
        return 'Error in update_isHazmatCustomer function'


def update_VINS_List(insured_name):
    try:
        for index, row in CPIM_dataframe.iterrows():
            CustName = str(row['CUSTNAME']).strip().upper()
            if CustName != "":
                if CustName in insured_name.upper():
                    VINS_List = str(row['VINS_LIST']).strip().upper()
                    return VINS_List

        return 'Customer not found'
    except Exception as Error:
        # print('Error in update_VINS_List function')
        return 'Error in update_VINS_List function'


def validate_contact_name(contact_name):
    if str(contact_name).strip() == "":
        return 'Contact name is blank'
    else:
        return ''


def validate_email_address(email_address):
    try:
        if str(email_address).strip() == "":
            return 'Email address is blank'
        else:
            pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,7}\b'

            if re.fullmatch(pattern, str(email_address)):
                return ''
            else:
                return 'Email address is invalid'
    except Exception as Error:
        return f'Error in validate_email_address {Error}'


def validate_phone_number(phone_number):
    # string = """350 tel: (650) 725—9327 fax: (650) 723» 1882"""
    # phone_regex  = re.match(".*tel:(.*)fax:(.*)",string)
    # phone , fax = [ re.sub("[^0-9]","",x) for x in phone_regex.groups() ]
    try:
        if str(phone_number).strip() == "":
            return 'Phone number is blank'
        else:
            return ''
    except Exception as Error:
        return 'Error in Phone number'


def validate_fax_number(fax_number):
    try:
        if str(fax_number).strip() == "":
            return 'Fax number is blank'
        else:
            return ''
    except Exception as Error:
        return 'Error in Fax Number'


def validate_insurer_A(INSURER_A):
    try:
        if str(INSURER_A).strip() == "":
            return "INSURER A is blank"
        else:
            return ""
    except Exception as Error:
        return 'Error in Insurer A'


def validate_insurer_B(INSURER_B):
    try:
        if str(INSURER_B).strip() == "":
            return "INSURER B is blank"
        else:
            return ""
    except Exception as Error:
        return 'Error in Insurer B'


def validate_insurer_C(INSURER_C):
    try:
        if str(INSURER_C).strip() == "":
            return "INSURER C is blank"
        else:
            return ""
    except Exception as Error:
        return 'Error in Insurer C'


def validate_insurer_D(INSURER_D):
    try:
        if str(INSURER_D).strip() == "":
            return "INSURER D is blank"
        else:
            return ""
    except Exception as Error:
        return 'Error in Insurer D'


def validate_insurer_E(INSURER_E):
    try:
        if str(INSURER_E).strip() == "":
            return "INSURER E is blank"
        else:
            return ""
    except Exception as Error:
        return 'Error in Insurer E'


def validate_insurer_F(INSURER_F):
    try:
        if str(INSURER_F).strip() == "":
            return "INSURER F is blank"
        else:
            return ""
    except Exception as Error:
        return 'Error in Insurer F'


def validate_insr_ltr_A(insr_ltr_A):
    try:
        if str(insr_ltr_A).strip() == "":
            return "INS LTR A is blank"
        else:
            return ""
    except Exception as Error:
        return 'Error in INS LTR A'


def validate_insr_ltr_B(insr_ltr_B):
    try:
        if str(insr_ltr_B).strip() == "":
            return "INS LTR B is blank"
        else:
            return ""
    except Exception as Error:
        return 'Error in INS LTR B'


def validate_insr_ltr_C(insr_ltr_C):
    try:
        if str(insr_ltr_C).strip() == "":
            return "INS LTR C is blank"
        else:
            return ""
    except Exception as Error:
        return 'Error in INS LTR C'


def validate_insr_ltr_D(insr_ltr_D):
    try:
        if str(insr_ltr_D).strip() == "":
            return "INS LTR D is blank"
        else:
            return ""
    except Exception as Error:
        return 'Error in INS LTR D'


def validate_insr_ltr_E(insr_ltr_E):
    try:
        if str(insr_ltr_E).strip() == "":
            return "INS LTR E is blank"
        else:
            return ""
    except Exception as Error:
        return 'Error in INS LTR E'


def validate_insr_ltr_F(insr_ltr_F):
    try:
        if str(insr_ltr_F).strip() == "":
            return "INS LTR F is blank"
        else:
            return ""
    except Exception as Error:
        return 'Error in INS LTR F'


def validate_ANY_AUTOS_ONLY(ANY_AUTOS_ONLY):
    try:
        if str(ANY_AUTOS_ONLY) == "":
            return 'ANY AUTOS ONLY is blank'
        else:
            return ''
    except Exception as Error:
        return 'Error in ANY AUTO ONLY'


def validate_OWNED_AUTOS_ONLY(OWNED_AUTOS_ONLY):
    try:
        if str(OWNED_AUTOS_ONLY) == "":
            return 'OWNED AUTOS ONLY is blank'
        else:
            return ''
    except Exception as Error:
        return 'Error in OWNED AUTOS ONLY'


def validate_HIRED_AUTOS_ONLY(HIRED_AUTOS_ONLY):
    try:
        if str(HIRED_AUTOS_ONLY) == "":
            return 'HIRED AUTOS ONLY blank'
        else:
            return ''
    except Exception as Error:
        return 'Error in HIRED AUTOS ONLY'


def validate_SCHEDULED_AUTOS_ONLY(SCHEDULED_AUTOS_ONLY):
    try:
        if str(SCHEDULED_AUTOS_ONLY) == "":
            return 'SCHEDULED AUTOS ONLY blank'
        else:
            return ''
    except Exception as Error:
        return 'Error in SCHEDULED AUTOS ONLY'


def validate_NON_SCHEDULED_AUTOS_ONLY(NON_SCHEDULED_AUTOS_ONLY):
    try:
        if str(NON_SCHEDULED_AUTOS_ONLY) == "":
            return 'NON SCHEDULED AUTOS ONLY blank'
        else:
            return ''
    except Exception as Error:
        return 'Error in NON SCHEDULED AUTOS ONLY'


def validate_additional_insured(additional_insured):
    try:
        str_additional_insured = str(additional_insured).strip().upper()
        if str_additional_insured == "":
            return 'Additional insured is blank'
        else:
            return ''
    except Exception as Error:
        return 'Error in ADDITIONAL INSURER'


def validate_policy_number(policy_number):
    try:
        str_policy_number = str(policy_number).strip()
        if str_policy_number == "":
            return 'Policy number is blank'
        else:
            return ''
    except Exception as Error:
        return f'Error in validate_policy_number {Error}'


def validate_policy_effective_date(policy_effective_date):
    try:
        if str(policy_effective_date).strip() == "":
            return 'Policy effective date is blank'
        else:
            return ''
    except Exception as Error:
        return 'Error in POLICY EFFECTIVE DATE'


def validate_policy_expiry_date(policy_expiry_date):
    try:
        if str(policy_expiry_date).strip() == "":
            return 'Policy expiry date is blank'
        else:
            if '/' in policy_expiry_date:
                try:
                    date_split = str(policy_expiry_date).split('/')

                    year = int(date_split[2])
                    if len(str(year)) == 2:
                        if year >= 40:
                            year = 1900 + year
                        else:
                            year = 2000 + year
                    elif len(str(year)) == 4:
                        year = year

                    day = int(date_split[1])
                    month = int(date_split[0])

                    expiry_date = datetime.date(year, month, day)
                    today = datetime.date.today()

                    if expiry_date > today:
                        return ''
                    else:
                        return f'Policy expiry date - {policy_expiry_date}/({expiry_date}) is less than current date {today}'

                except ValueError:
                    return f'Incorrect policy_expiry_date format'
    except Exception as Error:
        return 'Error in POLICY EXPIRY DATE'


def validate_combined_single_limit(combined_single_limit):
    try:
        if str(combined_single_limit) == "":
            return 'Combined single limit is blank'
            
        combined_single_limit = str(combined_single_limit).strip()
        pattern_matching = re.compile(r'[\d]+[.,\d]+', re.MULTILINE)
        result = re.findall(pattern_matching, combined_single_limit)

        if len(result) > 0:
            combined_single_limit = result[0].replace(',', '')
        else:
            combined_single_limit = ""

        if int(combined_single_limit) < 1000000:
            return 'Combined single limit is less than 1000000'
        elif int(combined_single_limit) > 5000000:
            return 'Combined single limit is greater than 5000000 (hazmatic customer)'
        elif int(combined_single_limit) >= 1000000 and int(combined_single_limit) <= 5000000:
            return ''
        else:
            return 'Invalid combined_single_limit'
        
    except Exception as Error:
        return 'Error in COMBINED SINGLE LIMIT'


def validate_description(description):
    try:
        if str(description).strip() == "":
            return 'Description is blank'
        else:
            return ''
    except Exception as Error:
        return 'Error in DESCRIPTION'


def validate_certificate_holder_name(certificate_holder):
    try:
        if str(certificate_holder).strip() == "":
            return 'Certificate holder is blank'
        else:
            return ''
    except Exception as Error:
        return 'Error in CERTIFICATE HOLDER NAME'


def validate_comprehension_and_collision(description):
    try:
        description = str(description).upper().strip()
        if 'COMPREHENSION' in description or 'COMPREHENSIVE' in description or 'COLLISION' in description:
            return ""
         
        if 'COLL/COMP' in description or 'COMP/COLL' in description:
            return ""
            
        if ' COMP' in description or ' COLL' in description:
            return ""
            
        return 'COMPREHENSION and COLLISION Deductibles not found.'
    except Exception as Error:
        return 'Error in COLL/COMP'


def validate_additional_insured_loss_payee_leased_rented(description, any_auto_tick):
    try:
        if len(description):
            description = description[0]

        if len(any_auto_tick):
            any_auto_tick = any_auto_tick[0]

        if any_auto_tick == "Y" or any_auto_tick == "X":
            if 'as Additional Insured and loss payee for all vehicles leased, rented or supplied as a substitute'.upper() in description.upper():
                return ''

            return 'Additional Insured and loss payee for all vehicles leased, rented or supplied as a substitute not found.'
        else:
            return ''
    except Exception as Error:
        return 'Error in ADDITIONAL INSURED LOSS PAYEE LEASED RENTED'


def validate_additional_insured_loss_payee_following_vehicles(description, scheduled_auto_tick):
    try:
        if len(description):
            description = description[0]

        if len(scheduled_auto_tick):
            scheduled_auto_tick = scheduled_auto_tick[0]

        if scheduled_auto_tick == "Y" or scheduled_auto_tick == "X":
            if 'as Additional Insured and loss payee for following vehicles'.upper() in description.upper():
                return ''

            return 'as Additional Insured and loss payee for following vehicles not found'
        else:
            return ''
    except Exception as Error:
        return 'Error in ADDITIONAL INSURED LOSS PAYEE FOLLOWING VEHICLES'


def validate_vins_listed(description, scheduled_auto_tick):
    try:
        description = str(description).strip()
        scheduled_auto_tick = str(scheduled_auto_tick).strip()

        if scheduled_auto_tick == "Y" or scheduled_auto_tick == "X":
            vins_number = re.compile(r'\b(\w{17})\b', re.MULTILINE)
            strings = re.findall(vins_number, description)

            if len(strings) > 0:
                vins = strings[0]
                return ''

            return f'SCHEDULED AUTO TICK is {scheduled_auto_tick} but VINS number not found'
        else:
            return ''
    except Exception as Error:
        return 'Error in VINS LISTED IN DESCRIPTION'


def validate_and_save_data(input_file_path):
    try:
        data = pandas.read_csv(input_file_path)
        filled_data = data.fillna('')

        filled_data["PRODUCER_COMMENTS"] = filled_data['PRODUCER'].apply(validate_producer)
        filled_data['PRODUCER_STATUS'] = filled_data.apply(lambda x: "TRUE" if x['PRODUCER_COMMENTS'] == "" else "FALSE",
                                                           axis=1)

        filled_data["INSURER_NAME_COMMENTS"] = filled_data['INSURED NAME'].apply(validate_insurer_name)
        filled_data['INSURER_NAME_STATUS'] = filled_data.apply(
            lambda x: "TRUE" if x['INSURER_NAME_COMMENTS'] == "" else "FALSE", axis=1)

        # filled_data["INSURER_ADDRESS_COMMENTS"] = filled_data['INSURED ADDRESS'].apply(validate_insurer_address)
        filled_data["INSURER_ADDRESS_COMMENTS"] = filled_data.apply(
            lambda x: validate_insurer_address(x["INSURED NAME"], x["INSURED ADDRESS"]), axis=1)
        filled_data['INSURER_ADDRESS_STATUS'] = filled_data.apply(
            lambda x: "TRUE" if x['INSURER_ADDRESS_COMMENTS'] == "" else "FALSE", axis=1)

        filled_data["CONTACT_NAME_COMMENTS"] = filled_data['CONTACT NAME'].apply(validate_contact_name)
        filled_data['CONTACT_NAME_STATUS'] = filled_data.apply(
            lambda x: "TRUE" if x['CONTACT_NAME_COMMENTS'] == "" else "FALSE", axis=1)

        filled_data["EMAIL_ADDRESS_COMMENTS"] = filled_data['EMAIL ADDRESS'].apply(validate_email_address)
        filled_data['EMAIL_ADDRESS_STATUS'] = filled_data.apply(
            lambda x: "TRUE" if x['EMAIL_ADDRESS_COMMENTS'] == "" else "FALSE", axis=1)

        filled_data["PHONE_NUMBER_COMMENTS"] = filled_data['PHONE NUMBER'].apply(validate_phone_number)
        filled_data['PHONE_NUMBER_STATUS'] = filled_data.apply(
            lambda x: "TRUE" if x['PHONE_NUMBER_COMMENTS'] == "" else "FALSE", axis=1)

        filled_data["FAX_NUMBER_COMMENTS"] = filled_data['FAX NUMBER'].apply(validate_fax_number)
        filled_data['FAX_NUMBER_STATUS'] = filled_data.apply(
            lambda x: "TRUE" if x['FAX_NUMBER_COMMENTS'] == "" else "FALSE", axis=1)

        filled_data["INSURER_A_COMMENTS"] = filled_data['INSURER A'].apply(validate_insurer_A)
        filled_data['INSURER_A_STATUS'] = filled_data.apply(lambda x: "TRUE" if x['INSURER_A_COMMENTS'] == "" else "FALSE",
                                                            axis=1)

        filled_data["INSURER_B_COMMENTS"] = filled_data['INSURER B'].apply(validate_insurer_B)
        filled_data['INSURER_B_STATUS'] = filled_data.apply(lambda x: "TRUE" if x['INSURER_B_COMMENTS'] == "" else "FALSE",
                                                            axis=1)

        filled_data["INSURER_C_COMMENTS"] = filled_data['INSURER C'].apply(validate_insurer_C)
        filled_data['INSURER_C_STATUS'] = filled_data.apply(lambda x: "TRUE" if x['INSURER_C_COMMENTS'] == "" else "FALSE",
                                                            axis=1)

        filled_data["INSURER_D_COMMENTS"] = filled_data['INSURER D'].apply(validate_insurer_D)
        filled_data['INSURER_D_STATUS'] = filled_data.apply(lambda x: "TRUE" if x['INSURER_D_COMMENTS'] == "" else "FALSE",
                                                            axis=1)

        filled_data["INSURER_E_COMMENTS"] = filled_data['INSURER E'].apply(validate_insurer_E)
        filled_data['INSURER_E_STATUS'] = filled_data.apply(lambda x: "TRUE" if x['INSURER_E_COMMENTS'] == "" else "FALSE",
                                                            axis=1)

        filled_data["INSURER_F_COMMENTS"] = filled_data['INSURER F'].apply(validate_insurer_F)
        filled_data['INSURER_F_STATUS'] = filled_data.apply(lambda x: "TRUE" if x['INSURER_F_COMMENTS'] == "" else "FALSE",
                                                            axis=1)

        filled_data["INSR_LTR_A_COMMENTS"] = filled_data['INS LTR A'].apply(validate_insr_ltr_A)
        filled_data['INSR_LTR_A_STATUS'] = filled_data.apply(lambda x: "TRUE" if x['INSR_LTR_A_COMMENTS'] == "" else "FALSE", axis=1)

        filled_data["INSR_LTR_B_COMMENTS"] = filled_data['INS LTR B'].apply(validate_insr_ltr_B)
        filled_data['INSR_LTR_B_STATUS'] = filled_data.apply(lambda x: "TRUE" if x['INSR_LTR_B_COMMENTS'] == "" else "FALSE", axis=1)

        filled_data["INSR_LTR_C_COMMENTS"] = filled_data['INS LTR C'].apply(validate_insr_ltr_C)
        filled_data['INSR_LTR_C_STATUS'] = filled_data.apply(lambda x: "TRUE" if x['INSR_LTR_C_COMMENTS'] == "" else "FALSE", axis=1)

        filled_data["INSR_LTR_D_COMMENTS"] = filled_data['INS LTR D'].apply(validate_insr_ltr_D)
        filled_data['INSR_LTR_D_STATUS'] = filled_data.apply(lambda x: "TRUE" if x['INSR_LTR_D_COMMENTS'] == "" else "FALSE", axis=1)

        filled_data["INSR_LTR_E_COMMENTS"] = filled_data['INS LTR E'].apply(validate_insr_ltr_E)
        filled_data['INSR_LTR_E_STATUS'] = filled_data.apply(lambda x: "TRUE" if x['INSR_LTR_E_COMMENTS'] == "" else "FALSE", axis=1)

        filled_data["INSR_LTR_F_COMMENTS"] = filled_data['INS LTR F'].apply(validate_insr_ltr_F)
        filled_data['INSR_LTR_F_STATUS'] = filled_data.apply(lambda x: "TRUE" if x['INSR_LTR_F_COMMENTS'] == "" else "FALSE", axis=1)

        filled_data["ANY_AUTO_COMMENTS"] = filled_data['ANY AUTO TEXT'].apply(validate_ANY_AUTOS_ONLY)
        filled_data['ANY_AUTO_STATUS'] = filled_data.apply(lambda x: "TRUE" if x['ANY_AUTO_COMMENTS'] == "" else "FALSE",
                                                           axis=1)

        filled_data["OWNED_AUTOS_ONLY_COMMENTS"] = filled_data['OWNED AUTOS ONLY TEXT'].apply(validate_OWNED_AUTOS_ONLY)
        filled_data['OWNED_AUTOS_ONLY_STATUS'] = filled_data.apply(
            lambda x: "TRUE" if x['OWNED_AUTOS_ONLY_COMMENTS'] == "" else "FALSE", axis=1)

        filled_data["HIRED_AUTOS_ONLY_COMMENTS"] = filled_data['HIRED AUTOS ONLY TEXT'].apply(validate_HIRED_AUTOS_ONLY)
        filled_data['HIRED_AUTOS_ONLY_STATUS'] = filled_data.apply(
            lambda x: "TRUE" if x['HIRED_AUTOS_ONLY_COMMENTS'] == "" else "FALSE", axis=1)

        filled_data["SCHEDULED_AUTOS_COMMENTS"] = filled_data['SCHEDULED AUTOS TEXT'].apply(validate_SCHEDULED_AUTOS_ONLY)
        filled_data['SCHEDULED_AUTOS_STATUS'] = filled_data.apply(
            lambda x: "TRUE" if x['SCHEDULED_AUTOS_COMMENTS'] == "" else "FALSE", axis=1)

        filled_data["NON_OWNED_AUTO_ONLY_COMMENTS"] = filled_data['NON-OWNED AUTO ONLY TEXT'].apply(
            validate_NON_SCHEDULED_AUTOS_ONLY)
        filled_data['NON_OWNED_AUTO_ONLY_Status'] = filled_data.apply(
            lambda x: "TRUE" if x['NON_OWNED_AUTO_ONLY_COMMENTS'] == "" else "FALSE", axis=1)

        filled_data["ADDL_INSD_COMMENTS"] = filled_data['ADDL INSD'].apply(validate_additional_insured)
        filled_data['ADDL_INSD_STATUS'] = filled_data.apply(lambda x: "TRUE" if x['ADDL_INSD_COMMENTS'] == "" else "FALSE",
                                                            axis=1)

        filled_data["POLICY_NUMBER_COMMENTS"] = filled_data['POLICY NUMBER'].apply(validate_policy_number)
        filled_data['POLICY_NUMBER_STATUS'] = filled_data.apply(
            lambda x: "TRUE" if x['POLICY_NUMBER_COMMENTS'] == "" else "FALSE", axis=1)

        filled_data["EFFECTIVE_DATE_COMMENTS"] = filled_data['EFFECTIVE DATE'].apply(validate_policy_effective_date)
        filled_data['EFFECTIVE_DATE_STATUS'] = filled_data.apply(
            lambda x: "TRUE" if x['EFFECTIVE_DATE_COMMENTS'] == "" else "FALSE", axis=1)

        filled_data["EXPIRY_DATE_COMMENTS"] = filled_data['EFFECTIVE DATE 2'].apply(validate_policy_expiry_date)
        filled_data['EXPIRY_DATE_STATUS'] = filled_data.apply(
            lambda x: "TRUE" if x['EXPIRY_DATE_COMMENTS'] == "" else "FALSE", axis=1)

        filled_data["COMBINED_SINGLE_LIMIT_COMMENTS"] = filled_data['COMBINED SINGLE LIMIT'].apply(
            validate_combined_single_limit)
        filled_data['COMBINED_SINGLE_LIMIT_STATUS'] = filled_data.apply(
            lambda x: "TRUE" if x['COMBINED_SINGLE_LIMIT_COMMENTS'] == "" else "FALSE", axis=1)

        filled_data["DESCRIPTION_COMMENTS"] = filled_data['DESCRIPTION'].apply(validate_description)
        filled_data['DESCRIPTION_STATUS'] = filled_data.apply(
            lambda x: "TRUE" if x['DESCRIPTION_COMMENTS'] == "" else "FALSE", axis=1)

        filled_data["CERTIFICATE_HOLDER_COMMENTS"] = filled_data['CERTIFICATE HOLDER'].apply(
            validate_certificate_holder_name)
        filled_data['CERTIFICATE_HOLDER_STATUS'] = filled_data.apply(
            lambda x: "TRUE" if x['CERTIFICATE_HOLDER_COMMENTS'] == "" else "FALSE", axis=1)

        filled_data["COMPREHENSION/COLLISION_COMMENTS"] = filled_data['DESCRIPTION'].apply(
            validate_comprehension_and_collision)
        filled_data['COMPREHENSION/COLLISION_STATUS'] = filled_data.apply(
            lambda x: "TRUE" if x['COMPREHENSION/COLLISION_COMMENTS'] == "" else "FALSE", axis=1)

        filled_data["ADDITIONAL_INSURED_LOSS_PAYEE_LEASED_RENTED_COMMENTS"] = filled_data.apply(
            lambda x: validate_additional_insured_loss_payee_leased_rented(x["DESCRIPTION"], x["ANY AUTO TEXT"]), axis=1)
        filled_data['ADDITIONAL_INSURED_LOSS_PAYEE_LEASED_RENTED_STATUS'] = filled_data.apply(
            lambda x: "TRUE" if x['ADDITIONAL_INSURED_LOSS_PAYEE_LEASED_RENTED_COMMENTS'] == "" else "FALSE", axis=1)

        filled_data["ADDITIONAL_INSURED_LOSS_PAYEE_FOLLOWING_VEHICLES_COMMENTS"] = filled_data.apply(
            lambda x: validate_additional_insured_loss_payee_following_vehicles(x["DESCRIPTION"],
                                                                                x["SCHEDULED AUTOS TEXT"]), axis=1)
        filled_data['ADDITIONAL_INSURED_LOSS_PAYEE_FOLLOWING_VEHICLES_STATUS'] = filled_data.apply(
            lambda x: "TRUE" if x['ADDITIONAL_INSURED_LOSS_PAYEE_FOLLOWING_VEHICLES_COMMENTS'] == "" else "FALSE", axis=1)

        filled_data["VINS_LISTED_COMMENTS"] = filled_data.apply(
            lambda x: validate_vins_listed(x["DESCRIPTION"], x["SCHEDULED AUTOS TEXT"]), axis=1)
        filled_data['VINS_LISTED_STATUS'] = filled_data.apply(
            lambda x: "TRUE" if x['VINS_LISTED_COMMENTS'] == "" else "FALSE", axis=1)

        filled_data["RPPD"] = filled_data['INSURED NAME'].apply(update_RPPD)
        filled_data["SIPD"] = filled_data['INSURED NAME'].apply(update_SIPD)
        filled_data["IsHazmatCustomer"] = filled_data['INSURED NAME'].apply(update_isHazmatCustomer)
        filled_data["VINS_LIST"] = filled_data['INSURED NAME'].apply(update_VINS_List)

        filled_data["OVERALL_SUMMARY"] = ""
        filled_data['OVERALL_STATUS'] = ""

        for index, row in filled_data.iterrows():
            summary = ""
            summary = summary + str(row['PRODUCER_COMMENTS']) + '\n'
            summary = summary + str(row['INSURER_NAME_COMMENTS']) + '\n'
            summary = summary + str(row['INSURER_ADDRESS_COMMENTS']) + '\n'
            summary = summary + str(row['CONTACT_NAME_COMMENTS']) + '\n'
            summary = summary + str(row['EMAIL_ADDRESS_COMMENTS']) + '\n'
            summary = summary + str(row['PHONE_NUMBER_COMMENTS']) + '\n'
            summary = summary + str(row['FAX_NUMBER_COMMENTS']) + '\n'
            summary = summary + str(row['INSURER_A_COMMENTS']) + '\n'
            summary = summary + str(row['INSURER_B_COMMENTS']) + '\n'
            summary = summary + str(row['INSURER_C_COMMENTS']) + '\n'
            summary = summary + str(row['INSURER_D_COMMENTS']) + '\n'
            summary = summary + str(row['INSURER_E_COMMENTS']) + '\n'
            summary = summary + str(row['INSURER_F_COMMENTS']) + '\n'
            summary = summary + str(row['INSR_LTR_A_COMMENTS']) + '\n'
            summary = summary + str(row['INSR_LTR_B_COMMENTS']) + '\n'
            summary = summary + str(row['INSR_LTR_C_COMMENTS']) + '\n'
            summary = summary + str(row['INSR_LTR_D_COMMENTS']) + '\n'
            summary = summary + str(row['INSR_LTR_E_COMMENTS']) + '\n'
            summary = summary + str(row['INSR_LTR_F_COMMENTS']) + '\n'
            summary = summary + str(row['ANY_AUTO_COMMENTS']) + '\n'
            summary = summary + str(row['OWNED_AUTOS_ONLY_COMMENTS']) + '\n'
            summary = summary + str(row['HIRED_AUTOS_ONLY_COMMENTS']) + '\n'
            summary = summary + str(row['SCHEDULED_AUTOS_COMMENTS']) + '\n'
            summary = summary + str(row['NON_OWNED_AUTO_ONLY_COMMENTS']) + '\n'
            summary = summary + str(row['ADDL_INSD_COMMENTS']) + '\n'
            summary = summary + str(row['POLICY_NUMBER_COMMENTS']) + '\n'
            summary = summary + str(row['EFFECTIVE_DATE_COMMENTS']) + '\n'
            summary = summary + str(row['EXPIRY_DATE_COMMENTS']) + '\n'
            summary = summary + str(row['COMBINED_SINGLE_LIMIT_COMMENTS']) + '\n'
            summary = summary + str(row['DESCRIPTION_COMMENTS']) + '\n'
            summary = summary + str(row['CERTIFICATE_HOLDER_COMMENTS']) + '\n'
            summary = summary + str(row['COMPREHENSION/COLLISION_COMMENTS']) + '\n'
            summary = summary + str(row['ADDITIONAL_INSURED_LOSS_PAYEE_LEASED_RENTED_COMMENTS']) + '\n'
            summary = summary + str(row['ADDITIONAL_INSURED_LOSS_PAYEE_FOLLOWING_VEHICLES_COMMENTS']) + '\n'
            summary = summary + str(row['VINS_LISTED_COMMENTS'])

            summary = summary.replace('\n\n', '\n')
            filled_data.loc[index, 'OVERALL_SUMMARY'] = summary.strip()

            if summary == "":
                filled_data.loc[index, 'OVERALL_STATUS'] = "TRUE"
            else:
                filled_data.loc[index, 'OVERALL_STATUS'] = "FALSE"

        validation_output_file_name = os.path.dirname(input_file_path) + "\\validation_output.csv"
        filled_data.to_csv(validation_output_file_name, index=False)

        return filled_data

    except Exception as Error:
        print(f'Error while validation:-\n{Error}')
        return None
