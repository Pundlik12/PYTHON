import os
import pandas as pd
from csv import DictWriter
from azure.core.credentials import AzureKeyCredential
from azure.ai.formrecognizer import DocumentAnalysisClient
from Azure.Validations import validate_and_save_data

from warnings import simplefilter

simplefilter(action="ignore", category=pd.errors.PerformanceWarning)


class Extract_data_from_Azure:

    def __init__(self, strEndPoint, strKey, strModelID):
        # self.endpoint = "https://rydercoi.cognitiveservices.azure.com/"
        # self.key = "d2da70cf048a4df787dce59029ccdb65"
        # self.model_id = "RYDER_COI_EXTRACTION_MODEL_V1.4"

        self.endpoint = strEndPoint
        self.key = strKey
        self.model_id = strModelID

        self.json_output_file = os.getcwd() + "\\extracted_data.json"
        self.csv_output_file_name = os.getcwd() + "\\SNL_Ryder_Output.csv"
        self.validation_output_file_name = os.getcwd() + "\\Validation_Output.csv"

    def extract_validate_and_save_data(self, input_directory_path):
        self.csv_output_file_name = input_directory_path + "\\SNL_Ryder_Output.csv"
        self.validation_output_file_name = input_directory_path + "\\Validation_Output.csv"

        if os.path.exists(self.csv_output_file_name):
            os.remove(self.csv_output_file_name)

        if os.path.exists(self.validation_output_file_name):
            os.remove(self.validation_output_file_name)

        main_data = []
        for filename in os.listdir(input_directory_path):
            if filename.lower().endswith('.pdf'):
                try:
                    client = DocumentAnalysisClient(self.endpoint, AzureKeyCredential(self.key))

                    form_path = input_directory_path + "\\" + filename

                    with open(form_path, "rb") as f:
                        poller = client.begin_analyze_document(self.model_id, document=f)
                        result = poller.result()

                    client.close()

                    extracted_data = {}
                    for idx, document in enumerate(result.documents):
                        for name, field in document.fields.items():
                            field_value = field.value if field.value else field.content
                            extracted_data['Filename'] = filename
                            extracted_data[name] = field_value

                    main_data.append(extracted_data)

                except Exception as Error:
                    print(f'Error while extracting data from Azure service for file:-{filename}:-\n{Error}')

        try:
            # list of column names
            # field_names = ['Filename', 'PRODUCER', 'INSURED NAME', 'INSURED ADDRESS', 'CONTACT NAME', 'EMAIL ADDRESS',
            #                'INSURER A', 'NAIC A', 'CERTIFICATE NUMBER', 'ADDL INSD', 'COMBINED SINGLE LIMIT', 'DESCRIPTION',
            #                'PHONE NUMBER', 'INSURER B', 'NAIC B', 'NAIC C', 'INSURER C', 'INSURER D', 'NAIC D',
            #                'CERTIFICATE HOLDER', 'COMMERCIAL GENERAL LIABLITY', 'HIRED AUTOS ONLY TEXT', 'EFFECTIVE DATE',
            #                'EFFECTIVE DATE 2', 'POLICY NUMBER', 'INSR LTR A', 'INS LTR B', 'INS LTR C', 'INS LTR D',
            #                'ANY AUTO TEXT', 'NAIC F', 'NAMED INSURED', 'NAIC E', 'DESCRIPTION PAGE 2', 'FAX NUMBER',
            #                'REVISION NUMBER', 'INS LTR A', 'SCHEDULED AUTOS TEXT', 'INSURER F', 'INSURER E',
            #                'OWNED AUTOS ONLY TEXT', 'NON-OWNED AUTO ONLY TEXT', 'INS LTR E', 'INS LTR F', 'COLL/COMP',
            #                'SIGNATURE', 'LIABILITY', 'NON-TRUCKING']

            field_names = ['Filename', 'PRODUCER', 'INSURED NAME', 'INSURED ADDRESS', 'CONTACT NAME', 'EMAIL ADDRESS',
                           'PHONE NUMBER', 'FAX NUMBER',
                           'INSURER A', 'NAIC A', 'INSURER B', 'NAIC B', 'INSURER C', 'NAIC C', 'INSURER D', 'NAIC D',
                           'INSURER E', 'NAIC E', 'INSURER F', 'NAIC F', 'CERTIFICATE NUMBER', 'REVISION NUMBER',
                           'INSR LTR A', 'INS LTR A', 'INS LTR B', 'INS LTR C', 'INS LTR D', 'INS LTR E', 'INS LTR F',
                           'COMBINED SINGLE LIMIT', 'DESCRIPTION', 'CERTIFICATE HOLDER', 'COMMERCIAL GENERAL LIABLITY',
                           'POLICY NUMBER', 'ADDL INSD', 'EFFECTIVE DATE', 'EFFECTIVE DATE 2', 'HIRED AUTOS ONLY TEXT',
                           'ANY AUTO TEXT', 'SCHEDULED AUTOS TEXT', 'OWNED AUTOS ONLY TEXT', 'NON-OWNED AUTO ONLY TEXT',
                           'LIABILITY', 'NON-TRUCKING', 'NAMED INSURED', 'DESCRIPTION PAGE 2', 'COLL/COMP', 'SIGNATURE']

            with open(self.csv_output_file_name, 'a', newline='', encoding="utf-8") as f_object:
                dictwriter_object = DictWriter(f_object, fieldnames=field_names)
                dictwriter_object.writeheader()
                dictwriter_object.writerows(main_data)
                f_object.close()

            # validate_and_save_data(self.csv_output_file_name)

        except Exception as Error:
            print(f'Error while writing data to csv file:-\n{Error}')

        return main_data
