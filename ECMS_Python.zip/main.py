from UILayer.Account.frmLoginForm import LoginForm

login = LoginForm()
