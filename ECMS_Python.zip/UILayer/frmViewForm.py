import os
import tkinter
from tkinter import *
from tkinter import ttk
from tkinter import tix
import textwrap


class ViewForm:

    def __init__(self, data_df):
        self.root = tix.Tk()
        self.root.title('View Form')
        self.root.iconbitmap(os.getcwd() + r"\Images\Emails.ico")
        self.root.geometry("{0}x{1}+0+0".format(self.root.winfo_screenwidth()-2, self.root.winfo_screenheight()-2))
        self.root.minsize(width=self.root.winfo_screenwidth()-2, height=self.root.winfo_screenheight()-2)

        top_frame = Frame(self.root, bg="pink", height=20)
        top_frame.pack(side=TOP, fill="x")
        lbl_header = Label(top_frame, text="View Extracted & Validated Information", highlightthickness=0, background="pink",
                           bd=0, justify=CENTER)
        lbl_header.grid(row=0, column=1, padx=2, pady=2)
        lbl_header.config(font=('Verdana', 15))

        middle_frame = Frame(self.root, height=510)
        middle_frame.pack(side=TOP, fill="both")

        columns = ('Field_Name', 'Extracted_Data', 'Validated_Data')
        self.tree = ttk.Treeview(middle_frame, selectmode='browse', columns=columns, show='headings', height=15)

        style = ttk.Style(middle_frame)
        style.theme_use("classic")
        style.configure("Treeview", background="white", fieldbackground="white", foreground="white", font=('Verdana', 13))
        style.configure('Treeview.Heading', background="PowderBlue", font=('Arial Bold', 15))

        # define headings
        self.tree.column("# 1", anchor="w", stretch=NO, width=300)
        self.tree.heading('Field_Name', text='Field Name')

        self.tree.column("# 2", anchor="w", stretch=NO, width=700)
        self.tree.heading('Extracted_Data', text='Extracted Data')

        self.tree.column("# 3", anchor="w", stretch=NO, width=400)
        self.tree.heading('Validated_Data', text='Validated Data')
        self.tree.grid(row=0, column=0, sticky='nsew')
        self.tree.config(height=35)
        # self.tree.bind('<Motion>', self.manage_tooltip)
        self.tree.bind('<ButtonRelease-1>', self.manage_tooltip_selection)

        scrollbar = ttk.Scrollbar(middle_frame, orient=tkinter.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscroll=scrollbar.set)
        scrollbar.grid(row=0, column=1, sticky='ns')

        data_list = data_df.values.tolist()

        for lst in data_list:
            self.tree.insert('', tkinter.END, values=lst)

        self.root.mainloop()

    def manage_tooltip_selection(self, event):
        tip = tix.Balloon(self.root)
        for selected_item in self.tree.selection():
            item = self.tree.item(selected_item)
            lst_values = item['values']

            tool_tip_text = ""
            if len(lst_values) > 0:
                column_selected = self.tree.identify_column(event.x)
                if column_selected == "#1":
                    tool_tip_text = str(lst_values[0]).strip()
                elif column_selected == "#2":
                    tool_tip_text = str(lst_values[1]).strip()
                elif column_selected == "#3":
                    tool_tip_text = str(lst_values[2]).strip()

            if tool_tip_text != "":
                tip.bind_widget(self.tree, balloonmsg="")
                tip.bind_widget(self.tree, balloonmsg=self.wrap_text(tool_tip_text))
            else:
                tip.bind_widget(self.tree, balloonmsg="")
                tip.unbind_widget(self.tree)

    def manage_tooltip(self, event):
        tip = tix.Balloon(self.root)

        item = self.tree.identify("item", event.x, event.y)
        lst_values = self.tree.item(item)["values"]

        tool_tip_text = ""
        if len(lst_values) > 0:
            column_selected = self.tree.identify_column(event.x)
            if column_selected == "#1":
                tool_tip_text = str(lst_values[0]).strip()
            elif column_selected == "#2":
                tool_tip_text = str(lst_values[1]).strip()
            elif column_selected == "#3":
                tool_tip_text = str(lst_values[2]).strip()

        if tool_tip_text != "":
            tip.bind_widget(self.tree, balloonmsg="")
            tip.bind_widget(self.tree, balloonmsg=self.wrap_text(tool_tip_text))
        else:
            tip.bind_widget(self.tree, balloonmsg="")
            tip.unbind_widget(self.tree)

    def wrap_text(self, string, length=60):
        text_wrapped = '\n'.join(textwrap.wrap(string, length))
        return text_wrapped
