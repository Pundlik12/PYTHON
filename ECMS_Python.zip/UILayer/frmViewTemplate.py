import os
import tkinter
from tkinter import *


class ViewTemplate:

    def __init__(self, data_df):
        self.root = tkinter.Tk()
        self.root.title('View Template')
        self.root.iconbitmap(os.getcwd() + r"\Images\Emails.ico")
        self.root.geometry("{0}x{1}+0+0".format(self.root.winfo_screenwidth()-2, self.root.winfo_screenheight()-2))
        # self.root.minsize(width=self.root.winfo_screenwidth(), height=self.root.winfo_screenheight()-2)

        top_frame = Frame(self.root, bg="pink", height=20)
        top_frame.pack(side=TOP, fill="x")

        lbl_header = Label(top_frame, text="View email template", highlightthickness=0, background="pink",
                           bd=0, justify=CENTER)
        lbl_header.grid(row=0, column=1, padx=5, pady=5)
        lbl_header.config(font=('Verdana', 15))

        middle_frame = Frame(self.root, height=510)
        middle_frame.pack(side=TOP, fill="both")

        text = tkinter.Text(middle_frame, height=46, width=170, font=('Verdana', 10))
        text.pack(side=tkinter.LEFT)

        scroll = tkinter.Scrollbar(middle_frame, width=25)
        scroll.pack(side=tkinter.RIGHT, fill=tkinter.Y)

        text.configure(yscrollcommand=scroll.set)
        scroll.config(command=text.yview)

        # insert_text = """
        # Hi ABC,
        #
        # Thank you for providing the certificate, however as per Ryder’s requirements, we require the following revisions in the certificate-
        #
        # 1.	Revision for Auto tick
        #
        # •	We need Any Auto check if you have any auto policy(For All type of vehicle coverage) or Scheduled Auto tick if you have a scheduled policy(for specific VINS)
        #
        #
        # 2.	If the description of wording is missing or incorrect.
        #
        # •	Please provide this wording in the description of operation "Certificate Holder is named as additional insured and loss payee”
        #
        # 3.	If Hired PD not listed/only Deductibles listed for a Blanket policy
        #
        # •	Please provide HIRED physical damage deductibles (comprehensive and collision) on the certificate instead of Physical damage deductibles
        #
        # 4.	If the customer name does not match
        #
        # •	Please provide this insured name (customer name) as DBA/AKA on the certificate or confirm if you have changed the name
        #
        # 5.	IF PD limit is below $100k
        #
        # •	Please provide hired physical damage limit up to $100 K given limit is low as per Ryder requirement.
        #
        # 6.	If Signature is missing
        #
        # •	Please provide an Authorized signature on the certificate.
        #
        # 7.	If the Certificate holder name is missing
        #
        # •	The certificate holder should be Ryder Truck Rental, Inc. and Ryder Truck Rental LT & Affiliates
        # 6000 Windward Parkway
        # Alpharetta, GA 30005
        #
        # 8.	If CSL limit is low
        # •	Please provide the CSL limit up to $1,000,000
        #
        # 9.	IF Hazmat customer & CSL+Umbrella is below $5m
        #
        # •	As you carry hazardous materials, we require the CSL+Umbrella=$5,000,000 in the COI, the given limit is low.
        #
        # 10.	IF VINS are missing
        #
        # •	Please add below missing VINS in the certificate.
        #
        # 11.	If deductibles are missing
        #
        # •	Please add the Hired physical damage deductibles (Comp/Coll) in the COI
        #
        # 12.	Hazmat evaluator to be filled
        #
        # •	Thank you for the certificate, as you are carrying hazardous metrical, we require the attached Hazmat form to be filled & share it with us.
        #
        # 13.	If COI not received in Acord format
        #
        # •	Thank you for the certificate, we require the COI in Acord format as per our requirement.
        #
        # •	Please find the attached COI requirement file for reference & share us the revised COI with Acord format.
        #
        # 14.	If Insurance Card received
        #
        # Thank you for the Insurance card, however we require the certificate of Insurance instead of the card.
        #
        # Please find the attached COI requirement file & send us the certificate as per our requirements.
        #
        # 15.	Name change assignment to AM
        #
        # As per the below confirmation from the Insurance agency/customer, they have changed the customer name and the new name is mentioned in COI instead of the current Insured name.
        #
        # Request you to submit a name change assignment to reflect the correct name in our system.
        #
        # 16.	SIPD declined email to AM
        # Your customer's request for self-insurance/high deductible for physical damage has been declined by the Credit team.  Please let the customer know and let us know how to proceed.  The customer can provide coverage via a 3rd party agency (in which case, we need "HIRED PHYSICAL DAMAGE" and the comp. and collision deductibles added to the COI) or they can apply to purchase Ryder insurance.
        #
        # Joe Pace, CC'd in this email is the credit manager over the decision piece of Self-Insurance requests.
        #
        # 17.	If COI received only for Liability & we require the physical damage coverage in the certificate
        #
        # The COI is only for Liability coverage, we require the coverage for physical damage also.
        #
        # Please add “Loss Payee” wording in the description box and Hired Physical damage deductibles (Comp/Coll)in the certificate
        #
        # 18.	If COI received only for Physical damage coverage & we require the Liability coverage in the certificate
        #
        # The COI is only for physical damage coverage, we require the coverage for Auto Liability also.
        #
        # Please add Any auto in automobile session, “Additional Insured” wording in description box with a future expire date & CSL should be $1,000,000 listed in the COI.
        # """
        # text.insert(tkinter.END, insert_text)

        Counter = 1
        strEmailTemplateString = ""
        strEmailTemplateString = "Hi ABC,\n\nThank you for providing the certificate, however as per Ryder’s requirements, we require the following revisions in the certificate-\n\n"

        for index, df in data_df.iterrows():
            if str(df["ANY_AUTO_STATUS"]) == "TRUE" or str(df["SCHEDULED_AUTOS_STATUS"]) == "TRUE":
                strEmailTemplateString = strEmailTemplateString + "   " + str(Counter) + '. We need Any Auto check if you have any auto policy(For All type of vehicle coverage) or Scheduled Auto tick if you have a scheduled policy(for specific VINS).\n\n'
                Counter = Counter + 1

            if str(df["DESCRIPTION_STATUS"]) == "FALSE":
                strEmailTemplateString = strEmailTemplateString + "   " + str(Counter) + '. Please provide this wording in the description of operation "Certificate Holder is named as additional insured and loss payee”.\n\n'
                Counter = Counter + 1
            elif 'additional insured and loss payee' not in str(df["DESCRIPTION"]).lower():
                strEmailTemplateString = strEmailTemplateString + "   " + str(Counter) + '. Please provide this wording in the description of operation "Certificate Holder is named as additional insured and loss payee”.\n\n'
                Counter = Counter + 1

            if str(df["ANY_AUTO_STATUS"]) == "TRUE" and 'additional insured and loss payee' in str(df["DESCRIPTION"]).lower() and 'hired physical damage deductibles' not in str(df["DESCRIPTION"]).lower():
                strEmailTemplateString = strEmailTemplateString + "   " + str(Counter) + '. Please provide HIRED physical damage deductibles (comprehensive and collision) on the certificate instead of Physical damage deductibles.\n\n'
                Counter = Counter + 1

            if str(df["INSURER_NAME_STATUS"]) == "FALSE":
                strEmailTemplateString = strEmailTemplateString + "   " + str(Counter) + '. Please provide this insured name (customer name) as DBA/AKA on the certificate or confirm if you have changed the name.\n\n'
                Counter = Counter + 1

            if str(df["CERTIFICATE_HOLDER_STATUS"]) == "FALSE":
                strEmailTemplateString = strEmailTemplateString + "   " + str(Counter) + '. The certificate holder should be Ryder Truck Rental, Inc. and Ryder Truck Rental LT & Affiliates.\n\n'
                Counter = Counter + 1

            if str(df["COMBINED SINGLE LIMIT"]) != "None":
                if int(df["COMBINED SINGLE LIMIT"].replace(',', '')) < 1000000:
                    strEmailTemplateString = strEmailTemplateString + "   " + str(Counter) + f'. Please provide the CSL limit up to $1,000,000. Current is {df["COMBINED SINGLE LIMIT"]}.\n\n'
                    Counter = Counter + 1

                if int(df["COMBINED SINGLE LIMIT"].replace(',', '')) < 5000000:
                    strEmailTemplateString = strEmailTemplateString + "   " + str(Counter) + f'. As you carry hazardous materials, we require the CSL+Umbrella=$5,000,000 in the COI, the given limit is low. Current is {df["COMBINED SINGLE LIMIT"]}\n\n'
                    Counter = Counter + 1

            if 'physical damage deductible' in str(df["DESCRIPTION"]).lower() and 'self insured for physical damage' not in str(df["DESCRIPTION"]).lower():
                strEmailTemplateString = strEmailTemplateString + "   " + str(Counter) + '. Please add the Hired physical damage deductibles (Comp/Coll) in the COI.\n\n'
                Counter = Counter + 1

            if 'collision and comp deductibles' not in str(df["DESCRIPTION"]).lower() and 'comp and coll' not in str(df["DESCRIPTION"]).lower() and 'collision' not in str(df["DESCRIPTION"]).lower() and 'composition' not in str(df["DESCRIPTION"]).lower() and 'loss payee' not in str(df["DESCRIPTION"]).lower() and 'self-insured physical damage' not in str(df["DESCRIPTION"]).lower() and 'additional insured' in str(df["DESCRIPTION"]).lower():
                strEmailTemplateString = strEmailTemplateString + "   " + str(Counter) + '. The COI is only for Liability coverage, we require the coverage for physical damage also.\nPlease add “Loss Payee” wording in the description box and Hired Physical damage deductibles (Comp/Coll)in the certificate.\n\n'
                Counter = Counter + 1

            if 'loss payee' in str(df["DESCRIPTION"]).lower() and 'additional insured' not in str(df["DESCRIPTION"]).lower() and str(df["POLICY NUMBER"]) == "" and str(df["EFFECTIVE DATE"]) == "" and str(df["EFFECTIVE DATE 2"]) == "":
                strEmailTemplateString = strEmailTemplateString + "   " + str(Counter) + '. The COI is only for physical damage coverage, we require the coverage for Auto Liability also.\nPlease add Any auto in automobile session, “Additional Insured” wording in description box with a future expire date & CSL should be $1,000,000 listed in the COI.\n\n'
                Counter = Counter + 1

            if str(df["SCHEDULED_AUTOS_STATUS"]) == "TRUE":
                is_vins_missing = False
                vins_list = str(df["VINS_LIST"]).split(',')
                for item in vins_list:
                    if item.lower() not in str(df["DESCRIPTION"]).lower():
                        is_vins_missing = True
                        break

                if is_vins_missing is True:
                    strEmailTemplateString = strEmailTemplateString + "   " + str(Counter) + '. Please add below missing VINS in the certificate.\n\n'
                    Counter = Counter + 1

            if str(df["ANY_AUTO_STATUS"]) == "TRUE" and str(df["VINS_LISTED_STATUS"]) == "TRUE":
                is_vins_missing = False
                vins_list = str(df["VINS_LIST"]).split(',')
                for item in vins_list:
                    if item.lower() not in str(df["DESCRIPTION"]).lower():
                        is_vins_missing = True
                        break

                if is_vins_missing is True:
                    strEmailTemplateString = strEmailTemplateString + "   " + str(Counter) + '. Please add below missing VINS in the certificate.\n\n'
                    Counter = Counter + 1

            if str(df["IsHazmatCustomer"]).upper() == "YES":
                strEmailTemplateString = strEmailTemplateString + "   " + str(Counter) + '. Thank you for the certificate, as you are carrying hazardous metrical, we require the attached Hazmat form to be filled & share it with us.\n\n'
                Counter = Counter + 1

            # Email confirmation
            if (df["SCHEDULED_AUTOS_STATUS"] == "TRUE" or df["HIRED_AUTOS_ONLY_STATUS"] == "TRUE") and df["NON_OWNED_AUTO_ONLY_Status"] == "TRUE" and df["VINS_LISTED_STATUS"] == "TRUE" and df["COMPREHENSION/COLLISION_STATUS"] == "TRUE":
                strEmailTemplateString = strEmailTemplateString + "   " + str(Counter) + ". Please confirm that the given deductibles also apply to hired auto as well.\n•	Please confirm If the coverage is automatic for temporary replacement vehicles or the Insured needs to report it for the hired physical damage coverage.\n\n"
                Counter = Counter + 1
            elif str(df["SCHEDULED_AUTOS_STATUS"]) == "TRUE" and str(df["VINS_LISTED_STATUS"]) == "TRUE":
                strEmailTemplateString = strEmailTemplateString + "   " + str(Counter) + ". Please confirm If the coverage is automatic for temporary replacement vehicles or if the Insured needs to report it for the Liability & Physical damage coverage.\n\n"
                Counter = Counter + 1

            if str(df["RPPD"]).upper() == "YES":
                strEmailTemplateString = strEmailTemplateString + "   " + str(Counter) + ". As per our record, you have Ryder provided physical damage deductibles last time. \nWould you please confirm if you are going to take Ryder coverage or continue with your own PD deductibles this time.\n\n"
                Counter = Counter + 1

            if str(df["SIPD"]).upper() == "YES":
                strEmailTemplateString = strEmailTemplateString + "   " + str(Counter) + ". Would you please confirm if you are self Insured for physical damage, as there no coverage for physical damage coverage in the COI & as per our record you were self insured for physical damage coverage.\n\n"
                Counter = Counter + 1

        strEmailTemplateString = strEmailTemplateString + "\n\nThanks And Regards,\nXYZ"
        text.insert(tkinter.END, strEmailTemplateString)

        self.root.mainloop()
