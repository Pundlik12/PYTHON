import os
import hashlib
import tkinter
from tkinter import messagebox
from PIL import ImageTk, Image
from BusinessLayer import UserBAL
from Common.AppSettings import AppSettings
from DataAccessLayer import UserDAL
from UILayer.frmMainForm import MainForm


class LoginForm:

    def __init__(self):
        self.window = tkinter.Tk()
        self.window.title("Login Form")
        self.window.resizable(False, False)
        self.window.iconbitmap(os.getcwd() + r"\Images\Emails.ico")

        w = self.window.winfo_reqwidth()
        h = self.window.winfo_reqheight()
        ws = self.window.winfo_screenwidth()
        hs = self.window.winfo_screenheight()
        x = (ws/2) - (w/2)
        y = (hs/2) - (h/2)
        self.window.geometry('+%d+%d' % (x, y))
        # self.window.configure(bg='#8F00FF')

        frame = tkinter.Frame()  # bg='#8F00FF'
        frame.pack(side=tkinter.TOP, fill="x")

        login_label = tkinter.Label(frame, text="Login Form", bg='pink', font=("Arial", 20))
        login_label.grid(row=0, column=0, columnspan=3, sticky="news")

        # img_path = os.getcwd() + r"\Images\Login_Background.jpg"
        # background_image = tkinter.PhotoImage(img_path)
        # background_label = tkinter.Label(frame, image=background_image)
        # background_label.place(x=0, y=1, relwidth=1, relheight=1)

        # img = Image.open(img_path)
        # img = ImageTk.PhotoImage(img)

        # label_image = tkinter.Label(frame, image=background_image)
        # label_image.photo = background_image
        # label_image.grid(row=1, column=0, rowspan=2, sticky="news")

        username_label = tkinter.Label(frame, text="User ID:-", font=("Arial", 12))  # bg='#8F00FF', fg="#FFFFFF",
        username_label.grid(row=1, column=1, sticky="e")

        self.username_entry = tkinter.Entry(frame, font=("Arial", 16))
        self.username_entry.grid(row=1, column=2, pady=20)

        password_label = tkinter.Label(frame, text="Password:-", font=("Arial", 12))  # bg='#8F00FF', fg="#FFFFFF",
        password_label.grid(row=2, column=1, sticky="e")

        self.password_entry = tkinter.Entry(frame, show="*", font=("Arial", 16))
        self.password_entry.grid(row=2, column=2, pady=20)

        login_button = tkinter.Button(frame, text="Login", width=10, bg="#DC143C", fg="#FFFFFF", font=("Arial", 16), command=self.login)
        login_button.grid(row=3, column=2, columnspan=2, pady=10, sticky="w")

        windows_ID = os.environ.get('USERNAME').upper()
        self.username_entry.insert(0, windows_ID)
        self.password_entry.focus()

        # Read App Settings to get all settings related to application like outlook Email Address, Folder Name
        self.ObjApp_Sett = AppSettings()
        self.App_Settings_Data = self.ObjApp_Sett.Read_Settings()

        outlook = self.App_Settings_Data['Outlook']
        self.strEmailAddress = outlook['EmailAddress']
        self.strFolderName = outlook['FolderName']

        Database = self.App_Settings_Data['Database']
        self.strServerName = Database['ServerName']
        self.strDatabaseName = Database['DatabaseName']

        GenAI = self.App_Settings_Data['GenAI']
        self.strEndPoint = GenAI['EndPoint']
        self.strKey = GenAI['Key']
        self.strModelID = GenAI['ModelID']

        user_dal = UserDAL.UserDataAccess()
        self.obj_userBal = UserBAL.UserBusinessLayer(user_dal)
        self.user_list = self.obj_userBal.get_user_details()

        self.window.mainloop()

    def login(self):
        userid = self.username_entry.get()
        pwd = self.password_entry.get()

        if userid.strip() == "":
            messagebox.showinfo(title="Login Form", message="Please enter the user ID.")
            return
        elif pwd.strip() == "":
            messagebox.showinfo(title="Login Form", message="Please enter the password.")
            return

        chk = self.check_user_exists()
        if chk is True:
            username = ""
            user_role = ""
            auth = pwd.encode()
            auth_hash = hashlib.md5(auth).hexdigest()

            isValid = False
            for user in self.user_list:
                username = str(user[1])
                stored_userid = str(user[2])
                stored_pwd = str(user[3])
                user_role = str(user[4])

                if userid.upper() == stored_userid.upper() and auth_hash == stored_pwd:
                    isValid = True
                    break

            if isValid is True:
                # messagebox.showinfo(title="Login Form", message="You successfully logged in.")
                self.window.destroy()

                main_screen = MainForm()

                main_screen.strEmailAddress = self.strEmailAddress
                main_screen.strFolderName = self.strFolderName
                main_screen.strServerName = self.strServerName
                main_screen.strDatabaseName = self.strDatabaseName
                main_screen.strEndPoint = self.strEndPoint
                main_screen.strKey = self.strKey
                main_screen.strModelID = self.strModelID

                main_screen.LoginUserID = userid
                main_screen.LoginUserName = username
                main_screen.UserRole = user_role

                main_screen.Initialize_Objects()
                main_screen.mainloop()
            else:
                messagebox.showinfo(title="Login Form", message="Login failed!")

    def check_user_exists(self):
        try:
            windows_ID = os.environ.get('USERNAME')
            user_lst = self.obj_userBal.get_user_details_by_UID(windows_ID)
            if len(user_lst) == 0:
                return False
            else:
                return True
        except Exception as Error:
            print(f'Error occurred in check_user_exists function:-{Error}')
            return False
