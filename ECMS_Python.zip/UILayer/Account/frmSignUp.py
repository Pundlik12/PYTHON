import hashlib
import os
import tkinter
from tkinter import messagebox


class SignUpForm:
    def __init__(self):
        self.window = tkinter.Tk()
        self.window.title("Signup Form")
        self.window.resizable(False, False)
        self.window.iconbitmap(os.getcwd() + r"\Images\Emails.ico")

        w = self.window.winfo_reqwidth()
        h = self.window.winfo_reqheight()
        ws = self.window.winfo_screenwidth()
        hs = self.window.winfo_screenheight()
        x = (ws/2) - (w/2)
        y = (hs/2) - (h/2)
        self.window.geometry('+%d+%d' % (x, y))
        # self.window.configure(bg='#8F00FF')

        frame = tkinter.Frame()  # bg='#8F00FF'
        frame.pack(side=tkinter.TOP, fill="x")

        login_label = tkinter.Label(frame, text="Signup Form", bg='pink', font=("Arial", 20))
        login_label.grid(row=0, column=0, columnspan=2, sticky="news")

        self.username_entry = tkinter.Entry(frame, font=("Arial", 16))
        self.username_entry.grid(row=1, column=1, pady=20)
        self.username_entry.focus()

        username_label = tkinter.Label(frame, text="User Name:-", font=("Arial", 12))  # bg='#8F00FF', fg="#FFFFFF",
        username_label.grid(row=1, column=0, sticky="e")

        password_label = tkinter.Label(frame, text="Password:-", font=("Arial", 12))  # bg='#8F00FF', fg="#FFFFFF",
        password_label.grid(row=2, column=0, sticky="e")

        self.password_entry = tkinter.Entry(frame, show="*", font=("Arial", 16))
        self.password_entry.grid(row=2, column=1, pady=20)

        confirm_password_label = tkinter.Label(frame, text="Confirm Password:-", font=("Arial", 12))  # bg='#8F00FF', fg="#FFFFFF",
        confirm_password_label.grid(row=3, column=0, sticky="e")

        self.confirm_password_entry = tkinter.Entry(frame, show="*", font=("Arial", 16))
        self.confirm_password_entry.grid(row=3, column=1, pady=20)

        role_label = tkinter.Label(frame, text="Select Role:-", font=("Arial", 12))
        role_label.grid(row=4, column=0, pady=20, sticky="e")

        self.role_clicked = tkinter.StringVar(value="Select")
        self.role_options = ["Admin", "User"]
        self.role_dropdown = tkinter.OptionMenu(frame, self.role_clicked, *self.role_options)
        self.role_dropdown.grid(row=4, column=1, sticky=tkinter.W)
        self.role_dropdown.config(width=20, height=2, bg="#ffbf00", font=('Arial', 12))

        self.login_button = tkinter.Button(frame, text="SignUp", bg="#DC143C", fg="#FFFFFF", font=("Arial", 16), command=self.signup)
        self.login_button.grid(row=5, column=0, columnspan=2, padx=20, pady=20)

        self.window.mainloop()

    def signup(self):
        username = self.username_entry.get()
        pwd = self.password_entry.get()
        conf_pwd = self.confirm_password_entry.get()
        user_role = self.role_clicked.get()
        # role_clicked.set('Select')

        if username.strip() == "":
            messagebox.showinfo(title="SignUp Form", message="Please enter the user name.")
            self.username_entry.focus()
            return
        elif pwd.strip() == "":
            messagebox.showinfo(title="SignUp Form", message="Please enter the password.")
            self.password_entry.focus()
            return
        elif conf_pwd.strip() == "":
            messagebox.showinfo(title="SignUp Form", message="Please enter the confirm password.")
            self.confirm_password_entry.focus()
            return
        elif user_role.strip() == "" or user_role.strip() == "Select":
            messagebox.showinfo(title="SignUp Form", message="Please select user role.")
            self.role_dropdown.focus()
            return

        if conf_pwd == pwd:
            enc = conf_pwd.encode()
            hash1 = hashlib.md5(enc).hexdigest()
            text = str(username) + "|" + str(hash1) + "|" + str(user_role) + "\n"

            with open("credentials.txt", "a") as f:
                f.writelines(text)

            f.close()

            messagebox.showinfo(title="SignUp Form", message="You have registered successfully!")
        else:
            messagebox.showinfo(title="SignUp Form", message="Password and confirm password does not match!")
