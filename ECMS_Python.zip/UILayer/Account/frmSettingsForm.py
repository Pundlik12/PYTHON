import os
import tkinter as tk
from tkinter import ttk, messagebox
from Common.AppSettings import AppSettings


class SettingsForm:

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Settings")
        self.root.resizable(False, False)
        self.root.iconbitmap(os.getcwd() + r"\Images\Emails.ico")

        w = self.root.winfo_reqwidth()
        h = self.root.winfo_reqheight()
        ws = self.root.winfo_screenwidth()
        hs = self.root.winfo_screenheight()
        x = (ws/2) - (w/2)
        y = (hs/2) - (h/2)
        self.root.geometry('+%d+%d' % (x, y))

        button_style = ttk.Style()
        button_style.configure('Kim.TButton', foreground="black", background="maroon", font=('Helvetica', 12), height=10, width=10)

        conf_label = ttk.Label(self.root, text="Configurations Details")
        conf_label.pack(side="top", fill="x", expand=False)
        conf_label.configure(background="pink", font=('Arial', 15, 'bold'))

        tabControl = ttk.Notebook(self.root)

        tab1 = ttk.Frame(tabControl)
        tab2 = ttk.Frame(tabControl)
        tab3 = ttk.Frame(tabControl)

        tabControl.add(tab1, text='Outlook')
        tabControl.add(tab2, text='Database')
        tabControl.add(tab3, text='Gen AI')
        tabControl.pack(expand=1, fill="both")

        # Outlook Configurations tab
        generic_email_label = ttk.Label(tab1, text="Generic Email Address:-", font=("Arial", 13))
        generic_email_label.grid(column=0, row=1, padx=5, pady=5, sticky="e")

        self.GenericEmailID_entry = ttk.Entry(tab1, font=("Arial", 13), width=30)
        self.GenericEmailID_entry.grid(column=1, row=1, pady=5)

        folder_name_label = ttk.Label(tab1, text="Folder Name:-", font=("Arial", 13))
        folder_name_label.grid(column=0, row=2, padx=5, pady=5, sticky="e")

        self.FolderName_entry = ttk.Entry(tab1, font=("Arial", 13), width=30)
        self.FolderName_entry.grid(column=1, row=2, pady=5)

        self.save_outlook_button = tk.Button(tab1, text="Save", font=("Arial", 13), width=15, height=2, bg="#ffbf00", command=self.Save_Settings)
        self.save_outlook_button.grid(column=1, row=3, columnspan=2, padx=5, pady=5, sticky="w")

        # Database Configurations Tab
        Server_IP_label = ttk.Label(tab2, text="Server Name/IP:-", font=("Arial", 13))
        Server_IP_label.grid(column=0, row=1, padx=5, pady=5, sticky="e")

        self.Server_Name_entry = ttk.Entry(tab2, font=("Arial", 13), width=30)
        self.Server_Name_entry.grid(column=1, row=1, pady=5)

        Database_Name_label = ttk.Label(tab2, text="Database Name:-", font=("Arial", 13))
        Database_Name_label.grid(column=0, row=2, padx=5, pady=5, sticky="e")

        self.Database_Name_entry = ttk.Entry(tab2, font=("Arial", 13), width=30)
        self.Database_Name_entry.grid(column=1, row=2, pady=5)

        self.save_database_button = tk.Button(tab2, text="Save", font=("Arial", 13), width=15, height=2, bg="#ffbf00", command=self.Save_Settings)
        self.save_database_button.grid(column=1, row=3, columnspan=2, padx=5, pady=5, sticky="w")

        # Gen AI Configurations Tab
        Endpoint_label = ttk.Label(tab3, text="End point:-", font=("Arial", 13))
        Endpoint_label.grid(column=0, row=1, padx=5, pady=5, sticky="e")

        self.Endpoint_entry = ttk.Entry(tab3, font=("Arial", 13), width=40)
        self.Endpoint_entry.grid(column=1, row=1, pady=5)

        Key_label = ttk.Label(tab3, text="Key:-", font=("Arial", 13))
        Key_label.grid(column=0, row=2, padx=5, pady=5, sticky="e")

        self.Key_entry = ttk.Entry(tab3, font=("Arial", 13), width=40)
        self.Key_entry.grid(column=1, row=2, pady=5)

        ModelId_label = ttk.Label(tab3, text="Model ID:-", font=("Arial", 13))
        ModelId_label.grid(column=0, row=3, padx=5, pady=5, sticky="e")

        self.ModelID_entry = ttk.Entry(tab3, font=("Arial", 13), width=40)
        self.ModelID_entry.grid(column=1, row=3, pady=5)

        self.save_GenAI_button = tk.Button(tab3, text="Save", font=("Arial", 13), width=15, height=2, bg="#ffbf00", command=self.Save_Settings)
        self.save_GenAI_button.grid(column=1, row=4, columnspan=2, padx=5, pady=5, sticky="w")

        self.ObjApp_Sett = AppSettings()
        self.Read_Settings()
        self.root.mainloop()

    def Read_Settings(self):
        try:
            data = self.ObjApp_Sett.Read_Settings()

            if data is not None:
                outlook = data['Outlook']
                EmailAddress = outlook['EmailAddress']
                FolderName = outlook['FolderName']
                self.GenericEmailID_entry.insert(0, str(EmailAddress))
                self.FolderName_entry.insert(0, str(FolderName))

                Database = data['Database']
                ServerName = Database['ServerName']
                DatabaseName = Database['DatabaseName']
                self.Server_Name_entry.insert(0, str(ServerName))
                self.Database_Name_entry.insert(0, str(DatabaseName))

                GenAI = data['GenAI']
                EndPoint = GenAI['EndPoint']
                Key = GenAI['Key']
                ModelID = GenAI['ModelID']

                self.Endpoint_entry.insert(0, str(EndPoint))
                self.Key_entry.insert(0, str(Key))
                self.ModelID_entry.insert(0, str(ModelID))
            else:
                messagebox.showinfo(title="App Settings", message="Error occurred while reading app settings")
                self.root.attributes('-topmost', 1)
                self.root.attributes('-topmost', 0)
        except Exception as Error:
            print(f'Error in Read_AppSettings function:- {Error}')

    def Save_Settings(self):
        try:
            strEmailAddress = self.GenericEmailID_entry.get()
            strFolderName = self.FolderName_entry.get()
            strServerName = self.Server_Name_entry.get()
            strDatabaseName = self.Database_Name_entry.get()
            strEndPoint = self.Endpoint_entry.get()
            strKey = self.Key_entry.get()
            strModelID = self.ModelID_entry.get()

            if strEmailAddress.strip() == "":
                self.GenericEmailID_entry.focus()
                messagebox.showerror(title="App Settings", message="Please enter generic email address.")
            elif strFolderName.strip() == "":
                self.FolderName_entry.focus()
                messagebox.showerror(title="App Settings", message="Please enter folder name.")
            elif strServerName.strip() == "":
                self.Server_Name_entry.focus()
                messagebox.showerror(title="App Settings", message="Please enter server name.")
            elif strDatabaseName.strip() == "":
                self.Database_Name_entry.focus()
                messagebox.showerror(title="App Settings", message="Please enter database name.")
            elif strEndPoint.strip() == "":
                self.Endpoint_entry.focus()
                messagebox.showerror(title="App Settings", message="Please enter azure api endpoint.")
            elif strKey.strip() == "":
                self.Key_entry.focus()
                messagebox.showerror(title="App Settings", message="Please enter azure api Key.")
            elif strModelID.strip() == "":
                self.ModelID_entry.focus()
                messagebox.showerror(title="App Settings", message="Please enter azure api ModelID.")
            else:
                confirmMsg = "Please confirm on below entries\n\n"
                confirmMsg = confirmMsg + f"Generic Email Address: {strEmailAddress}\nFolder Name: {strFolderName}\nServer Name: {strServerName}\nDatabase Name: {strDatabaseName}\nEnd Point: {strEndPoint}\nKey: {strKey}\nModel ID: {strModelID}"

                out = messagebox.askyesno(title="Confirm App Settings", message=confirmMsg)
                if out == 1:
                    out = self.ObjApp_Sett.Save_Settings(strEmailAddress, strFolderName, strServerName, strDatabaseName, strEndPoint, strKey, strModelID)
                    if out is True:
                        messagebox.showinfo(title="App Settings", message="App settings are updated successfully.")
                    else:
                        messagebox.showinfo(title="App Settings", message="Error occurred while saving app settings.")
                else:
                    messagebox.showinfo(title="App Settings", message="Action cancelled.")

            self.root.attributes('-topmost', 1)
            self.root.attributes('-topmost', 0)
        except Exception as Error:
            print(f'Error in Save_Settings function:- {Error}')
