import os
from datetime import timedelta
from tkinter import *
from tkinter import ttk, messagebox
import tkinter as tk

import pandas
import pandas as pd
from tkcalendar import DateEntry
from Common import Outlook
from BusinessLayer import EmailsBAL, ExtractedPDFDetailsBAL
from DataAccessLayer import EmailDAL, ExtractedPDFDetailsDAL
from Azure.extractazure import Extract_data_from_Azure
from Azure.Validations import validate_and_save_data
from UILayer.Account.frmSettingsForm import SettingsForm
from UILayer.frmViewForm import ViewForm
from UILayer.frmViewTemplate import ViewTemplate
from tktooltip import ToolTip


class MainForm(Tk):

    def __init__(self):
        super().__init__()

        self.strEmailAddress = ""
        self.strFolderName = ""
        self.strServerName = ""
        self.strDatabaseName = ""
        self.strEndPoint = ""
        self.strKey = ""
        self.strModelID = ""

        self.LoginUserName = ""
        self.LoginUserID = ""
        self.UserRole = ""

        self.config(background="lightblue")
        self.title("Ryder COI Extraction Tool v1.0")
        self.minsize(width=self.winfo_screenwidth(), height=self.winfo_screenheight())
        # self.config(padx=2, pady=2)
        self.iconbitmap(os.getcwd() + r"\Images\Emails.ico")

        top_frame = Frame(self, bg="pink", height=15)
        top_frame.pack(side=TOP, fill="x")

        label_header = Label(top_frame, text="Ryder COI Extraction Tool", font=("Times", 15, "bold"), bg='pink')
        label_header.pack(side=LEFT, pady=3)

        self.setting_button_img = PhotoImage(file=os.getcwd() + r"\Images\Settings.png")
        self.setting_button_img = self.setting_button_img.subsample(2, 2)
        self.button_settings = Button(top_frame, image=self.setting_button_img, borderwidth=0, command=self.settings_click)
        self.button_settings.pack(side=RIGHT, padx=10, pady=3)
        ToolTip(self.button_settings, msg="Settings")

        self.user_button_img = PhotoImage(file=os.getcwd() + r"\Images\ProfileImage.png")
        self.user_button_img = self.user_button_img.subsample(2, 2)
        self.button_user = Button(top_frame, image=self.user_button_img, borderwidth=0)
        self.button_user.pack(side=RIGHT, padx=6, pady=3)

        middle_frame = Frame(self, height=510)
        middle_frame.pack(side=TOP, fill="both")

        self.start_label = Label(middle_frame, text="Start Date:", font=('Verdana', 10))
        self.start_label.grid(row=3, column=0, sticky=E, pady=5)

        self.start_date_calendar = DateEntry(middle_frame, width=12, foreground="white", borderwidth=2)
        self.start_date_calendar.grid(row=3, column=1, pady=5, padx=5)

        self.end_label = Label(middle_frame, text="End Date:", font=('Verdana', 10))
        self.end_label.grid(row=3, column=3, sticky=W, pady=5)

        self.end_date_calendar = DateEntry(middle_frame, width=12, foreground="white", borderwidth=2)
        self.end_date_calendar.grid(row=3, column=4, sticky=W, pady=5, padx=5)

        # Sync button
        self.btnSynch = Button(middle_frame, text="Sync Emails from Outlook", bg="#ffbf00", height=2,
                               font=('Verdana', 10), justify=CENTER, command=self.sync_email_click)
        self.btnSynch.grid(row=3, column=5, pady=5)
        ToolTip(self.btnSynch, msg="Sync Emails from Outlook")

        self.btnExtractAndValidate = Button(middle_frame, text="Extract and Validate", bg="#ffbf00", height=2,
                                            font=('Verdana', 10), justify=CENTER,
                                            command=self.extract_and_validate_click)
        self.btnExtractAndValidate.grid(row=3, column=6, pady=5, padx=5)
        ToolTip(self.btnExtractAndValidate, msg="Extract and Validate")

        self.btnViewAll = Button(middle_frame, text="Fetch Data From DB", bg="#ffbf00", height=2,
                                 font=('Verdana', 10), justify=CENTER,
                                 command=self.fetch_data_from_db_click)
        self.btnViewAll.grid(row=3, column=7, pady=5)
        ToolTip(self.btnExtractAndValidate, msg="Fetch Data From DB")

        # self.end_label = Label(self.frameTop, text="Search by:")
        # self.end_label.grid(column=0, row=4, sticky=E)
        #
        # options = ["All", "Subject", "Priority", "Status"]
        # self.clicked = StringVar()
        # # initial menu text
        # self.clicked.set("All")
        # self.search_dropdown = OptionMenu(self.frameTop, self.clicked, *options)
        # self.search_dropdown.grid(column=1, row=4, columnspan=2)
        # self.search_dropdown.config(width=20)
        #
        # self.search_textbox = Text(self.frameTop, height=2, width=40)
        # self.search_textbox.grid(column=3, row=4, columnspan=4, sticky=W)
        #
        # self.btnSearch = Button(self.frameTop, highlightthickness=0, bd=0,
        #                         width=30, background="#ffefea", text="Search Email(s)", height=2)
        # self.btnSearch.grid(column=6, row=4)
        # self.btnSearch.columnconfigure(1, weight=1)

        self.frameList = Frame(self, height=510)
        self.frameList.pack(side=TOP, fill="both")

        # self.frameList = Frame(self)
        # # self.frameList.grid(column=0, row=4)
        # self.frameList.pack(side=TOP, fill="both")
        # self.frameList.grid_columnconfigure(1, weight=0)

        columns = (
            "Action1", "Action2", "MailBox_Name", "Sender_Name", "Received_Time",
            "Subject", "Priority", "Status", "Attachment_Count", "Entry_ID",
            "ConversationID")
        self.treeEmails = ttk.Treeview(self.frameList, columns=columns, selectmode='browse', show="headings")

        style = ttk.Style(middle_frame)
        style.theme_use("classic")
        style.configure("Treeview", background="white", fieldbackground="white", foreground="white",
                        font=('Verdana', 8))
        style.configure('Treeview.Heading', background="PowderBlue", font=('Arial Bold', 10))

        # define headings
        self.treeEmails.heading('Action1', text='Action1')
        self.treeEmails.heading('Action2', text='Action2')
        self.treeEmails.heading('MailBox_Name', text='MailBox_Name')
        self.treeEmails.heading('Sender_Name', text='Sender_Name')
        self.treeEmails.heading('Received_Time', text='Received_Time')
        self.treeEmails.heading('Subject', text='Subject')
        self.treeEmails.heading('Priority', text='Priority')
        self.treeEmails.heading('Status', text='Status')
        self.treeEmails.heading('Attachment_Count', text='Attachment_Count')
        self.treeEmails.heading('Entry_ID', text='Entry_ID')
        self.treeEmails.heading('ConversationID', text='ConversationID')

        self.treeEmails.column('Action1', width=100, anchor=tk.CENTER)
        self.treeEmails.column('Action2', width=100, anchor=tk.CENTER)
        self.treeEmails.column("MailBox_Name", width=140, anchor=tk.CENTER)
        self.treeEmails.column("Sender_Name", width=140, anchor=tk.CENTER)
        self.treeEmails.column("Received_Time", width=120, anchor=tk.CENTER)
        self.treeEmails.column("Subject", width=200, anchor=tk.CENTER)
        self.treeEmails.column("Priority", width=70, anchor=tk.CENTER)
        self.treeEmails.column("Status", width=80, anchor=tk.CENTER)
        self.treeEmails.column("Attachment_Count", width=50, anchor=tk.CENTER)
        self.treeEmails.column("Entry_ID", width=200, anchor=tk.CENTER)
        self.treeEmails.column("ConversationID", width=200, anchor=tk.CENTER)

        self.treeEmails.grid(column=0, row=0, sticky="e")
        self.treeEmails.config(height=30)
        self.treeEmails.bind("<Double-1>", self.OnDouble_Click)

        self.treeEmails.tag_configure("oddrow", background="lightGray")
        self.treeEmails.tag_configure("evenrow", background="lightyellow")

        # Vertical scrollbar
        vsb = ttk.Scrollbar(self.frameList, orient="vertical", command=self.treeEmails.yview)
        self.treeEmails.configure(yscrollcommand=vsb.set)
        vsb.grid(row=0, column=1, sticky="ns")

        statusframe = Frame(self, height=50)
        statusframe.pack(side=TOP, fill="both")

        self.No_of_Dashboard_Mails_label = Label(statusframe, text="No of Mails in Dashboard:- 0",
                                                 font=('Callibri', 13))
        self.No_of_Dashboard_Mails_label.grid(row=1, column=0, padx=5, pady=5, sticky=W)
        self.No_of_Dashboard_Mails_label.config(bg="#ff6347")

        self.No_of_Extracted_Mails_label = Label(statusframe, text="No of Mails Extracted:- 0", font=('Callibri', 13))
        self.No_of_Extracted_Mails_label.grid(row=1, column=1, padx=5, pady=5, sticky=W)
        self.No_of_Extracted_Mails_label.config(bg="#3cb371")

        self.No_of_Validated_Mails_label = Label(statusframe, text="No of Mails Validated:- 0", font=('Callibri', 13))
        self.No_of_Validated_Mails_label.grid(row=1, column=2, padx=5, pady=5, sticky=W)
        self.No_of_Validated_Mails_label.config(bg="#ff0000")

        self.sync_emailed_list = []
        self.new_emails_list = []
        self.Extracted_info_list = []
        self.Validated_info_list = []

        self.cpim_master_file_path = ""
        self.obj_outlook = None
        self.obj_extract_and_validate = None
        self.obj_emailsBal = None
        self.obj_extractBal = None

    def Initialize_Objects(self):
        ToolTip(self.button_user, msg=f"{self.LoginUserName} : {self.LoginUserID}")
        # create outlook and extract and validate class object
        self.obj_outlook = Outlook.OutlookEmails(self.strEmailAddress, self.strFolderName)
        self.obj_extract_and_validate = Extract_data_from_Azure(self.strEndPoint, self.strKey, self.strModelID)

        email_dal = EmailDAL.EmailDataAccess()
        self.obj_emailsBal = EmailsBAL.EmailsBusinessLayer(email_dal)

        extraction_dal = ExtractedPDFDetailsDAL.ExtractedDataDataAccess()
        self.obj_extractBal = ExtractedPDFDetailsBAL.ExtractedPDFDetailsBusinessLayer(extraction_dal)

        # extraction_dal = ExtractedPDFDetailsDAL.ExtractedDataDataAccess()
        # self.obj_extractBal = ExtractedPDFDetailsBAL.ExtractedPDFDetailsBusinessLayer(extraction_dal)

        if self.UserRole == "Admin":
            self.btnExtractAndValidate.config(state="normal")
            self.button_settings.config(state="normal")
            self.btnSynch.config(state="normal")
        else:
            self.btnSynch.config(state="disabled")
            self.btnExtractAndValidate.config(state="disabled")
            self.button_settings.config(state="disabled")

    def sync_email_click(self):
        isEmailIDConfigured = self.obj_outlook.ValidateAccount()
        if isEmailIDConfigured is True:
            start_date = self.start_date_calendar.get_date()
            start_date = start_date + timedelta(hours=-12)
            start_date = start_date.strftime("%m/%d/%Y %I:%M %p")

            end_date = self.end_date_calendar.get_date()
            end_date = end_date + timedelta(days=1)
            end_date = end_date.strftime("%m/%d/%Y %I:%M %p")

            self.sync_emailed_list = self.obj_outlook.SynchEmails(start_date, end_date)
            if len(self.sync_emailed_list) > 0:
                self.new_emails_list = []
                for item in self.sync_emailed_list:
                    entryID = str(item[7])
                    entryID_lst = self.obj_emailsBal.get_email_details_by_entryID(entryID)
                    if len(entryID_lst) == 0:
                        self.new_emails_list.append(item)

                if len(self.new_emails_list) > 0:
                    self.obj_emailsBal.add_email_details(self.new_emails_list)
                    self.display_emails()

                    messagebox.showinfo("Ryder COI Extraction Tool", "New emails synced successfully from outlook.")
                else:
                    messagebox.showinfo("Ryder COI Extraction Tool", "New emails not found.")
        else:
            messagebox.showinfo("Ryder COI Extraction Tool", "Your Outlook Account is not configured")

    def extract_and_validate_click(self):
        # if self.validate_CPIM_MasterFile() is True:
        input_pdf_directory_path = os.getcwd() + "\\PdfFiles"
        self.Extracted_info_list = self.obj_extract_and_validate.extract_validate_and_save_data(
            input_pdf_directory_path)
        self.Validated_info_list = validate_and_save_data(input_pdf_directory_path + "\\SNL_Ryder_Output.csv")
        # self.obj_extractBal.add_extracted_pdf_details(self.Extracted_info_list)
        messagebox.showinfo('Ryder COI Extraction Tool', 'Data Extraction and Validation procedure completed..')

    def fetch_data_from_db_click(self):
        try:
            self.new_emails_list = []
            self.new_emails_list = self.obj_emailsBal.get_email_details()
            self.display_emails()
        except Exception as Error:
            print(f'Error in fetch_data_from_db_click function\n{Error}')

    def display_emails(self):
        try:
            for item in self.treeEmails.get_children():
                self.treeEmails.delete(item)

            for item in self.new_emails_list:
                Extracted_Data = "Extracted data"
                Email_Template = "Email Template"
                mailbox_Name = item[0]
                sender_name = item[1]
                received_time = item[2]
                subject = item[3]
                priority = item[4]
                status = item[5]
                attachment_count = item[6]
                entry_id = item[7]
                conversation_id = item[8]

                self.treeEmails.insert("", "end", values=(Extracted_Data, Email_Template,
                                                          mailbox_Name, sender_name, received_time, subject, priority,
                                                          status, attachment_count,
                                                          entry_id, conversation_id))

                self.No_of_Dashboard_Mails_label.config(text=f"No of Mails in Dashboard:- {len(self.new_emails_list)}")
        except Exception as Error:
            print(f'Error in display_emails function\n{Error}')

    def OnDouble_Click(self, event):
        column_selected = self.treeEmails.identify_column(event.x)
        if column_selected == "#1":
            for selected_item in self.treeEmails.selection():
                item = self.treeEmails.item(selected_item)
                record = item['values']
                entryID = str(record[9])

                try:
                    if len(self.Validated_info_list) > 0:
                        filtered_df = self.Validated_info_list[self.Validated_info_list['Filename'].str.contains(entryID)]
                        if len(filtered_df) > 0:
                            Extraction_columns = ['PRODUCER', 'INSURED NAME', 'INSURED ADDRESS',
                                                  'CONTACT NAME', 'EMAIL ADDRESS', 'PHONE NUMBER',
                                                  'FAX NUMBER', 'INSURER A', 'INSURER B',
                                                  'INSURER C', 'INSURER D', 'INSURER E',
                                                  'INSURER F', 'INS LTR A', 'INS LTR B',
                                                  'INS LTR C', 'INS LTR D', 'INS LTR E',
                                                  'INS LTR F', 'ANY AUTO TEXT', 'OWNED AUTOS ONLY TEXT',
                                                  'HIRED AUTOS ONLY TEXT', 'SCHEDULED AUTOS TEXT',
                                                  'NON-OWNED AUTO ONLY TEXT',
                                                  'ADDL INSD', 'POLICY NUMBER', 'EFFECTIVE DATE',
                                                  'EFFECTIVE DATE 2', 'COMBINED SINGLE LIMIT', 'DESCRIPTION',
                                                  'CERTIFICATE HOLDER', 'COLL/COMP']
                            table1_dff = filtered_df[Extraction_columns].copy()

                            validation_columns = ['PRODUCER_COMMENTS', 'INSURER_NAME_COMMENTS',
                                                  'INSURER_ADDRESS_COMMENTS',
                                                  'CONTACT_NAME_COMMENTS', 'EMAIL_ADDRESS_COMMENTS',
                                                  'PHONE_NUMBER_COMMENTS',
                                                  'FAX_NUMBER_COMMENTS', 'INSURER_A_COMMENTS', 'INSURER_B_COMMENTS',
                                                  'INSURER_C_COMMENTS', 'INSURER_D_COMMENTS', 'INSURER_E_COMMENTS',
                                                  'INSURER_F_COMMENTS', 'INSR_LTR_A_COMMENTS', 'INSR_LTR_B_COMMENTS',
                                                  'INSR_LTR_C_COMMENTS', 'INSR_LTR_D_COMMENTS', 'INSR_LTR_E_COMMENTS',
                                                  'INSR_LTR_F_COMMENTS', 'ANY_AUTO_COMMENTS',
                                                  'OWNED_AUTOS_ONLY_COMMENTS',
                                                  'HIRED_AUTOS_ONLY_COMMENTS', 'SCHEDULED_AUTOS_COMMENTS',
                                                  'NON_OWNED_AUTO_ONLY_COMMENTS',
                                                  'ADDL_INSD_COMMENTS', 'POLICY_NUMBER_COMMENTS',
                                                  'EFFECTIVE_DATE_COMMENTS',
                                                  'EXPIRY_DATE_COMMENTS', 'COMBINED_SINGLE_LIMIT_COMMENTS',
                                                  'DESCRIPTION_COMMENTS',
                                                  'CERTIFICATE_HOLDER_COMMENTS', 'COMPREHENSION/COLLISION_COMMENTS']
                            table2_dff = filtered_df[validation_columns].copy()

                            table1_columns_list = table1_dff.columns.tolist()
                            table1_row_list = table1_dff.values.tolist()
                            table2_columns = table2_dff.columns.tolist()
                            table2_row_list = table2_dff.values.tolist()

                            extracted_data = []
                            for row, r in enumerate(table1_row_list):
                                for col, c in enumerate(r):
                                    extracted_data.append(r[col])

                            validated_data = []
                            for row, r in enumerate(table2_row_list):
                                for col, c in enumerate(r):
                                    validated_data.append(r[col])

                            # print(f'{len(table1_columns_list)},{len(extracted_data)},{len(validated_data)}')
                            result = pd.DataFrame(
                                {'Field_Names': table1_columns_list,
                                 'Extracted_Data': extracted_data,
                                 'Validated_Data': validated_data
                                 })

                            vf = ViewForm(result)
                except Exception as Error:
                    print(f'Error {Error}')

        elif column_selected == "#2":
            for selected_item in self.treeEmails.selection():
                item = self.treeEmails.item(selected_item)
                record = item['values']
                entryID = str(record[9])

                try:
                    if len(self.Validated_info_list) > 0:
                        filtered_df = self.Validated_info_list[self.Validated_info_list['Filename'].str.contains(entryID)]
                        if len(filtered_df) > 0:
                            var = ViewTemplate(filtered_df)
                except Exception as Error:
                    print(f'Error {Error}')

        else:
            for selected_item in self.treeEmails.selection():
                item = self.treeEmails.item(selected_item)
                record = item['values']
                entryID = str(record[9])
                self.obj_outlook.OpenEmail(entryID)
                # messagebox.showinfo(title='Information', message=entryid)

    def settings_click(self):
        settings_form = SettingsForm()

    def validate_CPIM_MasterFile(self):
        try:
            self.cpim_master_file_path = os.getcwd() + '\\MasterData\\CPIM_Raw_Data_Dump.xlsx'

            if os.path.isfile(self.cpim_master_file_path):
                CPIM_dataframe = pandas.read_excel(self.cpim_master_file_path)
                CPIM_dataframe_main = CPIM_dataframe.fillna("", inplace=False)

                for index, row in CPIM_dataframe_main.iterrows():
                    RPPD = str(row['RPPD']).strip()  # Was this account processed as RP PD
                    SIPD = str(row['SIPD']).strip()  # Does this account have SI PD information

                    if RPPD == "" or SIPD == "":
                        messagebox.showerror(title="Ryder COI Extraction Tool", message="CPIM master file is not updated (RP PD/CP PD columns are blank)\nPlease update and try again.")
                        return False
                return True
            else:
                messagebox.showerror(title="Ryder COI Extraction Tool", message=f"CPIM master file is not found at {self.cpim_master_file_path}")
                return False
        except Exception as Error:
            messagebox.showerror(title="Ryder COI Extraction Tool", message=f"Error in validate_CPIM_MasterFile\n{Error}")
            return False
