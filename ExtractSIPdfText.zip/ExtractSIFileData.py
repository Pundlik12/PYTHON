import os
import re
import cv2
import pandas as pd
import pymupdf
import pytesseract
import numpy as np
import xlsxwriter
from PIL import Image
from CommonClasses.common import Common
from ExtractSIPdfText import ExtractSIDataPdfPlumber


class ExtractSIData:
    pdfImagePath = []
    headersData = []
    detailsData = []
    si_pdf_plumber_data = []

    strShipper = ""
    strConsignee = ""
    strContainer = ""
    strSeal = ""
    strBookingReference = ""

    strNotifyAddress = ""
    strVessel = ""
    strPortOfLoading = ""
    strNrFile = ""
    strPlaceOfDelivery = ""
    strFinalDestination = ""
    strDocType = ""  # eg. Prepaid

    strHouseBL = ""
    strMarksAndNo = ""
    strPackage = ""
    strDescription = ""
    strGrossWeight = ""
    strMeasurement = ""

    def __init__(self):
        str_tesseract_binaries_path = os.getcwd() + r'\\Tesseract-OCR\\tesseract.exe'
        pytesseract.pytesseract.tesseract_cmd = str_tesseract_binaries_path
        self.obj_common = Common()
        self.obj_si_pdf_plumber = ExtractSIDataPdfPlumber()
        self.clear()

        if not os.path.exists('Processing'):
            os.makedirs('Processing')

    def clear(self):
        self.pdfImagePath = []
        self.headersData = []
        self.detailsData = []
        self.si_pdf_plumber_data = []

        self.strShipper = ""
        self.strConsignee = ""
        self.strContainer = ""
        self.strSeal = ""
        self.strBookingReference = ""

        self.strNotifyAddress = ""
        self.strVessel = ""
        self.strPortOfLoading = ""
        self.strNrFile = ""
        self.strPlaceOfDelivery = ""
        self.strFinalDestination = ""
        self.strDocType = ""  # eg. Prepaid

        self.strHouseBL = ""
        self.strMarksAndNo = ""
        self.strPackage = ""
        self.strDescription = ""
        self.strGrossWeight = ""
        self.strMeasurement = ""

        self.delete_processed_images()

    def delete_processed_images(self):
        try:
            for file in os.listdir('Processing'):
                if file.upper().endswith('.PNG'):
                    os.remove("Processing//" + file)
        except Exception as err:
            self.obj_common.write_log(f"Error in delete_processed_images function: -{str(err)}")

    def convert_pdf_to_images(self, str_pdf_file_path):
        try:
            self.clear()

            self.si_pdf_plumber_data = self.obj_si_pdf_plumber.extract_text_from_pdf(str_pdf_file_path)

            dpi = 200
            zoom = dpi / 75
            magnify = pymupdf.Matrix(zoom, zoom)

            # Open the PDF file and ensure it's properly closed
            with pymupdf.open(str_pdf_file_path) as pdf_doc:
                page_counter = 1
                for page in pdf_doc:
                    page_name = f"Processing\\SI_Page{str(page_counter)}.PNG"
                    pix = page.get_pixmap(matrix=magnify)
                    pix.save(page_name)
                    self.pdfImagePath.append(page_name)
                    page_counter += 1

            self.extract_first_page_data()
            self.extract_remaining_page_data()
            self.data_manipulation()
            self.delete_processed_images()
            self.write_to_excel(str_pdf_file_path)

        except Exception as err:
            self.obj_common.write_log(f"Error in convert_pdf_to_images function: -{str(err)}")

    def data_manipulation(self):
        try:
            # Update data in main list from pdf plumber data
            for data in self.detailsData:
                house_bl_ocr = str(data['HouseBL'])
                package_ocr = str(data['Package'])
                gross_weight_ocr = float(data['GrossWeight'])
                measurement_ocr = float(data['Measurement'])

                for data1 in self.si_pdf_plumber_data:
                    house_bl_plumber = str(data1['HouseBL'])
                    package_plumber = str(data1['Package'])
                    gross_weight_plumber = float(data1['GrossWeight'])
                    measurement_plumber = float(data1['Measurement'])

                    if house_bl_ocr == house_bl_plumber:
                        if gross_weight_ocr == gross_weight_plumber and measurement_ocr == measurement_plumber:
                            if package_plumber != "":
                                if package_plumber != package_ocr:
                                    data['Package'] = package_plumber
                            data['Package_Plumber'] = package_plumber
                            data['GrossWeight_Plumber'] = gross_weight_plumber
                            data['Measurement_Plumber'] = measurement_plumber
                            break

            # Missing data
            for data1 in self.si_pdf_plumber_data:
                is_found = False
                house_bl_plumber = str(data1['HouseBL'])
                package_plumber = str(data1['Package'])
                gross_weight_plumber = float(data1['GrossWeight'])
                measurement_plumber = float(data1['Measurement'])

                for data in self.detailsData:
                    house_bl_ocr = str(data['HouseBL'])
                    gross_weight_ocr = float(data['GrossWeight'])
                    measurement_ocr = float(data['Measurement'])

                    if house_bl_ocr == house_bl_plumber:
                        if gross_weight_ocr == gross_weight_plumber and measurement_ocr == measurement_plumber:
                            is_found = True
                            break

                if is_found is False:
                    self.detailsData.append({
                                    "HouseBL": house_bl_plumber,
                                    "MarksAndNo": "",
                                    "Package": "",
                                    "Description": "",
                                    "GrossWeight": "",
                                    "Measurement": "",
                                    "Package_Plumber": package_plumber,
                                    "GrossWeight_Plumber": gross_weight_plumber,
                                    "Measurement_Plumber": measurement_plumber
                                })
        except Exception as err:
            self.obj_common.write_log(f"Error in data_manipulation function: -{str(err)}")

    def extract_first_page_data(self):
        try:
            first_page_path = self.pdfImagePath[0]

            # Load the image
            img = cv2.imread(first_page_path)
            # Convert to grayscale
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            # Apply edge detection
            edges = cv2.Canny(gray, 50, 150)
            # Apply Hough transform
            lines = cv2.HoughLinesP(edges, 1, np.pi/180, 200, minLineLength=100, maxLineGap=10)

            # Filter horizontal lines
            horizontal_lines = []
            y_lines = []
            for line in lines:
                x1, y1, x2, y2 = line[0]
                if abs(y1 - y2) < 10 and abs(x1 - x2) > 700:   # Check if the line is horizontal
                    horizontal_lines.append(line)
                    y_lines.append(y1)

            y_lines.sort()

            line_length = len(y_lines)
            if line_length >= 2:
                lines_coordinate = []
                for counter in range(0, line_length):
                    current_value = y_lines[counter]
                    if (counter + 1) <= (line_length - 1):
                        next_value = y_lines[counter + 1]
                        if (next_value - current_value) > 20:
                            lines_coordinate.append([current_value, next_value])

                counter = 0
                for linnes in lines_coordinate:
                    counter = counter + 1
                    y1 = linnes[0]
                    y2 = linnes[1]
                    main_image = img[y1:y2, 0:img.shape[1]]

                    # Convert to grayscale
                    cropped_image = cv2.cvtColor(main_image, cv2.COLOR_BGR2GRAY)
                    # cv2.imwrite(f'Processing/cropped_image{str(counter)}.PNG', cropped_image)

                    if counter == 1:  # shipper
                        y1 = 3
                        y2 = 306
                        x1 = 1
                        x2 = 853
                        shipper_image = cropped_image[y1:y2, x1:x2]
                        pil_image = Image.fromarray(cv2.cvtColor(shipper_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        extracted_text = extracted_text.replace('\n\n', '\n').strip()
                        extracted_text = extracted_text.replace('\n', ' ').strip()
                        extracted_text = extracted_text.replace('  ', ' ').strip()
                        extracted_text = extracted_text.replace('Shipper', '').strip()
                        extracted_text = self.remove_special_characters(extracted_text)
                        self.strShipper = extracted_text.upper()
                        continue

                    if counter == 2:  # Consignee
                        y1 = 3
                        y2 = 306
                        x1 = 1
                        x2 = 853
                        consignee_image = cropped_image[y1:y2, x1:x2]
                        pil_image = Image.fromarray(cv2.cvtColor(consignee_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        extracted_text = extracted_text.replace('\n\n', '\n').strip()
                        extracted_text = extracted_text.replace('\n', ' ').strip()
                        extracted_text = extracted_text.replace('  ', ' ').strip()
                        extracted_text = extracted_text.replace('Consignee', '').strip()
                        extracted_text = self.remove_special_characters(extracted_text)
                        self.strConsignee = extracted_text.upper()

                        # Booking Ref
                        y1 = 3
                        y2 = 306
                        x1 = 850
                        x2 = 1571
                        booking_ref_image = cropped_image[y1:y2, x1:x2]
                        pil_image = Image.fromarray(cv2.cvtColor(booking_ref_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        extracted_text = extracted_text.replace('\n\n', '\n').strip()
                        extracted_text = extracted_text.replace('\n', ' ').strip()
                        extracted_text = extracted_text.replace('  ', ' ').strip()
                        extracted_text = extracted_text.replace('B/L INSTRUCTIONS Booking Ref', '').strip()
                        extracted_text = self.remove_special_characters(extracted_text)
                        self.strBookingReference = extracted_text.upper()
                        continue

                    if counter == 3:  # Notify Address
                        y1 = 3
                        y2 = 306
                        x1 = 1
                        x2 = 853
                        notify_address_image = cropped_image[y1:y2, x1:x2]
                        pil_image = Image.fromarray(cv2.cvtColor(notify_address_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        extracted_text = extracted_text.replace('\n\n', '\n').strip()
                        extracted_text = extracted_text.replace('\n', ' ').strip()
                        extracted_text = extracted_text.replace('  ', ' ').strip()
                        extracted_text = extracted_text.replace('Notify address', '').strip()
                        extracted_text = self.remove_special_characters(extracted_text)
                        if extracted_text.upper() == "SAME AS CONSIGNEE":
                            self.strNotifyAddress = self.strConsignee
                        else:
                            self.strNotifyAddress = extracted_text.upper()

                        # Container
                        y1 = 3
                        y2 = 306
                        x1 = 850
                        x2 = 1310
                        container_image = cropped_image[y1:y2, x1:x2]
                        pil_image = Image.fromarray(cv2.cvtColor(container_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        extracted_text = extracted_text.replace('\n\n', '\n').strip()
                        extracted_text = extracted_text.replace('\n', ' ').strip()
                        extracted_text = extracted_text.replace('  ', ' ').strip()
                        extracted_text = extracted_text.replace('Container', '').strip()
                        extracted_text = self.remove_special_characters(extracted_text)

                        data_array = str(extracted_text).split('  ')
                        if len(data_array) > 0:
                            extracted_text = str(data_array[0]).strip().replace(' ', '')
                            self.strContainer = extracted_text.strip().upper()
                        else:
                            self.strContainer = str(extracted_text).strip().upper()

                        # Seal
                        y1 = 3
                        y2 = 306
                        x1 = 1311
                        x2 = 1564
                        seal_image = cropped_image[y1:y2, x1:x2]
                        pil_image = Image.fromarray(cv2.cvtColor(seal_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        extracted_text = extracted_text.replace('\n\n', '\n').strip()
                        extracted_text = extracted_text.replace('\n', ' ').strip()
                        extracted_text = extracted_text.replace('  ', ' ').strip()
                        extracted_text = extracted_text.replace('Seal', '').strip()
                        self.strSeal = extracted_text.upper()
                        continue

                    if counter == 4:  # Vessel
                        y1 = 3
                        y2 = 82
                        x1 = 1
                        x2 = 444
                        vessel_image = cropped_image[y1:y2, x1:x2]
                        pil_image = Image.fromarray(cv2.cvtColor(vessel_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        extracted_text = extracted_text.replace('\n\n', '\n').strip()
                        extracted_text = extracted_text.replace('\n', ' ').strip()
                        extracted_text = extracted_text.replace('  ', ' ').strip()
                        extracted_text = extracted_text.replace('Vessel', '').strip()
                        self.strVessel = extracted_text.upper()

                        # Port Of Loading
                        y1 = 3
                        y2 = 82
                        x1 = 444
                        x2 = 851
                        port_of_loading_image = cropped_image[y1:y2, x1:x2]
                        pil_image = Image.fromarray(cv2.cvtColor(port_of_loading_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        extracted_text = extracted_text.replace('\n\n', '\n').strip()
                        extracted_text = extracted_text.replace('\n', ' ').strip()
                        extracted_text = extracted_text.replace('  ', ' ').strip()
                        extracted_text = extracted_text.replace('Port of loading', '').strip()
                        self.strPortOfLoading = extracted_text.upper()

                        # NrFile
                        y1 = 3
                        y2 = 82
                        x1 = 851
                        x2 = 1358
                        nr_file_image = cropped_image[y1:y2, x1:x2]
                        pil_image = Image.fromarray(cv2.cvtColor(nr_file_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        extracted_text = extracted_text.replace('\n\n', '\n').strip()
                        extracted_text = extracted_text.replace('\n', ' ').strip()
                        extracted_text = extracted_text.replace('  ', ' ').strip()
                        extracted_text = extracted_text.replace('NrFile', '').strip()

                        data_array = str(extracted_text).split('/')
                        if len(data_array) > 1:
                            extracted_text = str(data_array[2]).strip()
                            self.strNrFile = extracted_text.strip().upper()
                        else:
                            self.strNrFile = str(extracted_text).strip().upper()
                        continue

                    if counter == 5:  # Place Of Delivery
                        y1 = 3
                        y2 = 80
                        x1 = 4
                        x2 = 444
                        place_of_delivery_image = cropped_image[y1:y2, x1:x2]
                        pil_image = Image.fromarray(cv2.cvtColor(place_of_delivery_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        extracted_text = extracted_text.replace('\n\n', '\n').strip()
                        extracted_text = extracted_text.replace('\n', ' ').strip()
                        extracted_text = extracted_text.replace('  ', ' ').strip()
                        extracted_text = extracted_text.replace('Place of Delivery', '').strip()
                        self.strPlaceOfDelivery = extracted_text.upper()

                        # Final Destination
                        y1 = 3
                        y2 = 80
                        x1 = 444
                        x2 = 849
                        final_destination_image = cropped_image[y1:y2, x1:x2]
                        pil_image = Image.fromarray(cv2.cvtColor(final_destination_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        extracted_text = extracted_text.replace('\n\n', '\n').strip()
                        extracted_text = extracted_text.replace('\n', ' ').strip()
                        extracted_text = extracted_text.replace('  ', ' ').strip()
                        extracted_text = extracted_text.replace('Final Destination', '').strip()
                        self.strFinalDestination = extracted_text.upper()
                        continue

                self.headersData.append({
                                "Shipper": self.strShipper,
                                "Consignee": self.strConsignee,
                                "NotifyAddress": self.strNotifyAddress,
                                "Container": self.strContainer,
                                "Seal": self.strSeal,
                                "BookingReference": self.strBookingReference,
                                "Vessel": self.strVessel,
                                "PortOfLoading": self.strPortOfLoading,
                                "PlaceOfDelivery": self.strPlaceOfDelivery,
                                "FinalDestination": self.strFinalDestination,
                                "NrFile": self.strNrFile
                            })
            else:
                print("Not enough horizontal lines detected.")

        except Exception as err:
            self.obj_common.write_log(f"Error in extract_first_page_data function: -{str(err)}")

    def extract_remaining_page_data(self):
        try:
            page_counter = 0
            for imageFileName in self.pdfImagePath:
                if page_counter == 0:
                    page_counter = page_counter + 1
                    continue

                # image = cv2.imread(imageFileName, cv2.IMREAD_GRAYSCALE)
                # image = cv2.GaussianBlur(image, (3, 3), 0)
                # image = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
                # kernel = np.ones((1, 1), np.uint8)
                # image = cv2.dilate(image, kernel, iterations=1)
                # cv2.imwrite(f'Processing/main_image{counter}.PNG', image)

                image = cv2.imread(imageFileName)

                height = image.shape[0]
                image = image[:height-120, :]
                cv2.imwrite(imageFileName, image)

                # Convert to grayscale
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
                # Apply edge detection to detect lines
                edges = cv2.Canny(gray, threshold1=50, threshold2=150)
                # Use Hough Line Transform to detect horizontal lines
                lines = cv2.HoughLinesP(edges, 1, np.pi / 180, threshold=100, minLineLength=100, maxLineGap=10)

                # Extract y-coordinates of horizontal lines
                y_lines = []
                for line in lines:
                    for x1, y1, x2, y2 in line:
                        if abs(y1 - y2) < 10 and abs(x1-x2) > 500:  # This checks if the line is horizontal
                            y_lines.append(y1)
                            cv2.line(image, (x1, y1), (x2, y2), (0, 255, 0), 2)

                # Sort lines by y-coordinate
                y_lines.sort()

                line_length = len(y_lines)
                if line_length >= 2:
                    lines_coordinate = []
                    for counter in range(0, line_length):
                        current_value = y_lines[counter]
                        if (counter + 1) <= (line_length - 1):
                            next_value = y_lines[counter + 1]
                            if (next_value - current_value) > 20:
                                lines_coordinate.append([current_value, next_value])
                        else:
                            width, height = image.shape[:2]
                            end_x = width - 1
                            # end_y = height - 1
                            next_value = end_x
                            lines_coordinate.append([current_value, next_value])

                    counter = 0
                    for co_ordinates in lines_coordinate:
                        # print(f"=========Extracting data from Page No {str(counter+2)}========\n")
                        y1 = co_ordinates[0]
                        y2 = co_ordinates[1]
                        cropped_image = image[y1+5:y2-5, 0:image.shape[1]]
                        # cv2.imwrite(f'Processing/cropped_line_{str(page_counter)}_{str(counter)}.PNG', cropped_image)

                        # house_bl_image = cropped_image[:, 0:540]
                        # # cv2.imwrite(f'Processing/{str(counter)}_HBL.PNG', house_bl_image)
                        # pil_image = Image.fromarray(cv2.cvtColor(house_bl_image, cv2.COLOR_BGR2RGB))
                        # extracted_text = pytesseract.image_to_string(pil_image)
                        # extracted_text = extracted_text.replace('\n\n', '\n').strip()
                        # extracted_text = extracted_text.replace('\n', ' ').strip()
                        # extracted_text = extracted_text.replace('  ', ' ').strip()
                        # extracted_text = extracted_text.replace('House BL', '').strip()

                        # data_array = str(extracted_text).split(' ')
                        # if len(data_array) > 0:
                        #     self.strHouseBL = str(data_array[0]).strip()
                        # else:
                        #     self.strHouseBL = extracted_text

                        # extracted_text = extracted_text.replace(self.strHouseBL, '')
                        # extracted_text = self.remove_special_characters(extracted_text)
                        # self.strMarksAndNo = extracted_text.strip().upper()

                        # if 'DOCUMENT ISSUED BY' in self.strMarksAndNo:
                        #     index = self.strMarksAndNo.find('DOCUMENT ISSUED BY')
                        #     self.strMarksAndNo = self.strMarksAndNo[0:index-1]

                        # package_image = cropped_image[:, 510:750]
                        # # cv2.imwrite(f'Processing/{str(page_counter)}_{str(counter)}_PKG.PNG', package_image)
                        # pil_image = Image.fromarray(cv2.cvtColor(package_image, cv2.COLOR_BGR2RGB))
                        # extracted_text = pytesseract.image_to_string(pil_image)
                        # extracted_text = extracted_text.replace('\n\n', '\n').strip()
                        # extracted_text = extracted_text.replace('\n', ' ').strip()
                        # extracted_text = extracted_text.replace('  ', ' ').strip()
                        # extracted_text = self.remove_special_characters(extracted_text)
                        # extracted_text = extracted_text.replace(' STC', '').strip()
                        # self.strPackage = extracted_text

                        # description_image = cropped_image[:, 760:1200]
                        # # cv2.imwrite(f'Processing/{str(counter)}_DESC.PNG', description_image)
                        # pil_image = Image.fromarray(cv2.cvtColor(description_image, cv2.COLOR_BGR2RGB))
                        # extracted_text = pytesseract.image_to_string(pil_image)
                        # extracted_text = extracted_text.replace('\n\n', '\n').strip()
                        # extracted_text = extracted_text.replace('\n', ' ').strip()
                        # extracted_text = extracted_text.replace('  ', ' ').strip()
                        # extracted_text = self.remove_special_characters(extracted_text)
                        # self.strDescription = extracted_text.upper()

                        # gross_weight_image = cropped_image[:, 1210:1400]
                        # # cv2.imwrite(f'Processing/{str(counter)}_GrossWeight.PNG', gross_weight_image)
                        # pil_image = Image.fromarray(cv2.cvtColor(gross_weight_image, cv2.COLOR_BGR2RGB))
                        # extracted_text = pytesseract.image_to_string(pil_image)
                        # extracted_text = extracted_text.replace('\n\n', '\n').strip()
                        # extracted_text = extracted_text.replace('\n', ' ').strip()
                        # extracted_text = extracted_text.replace('  ', ' ').strip()
                        # extracted_text = extracted_text.replace(',', '').strip()
                        # extracted_text = self.extract_decimals(extracted_text)
                        # self.strGrossWeight = extracted_text

                        # measurement_image = cropped_image[:, 1410:]
                        # cv2.imwrite(f'Processing/{str(counter)}_Measurement.PNG', measurement_image)
                        # pil_image = Image.fromarray(cv2.cvtColor(measurement_image, cv2.COLOR_BGR2RGB))
                        # extracted_text = pytesseract.image_to_string(pil_image)
                        # extracted_text = extracted_text.replace('\n\n', '\n').strip()
                        # extracted_text = extracted_text.replace('\n', ' ').strip()
                        # extracted_text = extracted_text.replace('  ', ' ').strip()
                        # extracted_text = extracted_text.replace(',', '').strip()
                        # extracted_text = self.extract_decimals(extracted_text)
                        # self.strMeasurement = extracted_text

                        # Start Adding logic to further split image to check multiple records of same HBL number -> 10-Mar-2025
                        house_bl_image = cropped_image[:, 0:540]
                        cv2.imwrite(f'Processing/HBL_SI.PNG', house_bl_image)

                        house_bl_image = cropped_image[:50, 0:540]
                        pil_image = Image.fromarray(cv2.cvtColor(house_bl_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        extracted_text = extracted_text.replace('\n\n', '\n').strip()
                        extracted_text = extracted_text.replace('\n', ' ').strip()
                        extracted_text = extracted_text.replace('  ', ' ').strip()
                        extracted_text = extracted_text.replace('House BL', '').strip()
                        data_array = str(extracted_text).split(' ')

                        if len(data_array) > 0:
                            self.strHouseBL = str(data_array[0]).strip()
                        else:
                            self.strHouseBL = extracted_text

                        if 'TOTAL' in self.strHouseBL:
                            continue

                        package_image = cropped_image[:, 510:750]
                        cv2.imwrite(f'Processing/PKG_SI.PNG', package_image)

                        description_image = cropped_image[:, 760:1200]
                        cv2.imwrite(f'Processing/DESC_SI.PNG', description_image)

                        gross_weight_image = cropped_image[:, 1210:1400]
                        cv2.imwrite(f'Processing/GrossWeight_SI.PNG', gross_weight_image)

                        measurement_image = cropped_image[:, 1410:]
                        cv2.imwrite(f'Processing/Measurement_SI.PNG', measurement_image)

                        image_house_bls = Image.open(f'Processing/Measurement_SI.PNG')
                        data = pytesseract.image_to_data(image_house_bls, output_type='dict')
                        df = pd.DataFrame(data)
                        df_filtered = df.loc[lambda x: x['level'] == 5]

                        top_values = [55]
                        for index, row in df_filtered.iterrows():
                            str_text = str(row['text'])
                            # print(str_text)
                            if str_text != "":
                                if self.is_numeric(str_text):
                                    top_values.append(str(row['top']))

                        start = 0
                        length = len(top_values)

                        for i in range(start, start + length):
                            y1 = int(top_values[i])

                            if i == length-1:
                                y2 = y1 + 500
                            else:
                                y2 = int(top_values[i+1])

                            self.strMarksAndNo = ""
                            self.strPackage = ""
                            self.strDescription = ""
                            self.strMeasurement = ""
                            self.strGrossWeight = ""

                            cv2image = cv2.imread('Processing/HBL_SI.PNG')
                            cropped_image = cv2image[y1-4:y2, :]
                            # cv2.imwrite(f'Processing/MarksAndNos11.PNG', cropped_image)
                            pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
                            extracted_text = pytesseract.image_to_string(pil_image)
                            extracted_text = extracted_text.replace('\n\n', '\n').strip()
                            extracted_text = extracted_text.replace('\n', ' ').strip()
                            extracted_text = extracted_text.replace('  ', ' ').strip()
                            extracted_text = str(extracted_text).upper()
                            self.strMarksAndNo = extracted_text.strip()
                            self.strMarksAndNo = self.remove_special_characters(self.strMarksAndNo)

                            cv2image = cv2.imread('Processing/PKG_SI.PNG')
                            cropped_image = cv2image[y1-4:y2, :]
                            # cv2.imwrite(f'Processing/Package11.PNG', cropped_image)
                            pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
                            extracted_text = pytesseract.image_to_string(pil_image)
                            extracted_text = extracted_text.replace('\n\n', '\n').strip()
                            extracted_text = extracted_text.replace('\n', ' ').strip()
                            extracted_text = extracted_text.replace('  ', ' ').strip()
                            extracted_text = self.remove_special_characters(extracted_text)
                            extracted_text = extracted_text.replace(' ', '').strip()
                            extracted_text = extracted_text.replace('STC', '').strip()
                            self.strPackage = extracted_text.strip().upper()

                            if self.strPackage == "ICARTON" or self.strPackage == "CARTON":
                                self.strPackage = "1CARTON"
                            elif self.strPackage == "ICTN" or self.strPackage == "CTN":
                                self.strPackage = "1CTN"
                            elif self.strPackage == "IPACKAGE" or self.strPackage == "PACKAGE":
                                self.strPackage = "1PACKAGE"
                            elif self.strPackage == "IBOX" or self.strPackage == "BOX":
                                self.strPackage = "1BOX"
                            elif self.strPackage == "IWOODEN CASE" or self.strPackage == "WOODEN CASE":
                                self.strPackage = "1WOODEN CASE"
                            elif self.strPackage == "ICASE" or self.strPackage == "CASE":
                                self.strPackage = "1CASE"
                            elif self.strPackage == "IPALLET" or self.strPackage == "PALLET":
                                self.strPackage = "1PALLET"
                            elif self.strPackage == "IPIECE" or self.strPackage == "PIECE":
                                self.strPackage = "1PIECE"
                            elif self.strPackage == "ICRATE" or self.strPackage == "CRATE":
                                self.strPackage = "1CRATE"
                            elif self.strPackage == "IDRUM" or self.strPackage == "DRUM":
                                self.strPackage = "1DRUM"
                            elif self.strPackage == "IROLL" or self.strPackage == "ROLL":
                                self.strPackage = "1ROLL"
                            elif self.strPackage == "ISKID" or self.strPackage == "SKID":
                                self.strPackage = "1SKID"

                            if 'OCARTONS' in self.strPackage:
                                self.strPackage = self.strPackage.replace("OCARTONS", "0CARTONS")
                            elif 'SCARTONS' in self.strPackage:
                                self.strPackage = self.strPackage.replace("SCARTONS", "5CARTONS")
                            elif 'OCTNS' in self.strPackage:
                                self.strPackage = self.strPackage.replace("OCTNS", "0CTNS")
                            elif 'SCTNS' in self.strPackage:
                                self.strPackage = self.strPackage.replace("SCTNS", "5CTNS")
                            elif "OPACKAGES" in self.strPackage:
                                self.strPackage = self.strPackage.replace("OPACKAGES", "0PACKAGES")
                            elif "SPACKAGES" in self.strPackage:
                                self.strPackage = self.strPackage.replace("SPACKAGES", "5PACKAGES")
                            elif "OBOXS" in self.strPackage:
                                self.strPackage = self.strPackage.replace("OBOXS", "0BOXS")
                            elif "SBOXS" in self.strPackage:
                                self.strPackage = self.strPackage.replace("SBOXS", "5BOXS")
                            elif "OWOODEN CASES" in self.strPackage:
                                self.strPackage = self.strPackage.replace("OWOODEN CASES", "0WOODEN CASES")
                            elif "SWOODEN CASES" in self.strPackage:
                                self.strPackage = self.strPackage.replace("SWOODEN CASES", "5WOODEN CASES")
                            elif "OCASES" in self.strPackage:
                                self.strPackage = self.strPackage.replace("OCASES", "0CASES")
                            elif "SCASES" in self.strPackage:
                                self.strPackage = self.strPackage.replace("SCASES", "5CASES")
                            elif "OPALLETS" in self.strPackage:
                                self.strPackage = self.strPackage.replace("OPALLETS", "0PALLETS")
                            elif "SPALLETS" in self.strPackage:
                                self.strPackage = self.strPackage.replace("SPALLETS", "5PALLETS")
                            elif "OPIECES" in self.strPackage:
                                self.strPackage = self.strPackage.replace("OPIECES", "0PIECES")
                            elif "SPIECES" in self.strPackage:
                                self.strPackage = self.strPackage.replace("SPIECES", "5PIECES")
                            elif "OCRATES" in self.strPackage:
                                self.strPackage = self.strPackage.replace("OCRATES", "0CRATES")
                            elif "SCRATES" in self.strPackage:
                                self.strPackage = self.strPackage.replace("SCRATES", "5CRATES")
                            elif "ODRUMS" in self.strPackage:
                                self.strPackage = self.strPackage.replace("ODRUMS", "0DRUMS")
                            elif "SDRUMS" in self.strPackage:
                                self.strPackage = self.strPackage.replace("SDRUMS", "5DRUMS")
                            elif "OROLLS" in self.strPackage:
                                self.strPackage = self.strPackage.replace("OROLLS", "0ROLLS")
                            elif "SROLLS" in self.strPackage:
                                self.strPackage = self.strPackage.replace("SROLLS", "5ROLLS")
                            elif "OSKIDS" in self.strPackage:
                                self.strPackage = self.strPackage.replace("OSKIDS", "0SKIDS")
                            elif "SSKIDS" in self.strPackage:
                                self.strPackage = self.strPackage.replace("SSKIDS", "5SKIDS")

                            cv2image = cv2.imread('Processing/DESC_SI.PNG')
                            cropped_image = cv2image[y1-4:y2, :]
                            # cv2.imwrite(f'Processing/Description11.PNG', cropped_image)
                            pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
                            extracted_text = pytesseract.image_to_string(pil_image)
                            extracted_text = extracted_text.replace('\n\n', '\n').strip()
                            extracted_text = extracted_text.replace('\n', ' ').strip()
                            extracted_text = extracted_text.replace('  ', ' ').strip()
                            extracted_text = self.remove_special_characters(extracted_text)
                            self.strDescription = extracted_text.strip().upper()

                            cv2image = cv2.imread('Processing/GrossWeight_SI.PNG')
                            cropped_image = cv2image[y1-4:y2, :]
                            # cv2.imwrite(f'Processing/GrossWeight11.PNG', cropped_image)
                            pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
                            extracted_text = pytesseract.image_to_string(pil_image)
                            extracted_text = extracted_text.replace('\n\n', '\n').strip()
                            extracted_text = extracted_text.replace('\n', ' ').strip()
                            extracted_text = extracted_text.replace('  ', ' ').strip()
                            extracted_text = extracted_text.replace('KGS', ' ').strip()
                            extracted_text = extracted_text.replace(',', '').strip()
                            self.strGrossWeight = extracted_text.strip().replace(' ', '')

                            cv2image = cv2.imread('Processing/Measurement_SI.PNG')
                            cropped_image = cv2image[y1-4:y2, :]
                            # cv2.imwrite(f'Processing/Measurement11.PNG', cropped_image)
                            pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
                            extracted_text = pytesseract.image_to_string(pil_image)
                            extracted_text = extracted_text.replace('\n\n', '\n').strip()
                            extracted_text = extracted_text.replace('\n', ' ').strip()
                            extracted_text = extracted_text.replace('  ', ' ').strip()
                            extracted_text = extracted_text.replace('CBM', ' ').strip()
                            extracted_text = extracted_text.replace(',', '').strip()
                            self.strMeasurement = extracted_text.strip().replace(' ', '')

                            if self.strHouseBL != "" and self.strMarksAndNo != "" and self.strPackage != "" and self.strDescription != "" and self.strGrossWeight != "" and self.strMeasurement:
                                if self.strHouseBL != "TOTAL" and self.strHouseBL != "Document":
                                    self.detailsData.append({
                                        "HouseBL": self.strHouseBL,
                                        "MarksAndNo": self.strMarksAndNo,
                                        "Package": self.strPackage,
                                        "Description": self.strDescription,
                                        "GrossWeight": float(self.strGrossWeight),
                                        "Measurement": float(self.strMeasurement),
                                        "Package_Plumber": "",
                                        "GrossWeight_Plumber": "",
                                        "Measurement_Plumber": ""
                                    })

                        # End Adding logic to further split image to check multiple records of same HBL number -> 10-Mar-2025
                        os.remove("Processing//HBL_SI.PNG")
                        os.remove("Processing//PKG_SI.PNG")
                        os.remove("Processing//DESC_SI.PNG")
                        os.remove("Processing//GrossWeight_SI.PNG")
                        os.remove("Processing//Measurement_SI.PNG")

                        counter = counter + 1
                        self.strHouseBL = ""
                        self.strMarksAndNo = ""
                        self.strPackage = ""
                        self.strDescription = ""
                        self.strGrossWeight = ""
                        self.strMeasurement = ""
                else:
                    print("Not enough horizontal lines detected.")

                page_counter = page_counter + 1
                os.remove(imageFileName)
        except Exception as err:
            self.obj_common.write_log(f"Error in extract_remaining_page_data function: -{str(err)}")

    def is_numeric(self, value):
        try:
            float(value)
            return True
        except ValueError:
            return False

    def remove_special_characters(self, text):
        try:
            pattern = r'[^a-zA-Z0-9\s]'
            # Replace special characters with an empty string
            cleaned_text = re.sub(pattern, '', text)
            return cleaned_text
        except Exception as err:
            self.obj_common.write_log(f"Error in remove_special_characters function: -{str(err)}")
            return text

    def extract_decimals(self, text):
        try:
            pattern = r'\d+\.\d+'
            decimals = re.findall(pattern, text)
            if len(decimals) > 0:
                return str(decimals[0]).strip()
            else:
                return text
        except Exception as err:
            self.obj_common.write_log(f"Error in extract_decimals function: -{str(err)}")
            return text

    def write_to_excel(self, str_pdf_file_path):
        try:
            workbook = xlsxwriter.Workbook(str_pdf_file_path.replace('.pdf', '.xlsx'))
            worksheet = workbook.add_worksheet()
            worksheet.name = "Header Data"

            # worksheet.set_column('A:A', 20)
            if len(self.headersData) > 0:
                worksheet.write('A1', 'Shipper')
                worksheet.write('B1', 'Consignee')
                worksheet.write('C1', 'NotifyAddress')
                worksheet.write('D1', 'Vessel')
                worksheet.write('E1', 'PortOfLoading')
                worksheet.write('F1', 'FinalDestination')
                worksheet.write('G1', 'PlaceOfDelivery')
                worksheet.write('H1', 'BookingReference')
                worksheet.write('I1', 'NrFile')
                worksheet.write('J1', 'Container')
                worksheet.write('K1', 'Seal')

                counter = 2
                for data in self.headersData:
                    worksheet.write('A' + str(counter), data['Shipper'])
                    worksheet.write('B' + str(counter), data["Consignee"])
                    worksheet.write('C' + str(counter), data['NotifyAddress'])
                    worksheet.write('D' + str(counter), data['Vessel'])
                    worksheet.write('E' + str(counter), data['PortOfLoading'])
                    worksheet.write('F' + str(counter), data['FinalDestination'])
                    worksheet.write('G' + str(counter), data['PlaceOfDelivery'])
                    worksheet.write('H' + str(counter), data['BookingReference'])
                    worksheet.write('I' + str(counter), data['NrFile'])
                    worksheet.write('J' + str(counter), data['Container'])
                    worksheet.write('K' + str(counter), data['Seal'])

            if len(self.detailsData) > 0:
                worksheet = workbook.add_worksheet()
                worksheet.name = "Details Data"

                worksheet.write('A1', 'HouseBL')
                worksheet.write('B1', 'MarksAndNo')
                worksheet.write('C1', 'Package')
                worksheet.write('D1', 'Description')
                worksheet.write('E1', 'GrossWeight')
                worksheet.write('F1', 'Measurement')
                worksheet.write('G1', 'Package_Plumber')
                worksheet.write('H1', 'GrossWeight_Plumber')
                worksheet.write('I1', 'Measurement_Plumber')

                counter = 2
                for data in self.detailsData:
                    worksheet.write('A' + str(counter), data['HouseBL'])
                    worksheet.write('B' + str(counter), data['MarksAndNo'])
                    worksheet.write('C' + str(counter), data['Package'])
                    worksheet.write('D' + str(counter), data['Description'])
                    worksheet.write('E' + str(counter), data['GrossWeight'])
                    worksheet.write('F' + str(counter), data['Measurement'])
                    worksheet.write('G' + str(counter), data['Package_Plumber'])
                    worksheet.write('H' + str(counter), data['GrossWeight_Plumber'])
                    worksheet.write('I' + str(counter), data['Measurement_Plumber'])
                    counter = counter + 1

            workbook.close()
        except Exception as err:
            self.obj_common.write_log(f"Error in write_to_excel function: -{str(err)}")
