import pdfplumber
from CommonClasses.common import Common


class ExtractSIDataPdfPlumber:
    text = ''
    HblNumber = ''
    MarksAndNo = ''
    Package = ''
    Description = ''
    GrossWeight = ''
    Measurement = ''
    details_data = []
    obj_common = None

    def __init__(self):
        self.obj_common = Common()

    def initiate_variables(self):
        self.text = ''
        self.HblNumber = ''
        self.MarksAndNo = ''
        self.Package = ''
        self.Description = ''
        self.GrossWeight = ''
        self.Measurement = ''
        self.details_data = []

    def extract_text_from_pdf(self, pdf_path):
        try:
            self.initiate_variables()

            with pdfplumber.open(pdf_path) as pdf:
                for page in pdf.pages:
                    self.text = self.text + page.extract_text() + '\n'

        except Exception as Err:
            self.text = ""
            self.obj_common.write_log(f'Error in extract_text_from_pdf function of SI: - {str(Err)}')

        if self.text != "":
            return self.extract_line_details()
        else:
            return ""

    def extract_line_details(self):
        try:
            line_data = self.text.split('\n')
            # print(self.text)

            total_line_count = len(line_data) - 1
            for x in range(total_line_count):
                self.HblNumber = ""
                self.MarksAndNo = ""
                self.Package = ""
                self.Description = ""
                self.GrossWeight = ""
                self.Measurement = ""

                text = line_data[x]
                if 'House BL'.lower() in text.lower():
                    self.HblNumber = text.replace('House BL', '').strip()
                    text = line_data[x + 1]
                    data_array = text.split(' ')
                    self.GrossWeight = str(data_array[len(data_array)-2]).replace(',', '')
                    self.Measurement = str(data_array[len(data_array)-1]).replace(',', '')

                    if ' STC ' in text:
                        array_package = text.split(' STC ')
                        data_array1 = str(array_package[0]).split(' ')
                        self.Package = data_array1[len(data_array1)-1]

                    if self.is_numeric(self.GrossWeight) and self.is_numeric(self.Measurement):
                        self.details_data.append(
                                        {"HouseBL": self.HblNumber,
                                         "MarksAndNo": "",
                                         "Package": self.Package,
                                         "Description": "",
                                         "GrossWeight": float(self.GrossWeight),
                                         "Measurement": float(self.Measurement)})
        except Exception as Err:
            self.obj_common.write_log(f'Error in extract_line_details function of SI: - {str(Err)}')

        return self.details_data

    def is_numeric(self, value):
        try:
            check_value = value.replace(',', '')
            float(check_value)
            return True
        except ValueError:
            return False
