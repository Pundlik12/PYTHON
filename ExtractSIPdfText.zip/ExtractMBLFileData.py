import os
import re
import cv2
import numpy as np
import pymupdf
import pytesseract
import pandas as pd
from PIL import Image
import xlsxwriter
from CommonClasses.common import Common
from ExtractMBLPdfText import ExtractMBLDataPdfPlumber


class ExtractMBLData:
    pdfImagePath = []
    headersData = []
    detailsData = []
    mbl_pdf_plumber_header_data = []
    mbl_pdf_plumber_details_data = []

    strShipper = ""
    strConsignee = ""
    strNotifyAddress = ""
    strVessel = ""
    strPortOfLoading = ""
    strPortOfDischarge = ""
    strPlaceOfDelivery = ""
    strBookingNo = ""
    strSeaWayBillNo = ""
    strExportReference = ""
    strContainer = ""
    strSeal = ""

    strHblNumber = ""
    strMarksAndNo = ""
    strPackage = ""
    strDescription = ""
    strGrossWeight = ""
    strMeasurement = ""

    def __init__(self):
        str_tesseract_binaries_path = os.getcwd() + r'\\Tesseract-OCR\\tesseract.exe'
        pytesseract.pytesseract.tesseract_cmd = str_tesseract_binaries_path
        self.clear()
        self.obj_common = Common()
        self.obj_mbl_pdf_plumber = ExtractMBLDataPdfPlumber()

        if not os.path.exists('Processing'):
            os.makedirs('Processing')

    def clear(self):
        self.pdfImagePath = []
        self.headersData = []
        self.detailsData = []
        self.mbl_pdf_plumber_header_data = []
        self.mbl_pdf_plumber_details_data = []

        self.strShipper = ""
        self.strConsignee = ""
        self.strNotifyAddress = ""
        self.strVessel = ""
        self.strPortOfLoading = ""
        self.strPortOfDischarge = ""
        self.strPlaceOfDelivery = ""
        self.strBookingNo = ""
        self.strSeaWayBillNo = ""
        self.strExportReference = ""
        self.strContainer = ""
        self.strSeal = ""

        self.strHblNumber = ""
        self.strMarksAndNo = ""
        self.strPackage = ""
        self.strDescription = ""
        self.strGrossWeight = ""
        self.strMeasurement = ""

        self.delete_processed_images()

    def delete_processed_images(self):
        try:
            for file in os.listdir('Processing'):
                if file.upper().endswith('.PNG'):
                    os.remove("Processing//" + file)
        except Exception as err:
            self.obj_common.write_log(f"Error in delete_processed_images function: -{str(err)}")

    def convert_pdf_to_images(self, str_pdf_file_path):
        try:
            self.clear()
            self.mbl_pdf_plumber_header_data, self.mbl_pdf_plumber_details_data = self.obj_mbl_pdf_plumber.extract_text_from_pdf(str_pdf_file_path)

            dpi = 200
            zoom = dpi / 75
            magnify = pymupdf.Matrix(zoom, zoom)

            # Open the PDF file and ensure it's properly closed
            with pymupdf.open(str_pdf_file_path) as pdf_doc:
                page_counter = 1
                for page in pdf_doc:
                    page_name = f"Processing\\MBL_Page_{str(page_counter)}.PNG"
                    pix = page.get_pixmap(matrix=magnify)
                    pix.save(page_name)
                    self.pdfImagePath.append(page_name)
                    page_counter += 1

            self.extract_first_page_header_data()
            self.extract_first_page_details_data()
            self.extract_other_page_data()
            self.data_manipulation()
            self.delete_processed_images()
            self.write_to_excel(str_pdf_file_path)
        except Exception as err:
            self.obj_common.write_log(f"Error in convert_pdf_to_images function: -{str(err)}")

    def data_manipulation(self):
        try:
            # Update data in main list from pdf plumber data
            for data in self.detailsData:
                house_bl_ocr = str(data['HouseBL'])
                package_ocr = str(data['Package'])
                gross_weight_ocr = float(data['GrossWeight'])
                measurement_ocr = float(data['Measurement'])

                for data1 in self.mbl_pdf_plumber_details_data:
                    house_bl_plumber = str(data1['HouseBL'])
                    package_plumber = str(data1['Package'])
                    gross_weight_plumber = float(data1['GrossWeight'])
                    measurement_plumber = float(data1['Measurement'])

                    if house_bl_ocr == house_bl_plumber:
                        if gross_weight_ocr == gross_weight_plumber and measurement_ocr == measurement_plumber:
                            if package_plumber != "":
                                if package_plumber != package_ocr:
                                    data['Package'] = package_plumber
                            data['Package_Plumber'] = package_plumber
                            data['GrossWeight_Plumber'] = gross_weight_plumber
                            data['Measurement_Plumber'] = measurement_plumber
                            break

            # Missing data
            for data1 in self.mbl_pdf_plumber_details_data:
                is_found = False
                house_bl_plumber = str(data1['HouseBL'])
                marks_and_no_plumber = str(data1['MarksAndNo'])
                package_plumber = str(data1['Package'])
                description_plumber = str(data1['Description'])
                gross_weight_plumber = float(data1['GrossWeight'])
                measurement_plumber = float(data1['Measurement'])

                for data in self.detailsData:
                    house_bl_ocr = str(data['HouseBL'])
                    gross_weight_ocr = float(data['GrossWeight'])
                    measurement_ocr = float(data['Measurement'])

                    if house_bl_ocr == house_bl_plumber:
                        if gross_weight_ocr == gross_weight_plumber and measurement_ocr == measurement_plumber:
                            is_found = True
                            break

                if is_found is False:
                    self.detailsData.append({
                                    "HouseBL": house_bl_plumber,
                                    "MarksAndNo": "",
                                    "Package": package_plumber,
                                    "Description": "",
                                    "GrossWeight": gross_weight_plumber,
                                    "Measurement": measurement_plumber,
                                    "Package_Plumber": package_plumber,
                                    "GrossWeight_Plumber": gross_weight_plumber,
                                    "Measurement_Plumber": measurement_plumber
                                })
        except Exception as err:
            self.obj_common.write_log(f"Error in data_manipulation function: -{str(err)}")

    def extract_first_page_header_data(self):
        try:
            first_page_path = self.pdfImagePath[0]

            # main_image = cv2.imread(first_page_path, cv2.IMREAD_GRAYSCALE)
            # image = cv2.GaussianBlur(main_image, (3, 3), 0)
            # image = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
            # kernel = np.ones((1, 1), np.uint8)
            # image = cv2.dilate(image, kernel, iterations=1)

            main_image = cv2.imread(first_page_path)
            image = cv2.cvtColor(main_image, cv2.COLOR_BGR2GRAY)

            y1 = 157
            y2 = 345
            x1 = 74
            x2 = 907
            cropped_image = image[y1:y2, x1:x2]
            # cv2.imwrite(f'Processing/ShipperMBL.PNG', cropped_image)
            pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
            extracted_text = pytesseract.image_to_string(pil_image)
            extracted_text = extracted_text.replace('\n\n', '\n').strip()
            extracted_text = extracted_text.replace('\n', ' ').strip()
            extracted_text = extracted_text.replace('  ', ' ').strip()
            extracted_text = extracted_text.replace('SHIPPER/EXPORTER,', '').strip()
            extracted_text = self.remove_special_characters(extracted_text)
            self.strShipper = extracted_text.strip().upper()

            y1 = 345
            y2 = 523
            x1 = 74
            x2 = 907
            cropped_image = image[y1:y2, x1:x2]
            # cv2.imwrite(f'Processing/ConsigneeMBL.PNG', cropped_image)
            pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
            extracted_text = pytesseract.image_to_string(pil_image)
            extracted_text = extracted_text.replace('\n\n', '\n').strip()
            extracted_text = extracted_text.replace('\n', ' ').strip()
            extracted_text = extracted_text.replace('  ', ' ').strip()
            extracted_text = extracted_text.replace('CONSIGNEE', '').strip()
            extracted_text = self.remove_special_characters(extracted_text)
            self.strConsignee = extracted_text.strip().upper()

            y1 = 523
            y2 = 707
            x1 = 74
            x2 = 907
            cropped_image = image[y1:y2, x1:x2]
            # cv2.imwrite(f'Processing/NotifyAddressMBL.PNG', cropped_image)
            pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
            extracted_text = pytesseract.image_to_string(pil_image)
            extracted_text = extracted_text.replace('\n\n', '\n').strip()
            extracted_text = extracted_text.replace('\n', ' ').strip()
            extracted_text = extracted_text.replace('  ', ' ').strip()
            extracted_text = extracted_text.replace('NOTIFY PARTY (Itis agreed that no responsibility shall be attached to the Carrier or its Agents for failure to notify)', '').strip()
            extracted_text = self.remove_special_characters(extracted_text)
            self.strNotifyAddress = extracted_text.strip().upper()

            y1 = 760
            y2 = 832
            x1 = 74
            x2 = 907
            cropped_image = image[y1:y2, x1:x2]
            # cv2.imwrite(f'Processing/VesselMBL.PNG', cropped_image)
            pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
            extracted_text = pytesseract.image_to_string(pil_image)
            extracted_text = extracted_text.replace('\n\n', '\n').strip()
            extracted_text = extracted_text.replace('\n', ' ').strip()
            extracted_text = extracted_text.replace('  ', ' ').strip()
            extracted_text = extracted_text.replace('OCEAN VESSEL VOYAGE NO. FLAG', '').strip()
            extracted_text = self.remove_special_characters(extracted_text)
            self.strVessel = extracted_text.strip().upper()

            if 'PORT OF LOADING' in self.strVessel.upper():
                index = self.strVessel.find('PORT OF LOADING')
                self.strVessel = self.strVessel[0:index-1]

            y1 = 760
            y2 = 832
            x1 = 492
            x2 = 907
            cropped_image = image[y1:y2, x1:x2]
            # cv2.imwrite(f'Processing/PortOfLoadingMBL.PNG', cropped_image)
            pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
            extracted_text = pytesseract.image_to_string(pil_image)
            extracted_text = extracted_text.replace('\n\n', '\n').strip()
            extracted_text = extracted_text.replace('\n', ' ').strip()
            extracted_text = extracted_text.replace('  ', ' ').strip()
            extracted_text = extracted_text.replace('PORT OF LOADING', '').strip()
            extracted_text = self.remove_special_characters(extracted_text)
            self.strPortOfLoading = extracted_text.strip().upper()

            y1 = 832
            y2 = 893
            x1 = 75
            x2 = 490
            cropped_image = image[y1:y2, x1:x2]
            # cv2.imwrite(f'Processing/PortOfDischargeMBL.PNG', cropped_image)
            pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
            extracted_text = pytesseract.image_to_string(pil_image)
            extracted_text = extracted_text.replace('\n\n', '\n').strip()
            extracted_text = extracted_text.replace('\n', ' ').strip()
            extracted_text = extracted_text.replace('  ', ' ').strip()
            extracted_text = extracted_text.replace('PORT OF DISCHARGE', '').strip()
            extracted_text = self.remove_special_characters(extracted_text)
            self.strPortOfDischarge = extracted_text.strip().upper()

            y1 = 829
            y2 = 893
            x1 = 491
            x2 = 907
            cropped_image = image[y1:y2, x1:x2]
            # cv2.imwrite(f'Processing/PlaceOfDeliveryMBL.PNG', cropped_image)
            pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
            extracted_text = pytesseract.image_to_string(pil_image)
            extracted_text = extracted_text.replace('\n\n', '\n').strip()
            extracted_text = extracted_text.replace('\n', ' ').strip()
            extracted_text = extracted_text.replace('  ', ' ').strip()
            extracted_text = extracted_text.replace('PLACE OF DELIVERY', '').strip()
            extracted_text = self.remove_special_characters(extracted_text)
            self.strPlaceOfDelivery = extracted_text.strip().upper()

            y1 = 157
            y2 = 215
            x1 = 906
            x2 = 1239
            cropped_image = image[y1:y2, x1:x2]
            # cv2.imwrite(f'Processing/BookingNoMBL.PNG', cropped_image)
            pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
            extracted_text = pytesseract.image_to_string(pil_image)
            extracted_text = extracted_text.replace('\n\n', '\n').strip()
            extracted_text = extracted_text.replace('\n', ' ').strip()
            extracted_text = extracted_text.replace('  ', ' ').strip()
            extracted_text = extracted_text.replace("EXPORT REFERENCES(for the Merchant's and/or Carrier's reference only. See back clause 8. (4).)", '').strip()
            extracted_text = self.remove_special_characters(extracted_text)
            self.strBookingNo = extracted_text.strip().upper()

            y1 = 157
            y2 = 215
            x1 = 1239
            x2 = 1549
            cropped_image = image[y1:y2, x1:x2]
            # cv2.imwrite(f'Processing/SeaWayBillNoMBL.PNG', cropped_image)
            pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
            extracted_text = pytesseract.image_to_string(pil_image)
            extracted_text = extracted_text.replace('\n\n', '\n').strip()
            extracted_text = extracted_text.replace('\n', ' ').strip()
            extracted_text = extracted_text.replace('  ', ' ').strip()
            extracted_text = extracted_text.replace('SEA WAYBILL NO', '').strip()
            extracted_text = self.remove_special_characters(extracted_text)
            self.strSeaWayBillNo = extracted_text.strip().upper()

            y1 = 213
            y2 = 348
            x1 = 907
            x2 = 1549
            cropped_image = image[y1:y2, x1:x2]
            # cv2.imwrite(f'Processing/ExportReferenceMBL.PNG', cropped_image)
            pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
            extracted_text = pytesseract.image_to_string(pil_image)
            extracted_text = extracted_text.replace('\n\n', '\n').strip()
            extracted_text = extracted_text.replace('\n', ' ').strip()
            extracted_text = extracted_text.replace('  ', ' ').strip()
            extracted_text = extracted_text.replace("EXPORT REFERENCES(for the Merchant's and/or Carrier's reference only. See back clause 8. (4).)", '').strip()
            extracted_text = self.remove_special_characters(extracted_text)
            self.strExportReference = extracted_text.strip().upper()

            y1 = 964
            y2 = 1007
            x1 = 67
            x2 = 1553
            cropped_image = image[y1:y2, x1:x2]
            # cv2.imwrite(f'Processing/ContainerMBL.PNG', cropped_image)
            pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
            extracted_text = pytesseract.image_to_string(pil_image)
            extracted_text = extracted_text.replace('\n\n', '\n').strip()
            extracted_text = extracted_text.replace('\n', ' ').strip()
            extracted_text = extracted_text.replace('  ', ' ').strip()
            extracted_text = self.remove_special_characters(extracted_text)
            extracted_text = extracted_text.replace('  ', ' ').strip()

            data_array = str(extracted_text).split(' ')
            if len(data_array) > 0:
                self.strContainer = str(data_array[0]).strip()
                self.strSeal = str(data_array[1]).strip()
            else:
                self.strContainer = str(extracted_text).strip()
                self.strSeal = str(extracted_text).strip()

            self.headersData.append({
                            "Shipper": self.strShipper,
                            "Consignee": self.strConsignee,
                            "NotifyAddress": self.strNotifyAddress,
                            "Vessel": self.strVessel,
                            "PortOfLoading": self.strPortOfLoading,
                            "PortOfDischarge": self.strPortOfDischarge,
                            "PlaceOfDelivery": self.strPlaceOfDelivery,
                            "BookingNo": self.strBookingNo,
                            "SeaWayBillNo": self.strSeaWayBillNo,
                            "ExportReference": self.strExportReference,
                            "Container": self.strContainer,
                            "Seal": self.strSeal
                        })
        except Exception as err:
            self.obj_common.write_log(f"Error in extract_first_page_header_data function: -{str(err)}")

    def extract_first_page_details_data(self):
        try:
            first_page_path = self.pdfImagePath[0]

            # main_image = cv2.imread(first_page_path, cv2.IMREAD_GRAYSCALE)
            # image = cv2.GaussianBlur(main_image, (3, 3), 0)
            # image = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
            # kernel = np.ones((1, 1), np.uint8)
            # image = cv2.dilate(image, kernel, iterations=1)

            main_image = cv2.imread(first_page_path)
            image = cv2.cvtColor(main_image, cv2.COLOR_BGR2GRAY)

            # First crop all the columns from first page
            y1 = 964
            y2 = 1007
            x1 = 67
            x2 = 1553
            cropped_image = image[y1:y2, x1:x2]
            # cv2.imwrite(f'Processing/Measurement_{i+1}.PNG', cropped_image)
            pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
            extracted_text = pytesseract.image_to_string(pil_image)
            extracted_text = extracted_text.replace('\n\n', '\n').strip()
            extracted_text = extracted_text.replace('\n', ' ').strip()
            extracted_text = extracted_text.replace('  ', ' ').strip()
            extracted_text = self.remove_special_characters(extracted_text)
            extracted_text = extracted_text.replace('  ', ' ').strip().upper()

            data_array = str(extracted_text).split(' ')
            if len(data_array) > 0:
                self.strContainer = str(data_array[0]).strip()
                self.strSeal = str(data_array[1]).strip()
            else:
                self.strContainer = str(extracted_text).strip()
                self.strSeal = str(extracted_text).strip()

            y1 = 930
            y2 = 1397
            x1 = 74
            x2 = 379
            cropped_image = image[y1:y2, x1:x2]
            cv2.imwrite(f'Processing/MarksAndNosColumnMBL.PNG', cropped_image)

            y1 = 930
            y2 = 1397
            x1 = 378
            x2 = 539
            cropped_image = image[y1:y2, x1:x2]
            cv2.imwrite(f'Processing/PackageQuantityColumnMBL.PNG', cropped_image)

            y1 = 930
            y2 = 1397
            x1 = 563
            x2 = 1145
            cropped_image = image[y1:y2, x1:x2]
            cv2.imwrite(f'Processing/DescriptionOfGoodsColumnMBL.PNG', cropped_image)

            y1 = 930
            y2 = 1397
            x1 = 1142
            x2 = 1363
            cropped_image = image[y1:y2, x1:x2]
            cv2.imwrite(f'Processing/GrossWeightColumnMBL.PNG', cropped_image)

            y1 = 930
            y2 = 1397
            x1 = 1361
            x2 = 1553
            cropped_image = image[y1:y2, x1:x2]
            cv2.imwrite(f'Processing/MeasurementColumnMBL.PNG', cropped_image)

            # Extract Top coordinates of each line based from measurement column image which contains CBM or KGS to separate lines
            image = Image.open('Processing/MeasurementColumnMBL.PNG')
            data = pytesseract.image_to_data(image, output_type='dict')
            df = pd.DataFrame(data)
            df_filtered = df.loc[lambda x: x['level'] == 5]

            top_values = []
            for index, row in df_filtered.iterrows():
                if "CBM" in str(row['text']).upper() or " CBM" in str(row['text']).upper():
                    top_values.append(str(row['top']))

            start = 0
            length = len(top_values)

            for i in range(start, start + length):
                y1 = int(top_values[i])

                if i == length-1:
                    y2 = y1 + 500
                else:
                    y2 = int(top_values[i+1])

                self.strHblNumber = ""
                self.strMarksAndNo = ""
                self.strPackage = ""
                self.strDescription = ""
                self.strMeasurement = ""
                self.strGrossWeight = ""

                cv2image = cv2.imread('Processing/MeasurementColumnMBL.PNG')
                cropped_image = cv2image[y1-8:y2-8, :]
                # cv2.imwrite(f'Processing/Measurement_{i+1}.PNG', cropped_image)
                pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
                extracted_text = pytesseract.image_to_string(pil_image)
                extracted_text = extracted_text.replace('\n\n', '\n').strip()
                extracted_text = extracted_text.replace('\n', ' ').strip()
                extracted_text = extracted_text.replace('  ', ' ').strip()
                extracted_text = extracted_text.replace('CBM', ' ').strip()
                extracted_text = extracted_text.replace(',', '').strip()
                extracted_text = self.extract_decimals(extracted_text)
                self.strMeasurement = extracted_text.strip().replace(' ', '').replace('|', '')

                cv2image = cv2.imread('Processing/GrossWeightColumnMBL.PNG')
                cropped_image = cv2image[y1-8:y2-8, :]
                # cv2.imwrite(f'Processing/GrossWeight_{i+1}.PNG', cropped_image)
                pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
                extracted_text = pytesseract.image_to_string(pil_image)
                extracted_text = extracted_text.replace('\n\n', '\n').strip()
                extracted_text = extracted_text.replace('\n', ' ').strip()
                extracted_text = extracted_text.replace('  ', ' ').strip()
                extracted_text = extracted_text.replace('KGS', ' ').strip()
                extracted_text = extracted_text.replace(',', '').strip()
                extracted_text = self.extract_decimals(extracted_text)
                self.strGrossWeight = extracted_text.strip().replace(' ', '').replace('|', '')

                cv2image = cv2.imread('Processing/DescriptionOfGoodsColumnMBL.PNG')
                cropped_image = cv2image[y1-12:y2-8, :]
                # cv2.imwrite(f'Processing/DescriptionOfGoods_{i+1}.PNG', cropped_image)
                pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
                extracted_text = pytesseract.image_to_string(pil_image)
                extracted_text = extracted_text.replace('\n\n', '\n').strip()
                extracted_text = extracted_text.replace('\n', ' ').strip()
                extracted_text = extracted_text.replace('  ', ' ').strip()
                extracted_text = self.remove_special_characters(extracted_text)
                self.strDescription = extracted_text.strip().upper()

                cv2image = cv2.imread('Processing/PackageQuantityColumnMBL.PNG')
                cropped_image = cv2image[y1-8:y2-8, :]
                # cv2.imwrite(f'Processing/PackageQuantityColumn_{i+1}.PNG', cropped_image)
                pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
                extracted_text = pytesseract.image_to_string(pil_image)
                extracted_text = extracted_text.replace('\n\n', '\n').strip()
                extracted_text = extracted_text.replace('\n', ' ').strip()
                extracted_text = extracted_text.replace('  ', ' ').strip()
                extracted_text = self.remove_special_characters(extracted_text)
                extracted_text = extracted_text.replace(' ', '').strip()
                self.strPackage = extracted_text.strip().upper()

                cv2image = cv2.imread('Processing/MarksAndNosColumnMBL.PNG')
                cropped_image = cv2image[y1-12:y2-8, :]
                # cv2.imwrite(f'Processing/MarksAndNosColumn_{i+1}.PNG', cropped_image)
                pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
                extracted_text = pytesseract.image_to_string(pil_image)
                extracted_text = extracted_text.replace('\n\n', '').strip()
                extracted_text = extracted_text.replace('\n', '').strip()
                extracted_text = extracted_text.replace('  ', ' ').strip()
                extracted_text = str(extracted_text).upper()

                hbl_pattern1 = r'\b[A-Z]{3}/[A-Z]{3}/\d{5}'
                hbl_pattern2 = r'\b[A-Z]{3}/\s[A-Z]{3}/\s\d{5}\b'
                hbl_pattern3 = r'\b[A-Z]{6}\d{8}\b'
                hbl_pattern4 = r'\b[A-Z]{3}/[A-Z]{3}\s/\d{5}\b'
                hbl_pattern5 = r'\b[A-Z]{3}-\b[A-Z]{3}-\b[A-Z]{2}\d{6}\b'
                hbl_pattern6 = r'\b[A-Z]{6}\d{6}\b[A-Z]{1}'

                patterns = [hbl_pattern1, hbl_pattern2, hbl_pattern3, hbl_pattern4, hbl_pattern5, hbl_pattern6]
                is_found = False
                length_of_hbl_number = 0

                for pattern in patterns:
                    matches = re.finditer(pattern, extracted_text)
                    for match in matches:
                        is_found = True
                        self.strHblNumber = str(match.group()).strip()
                        length_of_hbl_number = len(self.strHblNumber)
                        break
                    if is_found:
                        break

                extracted_text = extracted_text[length_of_hbl_number:]
                self.strMarksAndNo = extracted_text.strip()
                self.strMarksAndNo = self.remove_special_characters(self.strMarksAndNo)
                self.strHblNumber = self.strHblNumber.replace(' ', '')

                if self.strPackage == "ICARTON" or self.strPackage == "CARTON":
                    self.strPackage = "1CARTON"
                elif self.strPackage == "ICTN" or self.strPackage == "CTN":
                    self.strPackage = "1CTN"
                elif self.strPackage == "IPACKAGE" or self.strPackage == "PACKAGE":
                    self.strPackage = "1PACKAGE"
                elif self.strPackage == "IBOX" or self.strPackage == "BOX":
                    self.strPackage = "1BOX"
                elif self.strPackage == "IWOODEN CASE" or self.strPackage == "WOODEN CASE":
                    self.strPackage = "1WOODEN CASE"
                elif self.strPackage == "ICASE" or self.strPackage == "CASE":
                    self.strPackage = "1CASE"
                elif self.strPackage == "IPALLET" or self.strPackage == "PALLET":
                    self.strPackage = "1PALLET"
                elif self.strPackage == "IPIECE" or self.strPackage == "PIECE":
                    self.strPackage = "1PIECE"
                elif self.strPackage == "ICRATE" or self.strPackage == "CRATE":
                    self.strPackage = "1CRATE"
                elif self.strPackage == "IDRUM" or self.strPackage == "DRUM":
                    self.strPackage = "1DRUM"
                elif self.strPackage == "IROLL" or self.strPackage == "ROLL":
                    self.strPackage = "1ROLL"
                elif self.strPackage == "ISKID" or self.strPackage == "SKID":
                    self.strPackage = "1SKID"

                if 'OCARTONS' in self.strPackage:
                    self.strPackage = self.strPackage.replace("OCARTONS", "0CARTONS")
                elif 'SCARTONS' in self.strPackage:
                    self.strPackage = self.strPackage.replace("SCARTONS", "5CARTONS")
                elif 'OCTNS' in self.strPackage:
                    self.strPackage = self.strPackage.replace("OCTNS", "0CTNS")
                elif 'SCTNS' in self.strPackage:
                    self.strPackage = self.strPackage.replace("SCTNS", "5CTNS")
                elif "OPACKAGES" in self.strPackage:
                    self.strPackage = self.strPackage.replace("OPACKAGES", "0PACKAGES")
                elif "SPACKAGES" in self.strPackage:
                    self.strPackage = self.strPackage.replace("SPACKAGES", "5PACKAGES")
                elif "OBOXS" in self.strPackage:
                    self.strPackage = self.strPackage.replace("OBOXS", "0BOXS")
                elif "SBOXS" in self.strPackage:
                    self.strPackage = self.strPackage.replace("SBOXS", "5BOXS")
                elif "OWOODEN CASES" in self.strPackage:
                    self.strPackage = self.strPackage.replace("OWOODEN CASES", "0WOODEN CASES")
                elif "SWOODEN CASES" in self.strPackage:
                    self.strPackage = self.strPackage.replace("SWOODEN CASES", "5WOODEN CASES")
                elif "OCASES" in self.strPackage:
                    self.strPackage = self.strPackage.replace("OCASES", "0CASES")
                elif "SCASES" in self.strPackage:
                    self.strPackage = self.strPackage.replace("SCASES", "5CASES")
                elif "OPALLETS" in self.strPackage:
                    self.strPackage = self.strPackage.replace("OPALLETS", "0PALLETS")
                elif "SPALLETS" in self.strPackage:
                    self.strPackage = self.strPackage.replace("SPALLETS", "5PALLETS")
                elif "OPIECES" in self.strPackage:
                    self.strPackage = self.strPackage.replace("OPIECES", "0PIECES")
                elif "SPIECES" in self.strPackage:
                    self.strPackage = self.strPackage.replace("SPIECES", "5PIECES")
                elif "OCRATES" in self.strPackage:
                    self.strPackage = self.strPackage.replace("OCRATES", "0CRATES")
                elif "SCRATES" in self.strPackage:
                    self.strPackage = self.strPackage.replace("SCRATES", "5CRATES")
                elif "ODRUMS" in self.strPackage:
                    self.strPackage = self.strPackage.replace("ODRUMS", "0DRUMS")
                elif "SDRUMS" in self.strPackage:
                    self.strPackage = self.strPackage.replace("SDRUMS", "5DRUMS")
                elif "OROLLS" in self.strPackage:
                    self.strPackage = self.strPackage.replace("OROLLS", "0ROLLS")
                elif "SROLLS" in self.strPackage:
                    self.strPackage = self.strPackage.replace("SROLLS", "5ROLLS")
                elif "OSKIDS" in self.strPackage:
                    self.strPackage = self.strPackage.replace("OSKIDS", "0SKIDS")
                elif "SSKIDS" in self.strPackage:
                    self.strPackage = self.strPackage.replace("SSKIDS", "5SKIDS")

                if self.strHblNumber != "":
                    if self.strMarksAndNo != "" and self.strPackage != "" and self.strDescription != "" and self.strGrossWeight != "" and self.strMeasurement != "":
                        self.detailsData.append({
                            "HouseBL": self.strHblNumber,
                            "MarksAndNo": self.strMarksAndNo,
                            "Package": self.strPackage,
                            "Description": self.strDescription,
                            "GrossWeight": float(self.strGrossWeight),
                            "Measurement": float(self.strMeasurement),
                            "Package_Plumber": "",
                            "GrossWeight_Plumber": "",
                            "Measurement_Plumber": "",
                        })
        except Exception as err:
            self.obj_common.write_log(f"Error in extract_first_page_details_data function: -{str(err)}")

    def extract_other_page_data(self):
        try:
            counter = 0
            for imagePath in self.pdfImagePath:
                if counter == 0:
                    counter = counter + 1
                    continue

                # main_image = cv2.imread(imagePath, cv2.IMREAD_GRAYSCALE)
                # image = cv2.GaussianBlur(main_image, (3, 3), 0)
                # image = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
                # kernel = np.ones((1, 1), np.uint8)
                # image = cv2.dilate(image, kernel, iterations=1)

                main_image = cv2.imread(imagePath)
                image = cv2.cvtColor(main_image, cv2.COLOR_BGR2GRAY)

                # First crop all the columns from main page
                y1 = 183
                y2 = 1929
                x1 = 37
                x2 = 375
                cropped_image = image[y1:y2, x1:x2]
                cv2.imwrite(f'Processing/MarksAndNosColumnMBL.PNG', cropped_image)

                y1 = 183
                y2 = 1929
                x1 = 377
                x2 = 529
                cropped_image = image[y1:y2, x1:x2]
                cv2.imwrite(f'Processing/PackageQuantityColumnMBL.PNG', cropped_image)

                y1 = 183
                y2 = 1929
                x1 = 545
                x2 = 1113
                cropped_image = image[y1:y2, x1:x2]
                cv2.imwrite(f'Processing/DescriptionOfGoodsColumnMBL.PNG', cropped_image)

                y1 = 183
                y2 = 1929
                x1 = 1112
                x2 = 1334
                cropped_image = image[y1:y2, x1:x2]
                cv2.imwrite(f'Processing/GrossWeightColumnMBL.PNG', cropped_image)

                y1 = 183
                y2 = 1929
                x1 = 1334
                x2 = 1561
                cropped_image = image[y1:y2, x1:x2]
                cv2.imwrite(f'Processing/MeasurementColumnMBL.PNG', cropped_image)

                # Extract Top coordinates of each line based from measurement column image which contains CBM or KGS to separate lines
                image = Image.open('Processing/MeasurementColumnMBL.PNG')
                data = pytesseract.image_to_data(image, output_type='dict')
                df = pd.DataFrame(data)
                df_filtered = df.loc[lambda x: x['level'] == 5]

                top_values = [55]
                for index, row in df_filtered.iterrows():
                    if "CBM" in str(row['text']).upper() or " CBM" in str(row['text']).upper():
                        top_values.append(str(row['top']))

                start = 0
                length = len(top_values)

                if length > 1:
                    for i in range(start, start + length):
                        y1 = int(top_values[i])

                        if i == length-1:
                            y2 = y1 + 500
                        else:
                            y2 = int(top_values[i+1])

                        self.strHblNumber = ""
                        self.strMarksAndNo = ""
                        self.strPackage = ""
                        self.strDescription = ""
                        self.strMeasurement = ""
                        self.strGrossWeight = ""

                        cv2image = cv2.imread('Processing/MeasurementColumnMBL.PNG')
                        cropped_image = cv2image[y1-4:y2, :]
                        # cv2.imwrite(f'Processing/Measurement_{i+1}.PNG', cropped_image)
                        pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        extracted_text = extracted_text.replace('\n\n', '\n').strip()
                        extracted_text = extracted_text.replace('\n', ' ').strip()
                        extracted_text = extracted_text.replace('  ', ' ').strip()
                        extracted_text = extracted_text.replace('CBM', ' ').strip()
                        extracted_text = extracted_text.replace(',', '').strip()
                        extracted_text = self.extract_decimals(extracted_text)
                        self.strMeasurement = extracted_text.strip().replace(' ', '').replace('|', '')

                        cv2image = cv2.imread('Processing/GrossWeightColumnMBL.PNG')
                        cropped_image = cv2image[y1-4:y2, :]
                        # cv2.imwrite(f'Processing/GrossWeight_{i+1}.PNG', cropped_image)
                        pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        extracted_text = extracted_text.replace('\n\n', '\n').strip()
                        extracted_text = extracted_text.replace('\n', ' ').strip()
                        extracted_text = extracted_text.replace('  ', ' ').strip()
                        extracted_text = extracted_text.replace('KGS', ' ').strip()
                        extracted_text = extracted_text.replace(',', '').strip()
                        extracted_text = self.extract_decimals(extracted_text)
                        self.strGrossWeight = extracted_text.strip().replace(' ', '').replace('|', '')

                        cv2image = cv2.imread('Processing/DescriptionOfGoodsColumnMBL.PNG')
                        cropped_image = cv2image[y1-4:y2, :]
                        # cv2.imwrite(f'Processing/DescriptionOfGoods_{i+1}.PNG', cropped_image)
                        pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        extracted_text = extracted_text.replace('\n\n', '\n').strip()
                        extracted_text = extracted_text.replace('\n', ' ').strip()
                        extracted_text = extracted_text.replace('  ', ' ').strip()
                        extracted_text = self.remove_special_characters(extracted_text)
                        self.strDescription = extracted_text.strip().upper()

                        if 'TOTAL PACKAGES' in self.strDescription.upper():
                            index = self.strDescription.find('TOTAL PACKAGES')
                            self.strDescription = self.strDescription[0:index-1]

                        cv2image = cv2.imread('Processing/PackageQuantityColumnMBL.PNG')
                        cropped_image = cv2image[y1-4:y2, :]
                        # cv2.imwrite(f'Processing/PackageQuantityColumn_{i+1}.PNG', cropped_image)
                        pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        extracted_text = extracted_text.replace('\n\n', '\n').strip()
                        extracted_text = extracted_text.replace('\n', ' ').strip()
                        extracted_text = extracted_text.replace('  ', ' ').strip()
                        extracted_text = self.remove_special_characters(extracted_text)
                        extracted_text = extracted_text.replace(' ', '').strip()
                        self.strPackage = extracted_text.strip().upper()

                        cv2image = cv2.imread('Processing/MarksAndNosColumnMBL.PNG')
                        cropped_image = cv2image[y1-4:y2, :]

                        image = cv2.GaussianBlur(cropped_image, (3, 3), 0)
                        kernel = np.ones((1, 1), np.uint8)
                        cropped_image = cv2.dilate(image, kernel, iterations=1)

                        # cv2.imwrite(f'Processing/MarksAndNosColumn_{i+1}.PNG', cropped_image)
                        pil_image = Image.fromarray(cv2.cvtColor(cropped_image, cv2.COLOR_BGR2RGB))
                        extracted_text = pytesseract.image_to_string(pil_image)
                        extracted_text = extracted_text.replace('\n\n', '\n').strip()
                        extracted_text = extracted_text.replace('\n', ' ').strip()
                        extracted_text = extracted_text.replace('  ', ' ').strip()
                        extracted_text = str(extracted_text).upper()

                        hbl_pattern1 = r'\b[A-Z]{3}/[A-Z]{3}/\d{5}'
                        hbl_pattern2 = r'\b[A-Z]{3}/\s[A-Z]{3}/\s\d{5}\b'
                        hbl_pattern3 = r'\b[A-Z]{6}\d{8}\b'
                        hbl_pattern4 = r'\b[A-Z]{3}/[A-Z]{3}\s/\d{5}\b'
                        hbl_pattern5 = r'\b[A-Z]{3}-\b[A-Z]{3}-\b[A-Z]{2}\d{6}\b'
                        hbl_pattern6 = r'[A-Z]{6}\d{6}[A-Z]'

                        patterns = [hbl_pattern1, hbl_pattern2, hbl_pattern3, hbl_pattern4, hbl_pattern5, hbl_pattern6]
                        is_found = False
                        length_of_hbl_number = 0

                        for pattern in patterns:
                            matches = re.finditer(pattern, extracted_text)
                            for match in matches:
                                is_found = True
                                self.strHblNumber = str(match.group()).strip()
                                length_of_hbl_number = len(self.strHblNumber)
                                break
                            if is_found:
                                break

                        extracted_text = extracted_text[length_of_hbl_number:]
                        self.strMarksAndNo = extracted_text.strip()
                        self.strMarksAndNo = self.remove_special_characters(self.strMarksAndNo)
                        self.strHblNumber = self.strHblNumber.replace(' ', '')

                        if 'OCEAN FREIGHT' in self.strMarksAndNo.upper():
                            index = self.strMarksAndNo.find('OCEAN FREIGHT')
                            self.strMarksAndNo = self.strMarksAndNo[0:index-1]

                        if self.strPackage == "ICARTON" or self.strPackage == "CARTON":
                            self.strPackage = "1CARTON"
                        elif self.strPackage == "ICTN" or self.strPackage == "CTN":
                            self.strPackage = "1CTN"
                        elif self.strPackage == "IPACKAGE" or self.strPackage == "PACKAGE":
                            self.strPackage = "1PACKAGE"
                        elif self.strPackage == "IBOX" or self.strPackage == "BOX":
                            self.strPackage = "1BOX"
                        elif self.strPackage == "IWOODEN CASE" or self.strPackage == "WOODEN CASE":
                            self.strPackage = "1WOODEN CASE"
                        elif self.strPackage == "ICASE" or self.strPackage == "CASE":
                            self.strPackage = "1CASE"
                        elif self.strPackage == "IPALLET" or self.strPackage == "PALLET":
                            self.strPackage = "1PALLET"
                        elif self.strPackage == "IPIECE" or self.strPackage == "PIECE":
                            self.strPackage = "1PIECE"
                        elif self.strPackage == "ICRATE" or self.strPackage == "CRATE":
                            self.strPackage = "1CRATE"
                        elif self.strPackage == "IDRUM" or self.strPackage == "DRUM":
                            self.strPackage = "1DRUM"
                        elif self.strPackage == "IROLL" or self.strPackage == "ROLL":
                            self.strPackage = "1ROLL"
                        elif self.strPackage == "ISKID" or self.strPackage == "SKID":
                            self.strPackage = "1SKID"

                        if 'OCARTONS' in self.strPackage:
                            self.strPackage = self.strPackage.replace("OCARTONS", "0CARTONS")
                        elif 'SCARTONS' in self.strPackage:
                            self.strPackage = self.strPackage.replace("SCARTONS", "5CARTONS")
                        elif 'OCTNS' in self.strPackage:
                            self.strPackage = self.strPackage.replace("OCTNS", "0CTNS")
                        elif 'SCTNS' in self.strPackage:
                            self.strPackage = self.strPackage.replace("SCTNS", "5CTNS")
                        elif "OPACKAGES" in self.strPackage:
                            self.strPackage = self.strPackage.replace("OPACKAGES", "0PACKAGES")
                        elif "SPACKAGES" in self.strPackage:
                            self.strPackage = self.strPackage.replace("SPACKAGES", "5PACKAGES")
                        elif "OBOXS" in self.strPackage:
                            self.strPackage = self.strPackage.replace("OBOXS", "0BOXS")
                        elif "SBOXS" in self.strPackage:
                            self.strPackage = self.strPackage.replace("SBOXS", "5BOXS")
                        elif "OWOODEN CASES" in self.strPackage:
                            self.strPackage = self.strPackage.replace("OWOODEN CASES", "0WOODEN CASES")
                        elif "SWOODEN CASES" in self.strPackage:
                            self.strPackage = self.strPackage.replace("SWOODEN CASES", "5WOODEN CASES")
                        elif "OCASES" in self.strPackage:
                            self.strPackage = self.strPackage.replace("OCASES", "0CASES")
                        elif "SCASES" in self.strPackage:
                            self.strPackage = self.strPackage.replace("SCASES", "5CASES")
                        elif "OPALLETS" in self.strPackage:
                            self.strPackage = self.strPackage.replace("OPALLETS", "0PALLETS")
                        elif "SPALLETS" in self.strPackage:
                            self.strPackage = self.strPackage.replace("SPALLETS", "5PALLETS")
                        elif "OPIECES" in self.strPackage:
                            self.strPackage = self.strPackage.replace("OPIECES", "0PIECES")
                        elif "SPIECES" in self.strPackage:
                            self.strPackage = self.strPackage.replace("SPIECES", "5PIECES")
                        elif "OCRATES" in self.strPackage:
                            self.strPackage = self.strPackage.replace("OCRATES", "0CRATES")
                        elif "SCRATES" in self.strPackage:
                            self.strPackage = self.strPackage.replace("SCRATES", "5CRATES")
                        elif "ODRUMS" in self.strPackage:
                            self.strPackage = self.strPackage.replace("ODRUMS", "0DRUMS")
                        elif "SDRUMS" in self.strPackage:
                            self.strPackage = self.strPackage.replace("SDRUMS", "5DRUMS")
                        elif "OROLLS" in self.strPackage:
                            self.strPackage = self.strPackage.replace("OROLLS", "0ROLLS")
                        elif "SROLLS" in self.strPackage:
                            self.strPackage = self.strPackage.replace("SROLLS", "5ROLLS")
                        elif "OSKIDS" in self.strPackage:
                            self.strPackage = self.strPackage.replace("OSKIDS", "0SKIDS")
                        elif "SSKIDS" in self.strPackage:
                            self.strPackage = self.strPackage.replace("SSKIDS", "5SKIDS")

                        if self.strHblNumber != "":
                            if self.strMarksAndNo != "" and self.strPackage != "" and self.strDescription != "" and self.strGrossWeight != "" and self.strMeasurement != "":
                                self.detailsData.append({
                                    "HouseBL": self.strHblNumber,
                                    "MarksAndNo": self.strMarksAndNo,
                                    "Package": self.strPackage,
                                    "Description": self.strDescription,
                                    "GrossWeight": float(self.strGrossWeight),
                                    "Measurement": float(self.strMeasurement),
                                    "Package_Plumber": "",
                                    "GrossWeight_Plumber": "",
                                    "Measurement_Plumber": "",
                                })

        except Exception as err:
            self.obj_common.write_log(f"Error in extract_other_page_data function: -{str(err)}")

    def remove_special_characters(self, text):
        try:
            pattern = r'[^a-zA-Z0-9\s]'
            # Replace special characters with an empty string
            cleaned_text = re.sub(pattern, '', text)
            return cleaned_text
        except Exception as err:
            self.obj_common.write_log(f"Error in remove_special_characters function: -{str(err)}")
            return text

    def extract_decimals(self, text):
        try:
            pattern = r'\d+\.\d+'
            decimals = re.findall(pattern, text)
            if len(decimals) > 0:
                return str(decimals[0]).strip()
            else:
                return text
        except Exception as err:
            self.obj_common.write_log(f"Error in extract_decimals function: -{str(err)}")
            return text

    def write_to_excel(self, str_pdf_file_path):
        try:
            workbook = xlsxwriter.Workbook(str_pdf_file_path.replace('.pdf', '.xlsx'))
            worksheet = workbook.add_worksheet()
            worksheet.name = "Header Data"

            # worksheet.set_column('A:A', 20)
            if len(self.headersData) > 0:
                worksheet.write('A1', 'Shipper')
                worksheet.write('B1', 'Consignee')
                worksheet.write('C1', 'NotifyAddress')
                worksheet.write('D1', 'Vessel')
                worksheet.write('E1', 'PortOfLoading')
                worksheet.write('F1', 'PortOfDischarge')
                worksheet.write('G1', 'PlaceOfDelivery')
                worksheet.write('H1', 'SeaWayBillNo')
                worksheet.write('I1', 'ExportReference')
                worksheet.write('J1', 'Container')
                worksheet.write('K1', 'Seal')

                counter = 2
                for data in self.headersData:
                    worksheet.write('A' + str(counter), data['Shipper'])
                    worksheet.write('B' + str(counter), data["Consignee"])
                    worksheet.write('C' + str(counter), data['NotifyAddress'])
                    worksheet.write('D' + str(counter), data['Vessel'])
                    worksheet.write('E' + str(counter), data['PortOfLoading'])
                    worksheet.write('F' + str(counter), data['PortOfDischarge'])
                    worksheet.write('G' + str(counter), data['PlaceOfDelivery'])
                    worksheet.write('H' + str(counter), data['SeaWayBillNo'])
                    worksheet.write('I' + str(counter), data['ExportReference'])
                    worksheet.write('J' + str(counter), data['Container'])
                    worksheet.write('K' + str(counter), data['Seal'])

            if len(self.detailsData) > 0:
                worksheet = workbook.add_worksheet()
                worksheet.name = "Details Data"

                worksheet.write('A1', 'HouseBL')
                worksheet.write('B1', 'MarksAndNo')
                worksheet.write('C1', 'Package')
                worksheet.write('D1', 'Description')
                worksheet.write('E1', 'GrossWeight')
                worksheet.write('F1', 'Measurement')
                worksheet.write('G1', "Package_Plumber")
                worksheet.write('H1', "GrossWeight_Plumber")
                worksheet.write('I1', "Measurement_Plumber")

                counter = 2
                for data in self.detailsData:
                    worksheet.write('A' + str(counter), data['HouseBL'])
                    worksheet.write('B' + str(counter), data['MarksAndNo'])
                    worksheet.write('C' + str(counter), data['Package'])
                    worksheet.write('D' + str(counter), data['Description'])
                    worksheet.write('E' + str(counter), data['GrossWeight'])
                    worksheet.write('F' + str(counter), data['Measurement'])
                    worksheet.write('G' + str(counter), data["Package_Plumber"])
                    worksheet.write('H' + str(counter), data["GrossWeight_Plumber"])
                    worksheet.write('I' + str(counter), data["Measurement_Plumber"])
                    counter = counter + 1

            workbook.close()
        except Exception as err:
            self.obj_common.write_log(f"Error in write_to_excel function: -{str(err)}")
