import cv2
import numpy as np


def crop_image(image_path):
    img = cv2.imread(image_path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    _, thresh = cv2.threshold(gray, 1, 255, cv2.THRESH_BINARY)
    coords = cv2.findNonZero(thresh)
    x, y, w, h = cv2.boundingRect(coords)

    # height = img.shape[0]
    # cropped_img = img[:height-100, x:x+w]

    cropped_img = img[:50, 0:540]
    return cropped_img


cropped = crop_image("C:\Pundlik\OneDrive - WNS\MY_PYTHON_PROJECTS\MBLDataExtractor\Processing\HBL_SI.PNG")
cv2.imwrite('cropped_image.jpg', cropped)
