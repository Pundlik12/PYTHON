import cv2


# Function to capture coordinates for cropping
def select_roi(event, x, y, flags, param):
    global x1, y1, cropping, image

    if event == cv2.EVENT_LBUTTONDOWN:  # Mouse button press
        x1, y1 = x, y
        cropping = True

    elif event == cv2.EVENT_LBUTTONUP:  # Mouse button release
        x2, y2 = x, y
        cropping = False

        # Draw the rectangle on the image (optional)
        cv2.rectangle(image, (x1, y1), (x2, y2), (0, 255, 0), 2)
        cv2.imshow("image", image)

        print('y1:-' + str(y1) + ',y2:-' + str(y2) + '--x1:-' + str(x1) + ',x2:-' + str(x2))
        # Crop the image using the selected coordinates
        cropped_image = image[y1:y2, x1:x2]
        cv2.imshow("Cropped Image", cropped_image)
        cv2.imwrite("CroppedImage.png", cropped_image)
        cv2.waitKey(0)


# Load an image
strFilePath = 'Processing/MBL_Page_1.png'
image = cv2.imread(strFilePath)

# Clone the image to avoid modifying the original
clone = image.copy()

# Variable to track cropping
x1, y1, x2, y2 = -1, -1, -1, -1
cropping = False

# Set up mouse callback function to capture ROI
cv2.namedWindow("image", cv2.WINDOW_NORMAL)
cv2.setMouseCallback("image", select_roi)

# resize the window to the image size
cv2.resizeWindow("image", image.shape[1], image.shape[0])

# Show the image and wait for a key press
cv2.imshow("image", image)
cv2.waitKey(0)
cv2.destroyAllWindows()

