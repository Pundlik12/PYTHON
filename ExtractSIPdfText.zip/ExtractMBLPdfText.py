import re
import pdfplumber
from CommonClasses.common import Common


class ExtractMBLDataPdfPlumber:
    text = ''
    Shipper = ''
    Consignee = ''
    NotifyAddress = ''
    BookingRef = ''
    ContainerNo = ''
    Seal = ''
    NrFile = ''
    Vessel = ''
    PortOfLoading = ''
    PlaceOfDelivery = ''
    FinalDestination = ''

    HblNumber = ''
    MarksAndNo = ''
    Package = ''
    Description = ''
    GrossWeight = ''
    Measurement = ''
    first_page_row_locator = 0
    headers_data = []
    details_data = []
    obj_common = None

    def __init__(self):
        self.obj_common = Common()

    def initiate_variables(self):
        self.text = ''
        self.Shipper = ''
        self.Consignee = ''
        self.NotifyAddress = ''
        self.BookingRef = ''
        self.ContainerNo = ''
        self.Seal = ''
        self.NrFile = ''
        self.Vessel = ''
        self.PortOfLoading = ''
        self.PlaceOfDelivery = ''
        self.FinalDestination = ''

        self.HblNumber = ''
        self.MarksAndNo = ''
        self.Package = ''
        self.Description = ''
        self.GrossWeight = ''
        self.Measurement = ''
        self.first_page_row_locator = 0
        self.headers_data = []
        self.details_data = []

    def extract_text_from_pdf(self, pdf_path):
        try:
            self.initiate_variables()

            with pdfplumber.open(pdf_path) as pdf:
                for page in pdf.pages:
                    self.text = self.text + page.extract_text() + '\n'

        except Exception as exp:
            self.text = ""
            self.obj_common.write_log(f'Error in extract_text_from_pdf function of MBL: - {str(exp)}')

        if self.text != "":
            self.extract_header_details()
            self.extract_line_details()

        return self.headers_data, self.details_data

    def extract_header_details(self):
        try:
            tempdata = self.get_data_between_markers("SHIPPER/EXPORTER", "CONSIGNEE")
            if len(tempdata) > 0:
                for x in range(len(tempdata)-1):
                    line = tempdata[x]
                    if x == 0:
                        self.BookingRef = line.split(' ')[0].strip()
                        continue
                    elif 'EXPORT REFERENCES' in line:
                        start_position = line.find('EXPORT REFERENCES')
                        text = line[1:start_position]
                        self.Shipper = self.Shipper + text.strip() + '\n'
                        x = x + 1
                    elif 'SH>' in line:
                        self.Shipper = self.Shipper + text.replace('SH>', '').strip() + '\n'
                        break
                    else:
                        if 'EXPORT REFERENCES' in tempdata[x-1]:
                            self.NrFile = line
                            continue
                        else:
                            self.Shipper = self.Shipper + line + '\n'

            tempdata = self.get_data_between_markers("CONSIGNEE", "NOTIFY PARTY")
            if len(tempdata) > 0:
                for line in tempdata:
                    if 'FMC NO' in line:
                        continue
                    elif 'CN>' in line:
                        self.Consignee = self.Consignee + line.replace('CN>', '').strip() + '\n'
                        break
                    elif 'RECEIVED by the Carrier' in line:
                        break
                    else:
                        self.Consignee = self.Consignee + line + '\n'

            tempdata = self.get_data_between_markers("NOTIFY PARTY", "PRE-CARRIAGE BY")
            if len(tempdata) > 0:
                for line in tempdata:
                    if 'NP>' in line:
                        start_position = line.find('NP>')
                        text = line[1:start_position]
                        self.NotifyAddress = self.NotifyAddress + text.strip() + '\n'
                        break
                    else:
                        pattern = r'\b[A-Z]+\b'
                        capital_words = re.findall(pattern, line)
                        if len(capital_words) > 0:
                            notify_address = " ".join(map(str, capital_words))
                            self.NotifyAddress = self.NotifyAddress + notify_address + '\n'

            tempdata = self.get_data_between_markers("OCEAN VESSEL VOYAGE NO. FLAG PORT OF LOADING FINAL DESTINATION", "PORT OF DISCHARGE PLACE OF DELIVERY TYPE OF MOVEMENT")
            if len(tempdata) > 0:
                self.Vessel = tempdata[0]
                self.PortOfLoading = tempdata[0]

            tempdata = self.get_data_between_markers("PORT OF DISCHARGE PLACE OF DELIVERY TYPE OF MOVEMENT", 'CHECK "HM" COLUMN IF HAZARDOUS MATERIAL')
            if len(tempdata) > 0:
                self.PlaceOfDelivery = tempdata[0]
                self.FinalDestination = tempdata[0]

            tempdata = self.get_data_between_markers("DESCRIPTION OF GOODS GROSS WEIGHT GROSS MEASUREMENT", "--------------------------------------------------------------------")
            if len(tempdata) > 0:
                self.ContainerNo = str(tempdata[0]).split('/')[0].strip()
                self.Seal = str(tempdata[0]).split('/')[1].strip()

            self.headers_data.append({
                                "Shipper": self.Shipper,
                                "Consignee": self.Consignee,
                                "NotifyAddress": self.NotifyAddress,
                                "Vessel": self.Vessel,
                                "PortOfLoading": self.PortOfLoading,
                                "PlaceOfDelivery": self.PlaceOfDelivery,
                                "FinalDestination": self.FinalDestination,
                                "BookingNo": self.BookingRef,
                                "Container": self.ContainerNo,
                                "Seal": self.Seal
                            })

            # tempdata = self.get_data_between_markers("--------------------------------------------------------------------", "TO BE CONTINUED ON ATTACHED LIST")
            tempdata = self.text.split('\n')
            self.first_page_row_locator = 0

            if len(tempdata) > 0:
                for x in range(len(tempdata)-1):
                    line = tempdata[x]
                    kgs_cbm_line_number = 0
                    if 'TO BE CONTINUED ON' in line:
                        break

                    if 'KGS' in line and 'CBM' in line:
                        kgs_cbm_line_number = x
                        gross_weight_pattern = r'\b\d+\.\d+KGS\b'
                        match = re.search(gross_weight_pattern, line)
                        if match:
                            self.GrossWeight = match.group()
                            self.GrossWeight = self.GrossWeight.replace('KGS', '')
                            self.GrossWeight = self.GrossWeight.replace(',', '')
                        else:
                            print("GrossWeight Pattern not found.")

                        measurement_pattern = r'\b\d+\.\d+CBM\b'
                        match = re.search(measurement_pattern, line)
                        if match:
                            self.Measurement = match.group()
                            self.Measurement = self.Measurement.replace('CBM', '')
                            self.Measurement = self.Measurement.replace(',', '')
                        else:
                            print("Measurement Pattern not found.")

                        hbl_pattern = r'\b[A-Z]{3}/[A-Z]{3}/\d{5}\b'
                        match = re.search(hbl_pattern, line)
                        if match:
                            self.HblNumber = match.group()
                            hbl_to_replace = match.group()
                            self.first_page_row_locator = x
                        else:
                            hbl_pattern1 = r'\b[A-Z]{3}/[A-Z]{3}/\s\b'
                            match1 = re.search(hbl_pattern1, line)
                            if match1:
                                self.HblNumber = match1.group()
                                hbl_to_replace = match1.group()
                                hbl_pattern2 = r'\b\d{5}\b'
                                second_hbl_line = tempdata[x+1]
                                match2 = re.search(hbl_pattern2, second_hbl_line)
                                if match2:
                                    text = match2.group()
                                    self.HblNumber = self.HblNumber.strip() + text.strip()
                                    self.first_page_row_locator = x
                            else:
                                hbl_pattern1 = r'\b[A-Z]{3}/[A-Z]{3}\s\b'
                                match1 = re.search(hbl_pattern1, line)
                                if match1:
                                    self.HblNumber = match1.group()
                                    hbl_to_replace = match1.group()
                                    hbl_pattern2 = r'\b\d{5}\s\b'
                                    second_hbl_line = tempdata[x+1]
                                    match2 = re.search(hbl_pattern2, second_hbl_line)
                                    if match2:
                                        text = match2.group()
                                        self.HblNumber = self.HblNumber.strip() + "/" + text.strip()
                                        self.first_page_row_locator = x
                                else:
                                    hbl_pattern1 = r'\b[A-Z]{3}-\b[A-Z]{3}-\b[A-Z]{2}\b'
                                    match1 = re.search(hbl_pattern1, line)
                                    if match1:
                                        self.HblNumber = match1.group()
                                        hbl_to_replace = match1.group()
                                    else:
                                        hbl_to_replace = ""

                        desc = line.replace(self.GrossWeight, '').replace(self.Measurement, '').replace(hbl_to_replace, '').strip()
                        data_array = desc.split(' ')

                        if len(data_array) > 0:
                            self.Package = str(data_array[0]).strip()
                            data_array.remove(self.Package)

                            self.Package = str(self.Package).replace('H', '').replace('M', '')
                            self.Description = ' '.join(map(str, data_array))

                            text = str(tempdata[kgs_cbm_line_number + 1]).upper()
                            qty_lst = ['CARTONS', 'CARTON',
                                       'CTNS', 'CTN',
                                       'PACKAGES', 'PACKAGE',
                                       'BOXS', 'BOX',
                                       'WOODEN CASES', 'WOODEN CASE',
                                       'CASES', 'CASE',
                                       'PALLETS', 'PALLET',
                                       'PIECES', 'PIECE',
                                       'CRATES', 'CRATE',
                                       'DRUMS', 'DRUM',
                                       'ROLLS', 'ROLL',
                                       'SKIDS', 'SKID']

                            pkgs_array = text.split(' ')

                            is_found = False
                            for pkg in pkgs_array:
                                for qty in qty_lst:
                                    if str(pkg) == str(qty):
                                        self.Package = self.Package + str(qty)
                                        is_found = True
                                        break
                                if is_found is True:
                                    break

                        if self.HblNumber != "":
                            self.details_data.append(
                                        {"HouseBL": self.HblNumber,
                                         "MarksAndNo": self.MarksAndNo,
                                         "Package": self.Package,
                                         "Description": self.Description,
                                         "GrossWeight": float(self.GrossWeight),
                                         "Measurement": float(self.Measurement)})

        except Exception as Err:
            self.obj_common.write_log(f'Error in extract_header_details function of MBL: - {str(Err)}')

    def extract_line_details(self):
        try:
            line_data = self.text.split('\n')

            for x in range(len(line_data)-1):
                line = line_data[x]
                kgs_cbm_line_number = 0
                if x < self.first_page_row_locator + 1:
                    continue

                hbl_number = ""
                hbl_pattern = r'\b[A-Z]{3}/[A-Z]{3}/\d{5}\b'
                match = re.search(hbl_pattern, line)
                if match:
                    hbl_number = match.group()
                    hbl_to_replace = match.group()
                else:
                    hbl_pattern1 = r'\b[A-Z]{3}/[A-Z]{3}/\s\b'
                    match1 = re.search(hbl_pattern1, line)
                    if match1:
                        hbl_number = match1.group()
                        hbl_to_replace = match1.group()
                        hbl_pattern2 = r'\b\d{5}\b'
                        match2 = re.search(hbl_pattern2, line_data[x+1])
                        if match2:
                            text = match2.group()
                            hbl_number = hbl_number.strip() + text.strip()
                    else:
                        hbl_pattern1 = r'\b[A-Z]{3}/[A-Z]{3}\s\b'
                        match1 = re.search(hbl_pattern1, line)
                        if match1:
                            hbl_number = match1.group()
                            hbl_to_replace = match1.group()
                            hbl_pattern2 = r'\b\d{5}\s\b'
                            second_hbl_line = line_data[x+1]
                            match2 = re.search(hbl_pattern2, second_hbl_line)
                            if match2:
                                text = match2.group()
                                hbl_number = hbl_number.strip() + "/" + text.strip()
                        else:
                            hbl_pattern1 = r'\b[A-Z]{6}\d{8}\b'
                            match1 = re.search(hbl_pattern1, line)
                            if match1:
                                hbl_number = match1.group()
                                hbl_to_replace = match1.group()
                            else:
                                hbl_pattern1 = r'\b[A-Z]{3}-\b[A-Z]{3}-\b[A-Z]{2}\d{6}\b'
                                match1 = re.search(hbl_pattern1, line)
                                if match1:
                                    hbl_number = match1.group()
                                    hbl_to_replace = match1.group()
                                else:
                                    hbl_to_replace = ""

                if hbl_number != "":
                    self.HblNumber = hbl_number

                    if 'KGS' in line or 'CBM' in line:
                        kgs_cbm_line_number = x
                        gross_weight_pattern = r'\b\d+\.\d+KGS\b'
                        match = re.search(gross_weight_pattern, line)
                        if match:
                            self.GrossWeight = match.group()
                            self.GrossWeight = self.GrossWeight.replace('KGS', '')
                            self.GrossWeight = self.GrossWeight.replace(',', '')
                        else:
                            print("GrossWeight Pattern not found.")

                        measurement_pattern = r'\b\d+\.\d+CBM\b'
                        match = re.search(measurement_pattern, line)
                        if match:
                            self.Measurement = match.group()
                            self.Measurement = self.Measurement.replace('CBM', '')
                            self.Measurement = self.Measurement.replace(',', '')
                        else:
                            print("Measurement Pattern not found.")

                        desc = line.replace(self.GrossWeight + "KGS", '').replace(self.Measurement + "CBM", '').replace(hbl_to_replace, '').strip()
                        data_array = desc.split(' ')

                        if len(data_array) > 0:
                            self.Package = str(data_array[0]).strip()
                            data_array.remove(self.Package)

                            self.Package = str(self.Package).replace('H', '').replace('M', '')
                            self.Description = ' '.join(map(str, data_array))

                            text = str(line_data[kgs_cbm_line_number + 1]).upper()

                            qty_lst = ['CARTONS', 'CARTON',
                                       'CTNS', 'CTN',
                                       'PACKAGES', 'PACKAGE',
                                       'BOXS', 'BOX',
                                       'WOODEN CASES', 'WOODEN CASE',
                                       'CASES', 'CASE',
                                       'PALLETS', 'PALLET',
                                       'PIECES', 'PIECE',
                                       'CRATES', 'CRATE',
                                       'DRUMS', 'DRUM',
                                       'ROLLS', 'ROLL',
                                       'SKIDS', 'SKID']

                            pkgs_array = text.split(' ')

                            is_found = False
                            for pkg in pkgs_array:
                                for qty in qty_lst:
                                    if str(pkg) == str(qty):
                                        self.Package = self.Package + str(qty)
                                        is_found = True
                                        break
                                if is_found is True:
                                    break

                        if self.HblNumber != "":
                            self.details_data.append(
                                        {"HouseBL": self.HblNumber,
                                         "MarksAndNo": self.MarksAndNo,
                                         "Package": self.Package,
                                         "Description": self.Description,
                                         "GrossWeight": float(self.GrossWeight),
                                         "Measurement": float(self.Measurement)})

        except Exception as Err:
            self.obj_common.write_log(f'Error in extract_line_details function: - {str(Err)}')

    def is_numeric(self, value):
        try:
            float(value)
            return True
        except ValueError:
            return False

    def get_data_between_markers(self, start_text, end_text):
        try:
            lines = []
            inside = False
            line_data = self.text.split('\n')

            for line in line_data:
                if start_text.lower() in line.lower():
                    inside = True
                    continue

                if end_text.lower() in line.lower():
                    break

                if inside:
                    lines.append(line.strip())

            return lines

        except Exception as Err:
            self.obj_common.write_log(f'Error in get_data_between_markers function of MBL: - {str(Err)}')
