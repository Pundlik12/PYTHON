import os.path
import requests
import json
import pandas as pd
import datetime
import pytz

# Include your unique webhook URL here!
url = "https://wnsgs.webhook.office.com/webhookb2/8b500497-c635-449c-9948-b2308e0d07ee@23f8ecfb-6a90-46c2-96ca-4a362721b82c/IncomingWebhook/923d2fece76147449c691e1e4d20119d/cfc32be0-dfa2-4432-a931-3f6a76bb4e0c/V2gl5teoVxnl7kw_Cc6B2WD5JP_4afLzDL3s-RZiQYFp81"


# Create and returns an Adaptive Card JSON
def create_payload(email, name):
    payload = json.dumps({
        "type": "message",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "content": {
                    "type": "AdaptiveCard",
                    "body": [
                        {
                            "type": "TextBlock",
                            "text": f"Happy Birthday <at>{name}</at>! 🎂",
                            "wrap": True
                        }
                    ],
                    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "version": "1.4",
                    "msteams": {
                        "entities": [
                            {
                                "type": "mention",
                                "text": f"<at>{name}</at>",
                                "mentioned": {
                                    "id": f"{email}",
                                    "name": f"{name}"
                                }
                            }
                        ]
                    }
                }
            }
        ]
    })
    return payload


# Posts Happy Birthday Message to Teams
def post_to_teams(email, name):
    try:
        headers = {'Content-Type': 'application/json'}
        payload = create_payload(email, name)
        requests.request("POST", url, headers=headers, data=payload)
    except Exception as ex:
        print(f'Error occurred in post_to_teams function:-\n' + str(ex))


def get_birthdays():
    file = 'Team Birthdays.xlsx'
    if os.path.exists(file):
        birthday_list = pd.read_excel(file)
        # set timezone
        today = datetime.datetime.now(pytz.timezone('Asia/Kolkata'))
        # extract day and month components
        birthday_list['date'] = pd.to_datetime(birthday_list['What is your birthday?'])
        birthday_list['month'] = pd.DatetimeIndex(birthday_list['date']).month
        birthday_list['day'] = pd.DatetimeIndex(birthday_list['date']).day
        # get a list of today's birthdays
        today_birthdays = birthday_list.loc[(birthday_list['month'] == today.month) & (birthday_list['day'] == today.day)]
        today_birthdays = today_birthdays.to_numpy()
        return today_birthdays
    else:
        print('Team Birthdays.xlsx file does not exists')
        return None


def happy_birthday():
    today_birthdays = get_birthdays()
    if today_birthdays is not None:
        for birthday in today_birthdays:
            email = birthday[0]
            name = birthday[1]
            post_to_teams(email, name)


happy_birthday()
